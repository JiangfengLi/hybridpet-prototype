# 导入模型

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /models/import`

将外部 3D 模型文件导入 Tripo 平台以进行后续处理。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型文件来源。接受 `file_token`（前缀 `file_`）或 URL。


- 支持格式：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`
- 最大文件大小：**150 MB**


## Request Example

### 文件示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/models/import \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "file_abc123"
}'
```

### URL 示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/models/import \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "https://example.com/my-model.glb"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```
