# 文本生成 3D 模型 — P 系列

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/text-to-model`

使用 P 系列根据文本提示词生成 3D 模型。针对低面数输出和干净拓扑优化。

## Request Parameters

### prompt

- **Type:** string
- **Required:** 必选

文本提示词，最多 1024 个字符。描述形状、材质、风格和尺寸。


- 好的示例："一个低面数中世纪木质宝箱，带有铁铰链和生锈的锁。"
- 差的示例："一个箱子。"
- 加入材质和风格描述可提升 PBR 贴图效果。

### negative_prompt

- **Type:** string
- **Required:** 可选

反向提示词，最多 255 个字符。描述不希望在生成模型中出现的内容。例如："blurry, low quality, broken mesh"。
### image_seed

- **Type:** integer
- **Required:** 可选

内部文本转图像阶段的随机种子。控制从文本提示词生成的参考图像，然后再进行 3D 转换。若未设置，每次会使用随机种子。
### model

- **Type:** string
- **Required:** 必选

P 系列模型版本。
- `P1-20260311`：针对低面数生成优化。
- `P2-20260801`：新一代 P 系列，支持四边面输出。 preview版

### model_seed

- **Type:** integer
- **Required:** 可选

几何体生成的随机种子。使用相同种子和相同输入将生成相同的 3D 网格。若未设置，每次会使用随机种子。
### face_limit

- **Type:** integer
- **Required:** 可选

输出网格的最大面数。


- `P1-20260311`：**50 – 20,000**
- `P2-20260801` 三角面：**48 – 50,000**；`quad=true` 时：**48 – 25,000**
- 省略时自适应确定面数。
最佳质量建议：简单模型从 **150** 面起步，复杂模型从 **250** 面起步。面数过低可能导致生成质量下降。

### texture

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

是否为模型生成贴图。设为 false 可获取无贴图的纯几何体。默认为 true。
### pbr

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

启用 PBR 材质贴图（`base_color`、`metallic`、`roughness`、`normal`）。当 `pbr` 设为 `true` 时，`texture` 会自动强制设为 `true`。

### texture_seed

- **Type:** integer
- **Required:** 可选

贴图生成的随机种子。使用相同种子将生成相同的贴图。若未设置，每次会使用随机种子。如需获取相同几何体但不同贴图的模型，请保持 model_seed 不变并更改 texture_seed。
### texture_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

贴图质量等级。
- `fast`：生成最快，以细节换速度；输出贴图尺寸与 `standard` 相同。 需要贴图版本 `v3.5-20260815`；积分与 `standard` 相同。
- `standard`：质量与速度的平衡。
- `detailed`：更高保真度，生成速度较慢。
- `extreme`：8K 贴图，最高保真度。相比 detailed 额外消耗积分。


`fast` 仅在贴图版本 `v3.5-20260815` 下可用。生成接口需将 `texture_version` 设为该版本；`/v3/models/texture` 则是 `model`。其它贴图版本会返回 `1004`，不会静默回退到 `standard`。
### texture_version

- **Type:** string
- **Required:** 可选

独立指定贴图模型，与几何体 `model` 解耦。
- `v3.5-20260815`：最新贴图模型。使用 `texture_quality=fast` 与 `delight` 时必填。
- `v3.0-20250812`：`v3.x` 与 P 系列几何体的默认值。
- `v2.5-20250123`：`v2.5-20250123` 几何体的默认值。
省略时按上表根据几何体 `model` 自动推导。
### delight

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

贴图前去除参考图中的光照信息。设为 `false` 可保留原有明暗。仅 `v3.5-20260815` 贴图模型支持，更早的贴图版本会忽略该参数。
### auto_size

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否自动将生成的模型缩放至真实世界尺寸。启用后，模型尺寸将以米为单位，适用于 AR/VR 或游戏引擎场景。默认为 false。
### export_uv

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

控制 UV 展开。设为 `false` 可加快生成速度并减小文件体积。
### export_orientation

- **Type:** string
- **Required:** 可选
- **Default:** `+x`

导出朝向（前向轴）。
- `+x`：默认，X 轴正方向朝前。
- `-x`：X 轴负方向朝前。
- `-y`：Y 轴负方向朝前。
- `+y`：Y 轴正方向朝前。



- 仅作用于本次生成。如需用于后续的贴图、绑定、重定向、格式转换等后处理任务，不建议设置该参数。
- 设置该参数后，用于其他后处理任务时，可能因模型方向错误影响最终效果，但任务状态仍为`success`、不会报错，请谨慎使用该参数。
- 若计划对模型做后处理，建议本参数留空，改为在最后一步用`/v3/models/convert` 转换朝向。

### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

**仅 P2-20260801 支持。**是否输出四边面网格。

## Request Example

### P 系列示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A cat wearing a spacesuit",
  "model": "P1-20260311",
  "face_limit": 3000,
  "texture": true,
  "pbr": true
}'
```

### P2 系列示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A low-poly wooden chair",
  "model": "P2-20260801",
  "quad": true,
  "face_limit": 5000,
  "texture": true,
  "pbr": true
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```
