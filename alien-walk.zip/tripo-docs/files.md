# 文件管理

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /files`

上传文件并获取 file_token 以供后续 API 调用使用。

## Request Parameters

### file

- **Type:** binary
- **Required:** 必选

文件数据。使用 `multipart/form-data` 编码。


- 图片：`JPEG`、`PNG`。最大 **20 MB**。
- 模型：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`。最大 **150 MB**。
- 建议 > 60MB 的文件，可以参考文件上传(大文件)，有更快的性能体验。


## Response Fields

### file_token

- **Type:** string
- **Required:** 必选

文件引用 token（如 `file_abc123`）。在其他 API 调用的 `input` 字段中使用。

## Request Example

### 上传示例

```
curl -s \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -F "file=@product-photo.png" \
  https://openapi.tripo3d.com/v3/files
```


## Response Example

### 上传示例

```json
{
  "code": 0,
  "data": {
    "file_token": "file_abc123"
  }
}
```
