# 账户管理

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `GET /account/balance`

查询账户余额和用量详情。余额返回可用额度和冻结额度；用量返回按任务的消耗历史。

## Response Fields

### balance

- **Type:** number
- **Required:** 必选

可用额度余额。最多两位小数的数值（例如 41465.00）。
### frozen

- **Type:** number
- **Required:** 必选

为进行中任务冻结的额度。最多两位小数的数值（例如 0.00）。

## Request Example

### 余额

```
curl -s \
  -H "Authorization: Bearer YOUR_API_KEY" \
  https://openapi.tripo3d.com/v3/account/balance
```

### 用量

```
curl -s \
  -H "Authorization: Bearer YOUR_API_KEY" \
  https://openapi.tripo3d.com/v3/account/usage
```


## Response Example

### 余额

```json
{
  "code": 0,
  "data": {
    "balance": 10000.00,
    "frozen": 200.00
  }
}
```

### 用量

```json
{
  "code": 0,
  "data": [
    {
      "task_id": "task_abc123",
      "type": "text_to_model",
      "credits_consumed": 100.00,
      "created_at": "2025-01-01T00:00:00Z"
    }
  ]
}
```
