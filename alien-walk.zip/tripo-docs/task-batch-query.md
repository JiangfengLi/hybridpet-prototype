# 批量任务查询

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /tasks/list`

在单次请求中批量查询多个异步任务的状态和输出。返回以 task_id 为键的任务详情 map，以及未找到的任务 ID 列表。

## Request Parameters

### task_ids

- **Type:** string[]
- **Required:** 必选

要查询的任务 ID 数组。每次请求最多 **100** 个。
示例： `["task_abc123", "task_def456"]`

## Response Fields

### tasks

- **Type:** object
- **Required:** 必选

以 task_id 为键的任务详情 map。每个值的结构与单任务查询响应相同。
### missed

- **Type:** string[]
- **Required:** 必选

未找到的任务 ID 列表（无效 ID、错误的 API Key 或已过期）。

## Request Example

### 批量查询

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/tasks/list \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "task_ids": [
    "task_abc123",
    "task_def456"
  ]
}'
```


## Response Example

### 批量结果

```json
{
  "code": 0,
  "data": {
    "tasks": {
      "task_abc123": {
        "task_id": "task_abc123",
        "type": "text_to_model",
        "status": "success",
        "progress": 100,
        "credits_consumed": 100.00
      },
      "task_def456": {
        "task_id": "task_def456",
        "type": "image_to_model",
        "status": "running",
        "progress": 60
      }
    },
    "missed": []
  }
}
```
