# 开票引导

通过支付宝完成的积分充值订单，可在支付宝账单中自助申请电子发票，无需人工对接。以下 4 个步骤覆盖从查找账单到收取发票的完整流程。

![开票流程总览：查找支付账单、点击开发票、填写开票信息、邮箱收取发票](/assets/images/docs/invoice-guide/overview-steps.webp)

## 01｜找到支付账单

打开支付宝 App，在账单中搜索「tripo」，找到本次充值对应的账单记录（商品说明形如「Tripo 积分充值 600 Credits」），点击进入账单详情。

<img src="/assets/images/docs/invoice-guide/step-01-find-alipay-bill.webp" alt="步骤 1：支付宝账单搜索 tripo 后列出的充值记录" width="340" />

## 02｜点击开发票

在账单详情页核对支付时间、商品说明与收款方全称，下拉至底部的账单管理区域，点击「开发票」。

<img src="/assets/images/docs/invoice-guide/step-02-bill-detail-invoice.webp" alt="步骤 2：账单详情页底部账单管理区域中的开发票入口" width="340" />

## 03｜填写开票信息

进入票通发票服务平台后，确认开票金额与开票项目（技术服务费）无误，选择发票种类（普通发票 / 增值税专用发票）与抬头类型（企业 / 个人及非企业性单位），填写企业名称、企业税号与接收邮箱，点击「去开票」提交申请。

<img src="/assets/images/docs/invoice-guide/step-03-fill-invoice-info.webp" alt="步骤 3：票通发票服务平台的申请开票表单，含发票种类、抬头类型、企业名称、税号与接收邮箱" width="340" />

## 04｜邮箱收取发票

提交后稍等片刻，电子发票将发送至所填邮箱，邮件中附带 PDF 与 OFD 格式的发票文件，可直接下载用于报销与入账。

<img src="/assets/images/docs/invoice-guide/step-04-receive-invoice-email.webp" alt="步骤 4：邮箱收到的电子发票邮件，含 PDF 与 OFD 附件" width="340" />

## 注意事项

<div class="doc-callout doc-callout--warn rounded-lg p-4 text-sm text-[var(--text-block)]">
发票由票通电子发票服务平台开具，开票金额以该笔订单的实付金额为准，开票项目为技术服务费。提交后请注意查收邮箱（含垃圾邮件目录）。若在账单中未找到「开发票」入口，或需要换开、补开发票与对账单，请联系 business@tripo3d.com。
</div>
