# 图像生成多视图

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/image-to-multiview`

从单张图像生成多视图图像。可作为多视图转模型的预处理步骤，也可用于转台预览。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

多视图生成的源图像。接受以下输入类型：**以下方式任选其一**，不可同时传入多种类型。

- file_token：先通过文件上传 API上传图像，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的图像直链。
示例： `https://example.com/character.png`



- 支持格式：`PNG`、`JPEG`、`WebP`
- 主体应清晰可见，背景保持干净。


## Request Example

### 基础示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/image-to-multiview \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "https://example.com/character.png"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "status": "success",
    "output": {
      "front_view_url": "https://cdn.tripo3d.ai/front.png",
      "left_view_url": "https://cdn.tripo3d.ai/left.png",
      "back_view_url": "https://cdn.tripo3d.ai/back.png",
      "right_view_url": "https://cdn.tripo3d.ai/right.png"
    }
  }
}
```
