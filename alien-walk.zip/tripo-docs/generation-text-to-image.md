# 文本生成图像

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/text-to-image`

根据文本提示词生成图像。不接受参考图像 — 如需使用参考图请使用图像生图。

## Request Parameters

### model

- **Type:** string
- **Required:** 可选
- **Default:** `seedream_v4`

图像生成模型。可选模型：
- `seedream_v5` — 最新质量，提示词遵循更强。
- `seedream_v4` — 默认均衡模型。
- `banana` — 快速生成。
- `banana_pro` — 更高质量。
- `banana2` — 最新快速选项。
- `chat_image_1` — 基础图像模型。**2026-10-23 下线。**
- `chat_image_1.5` — 更高质量。**2026-12-01 下线。**
- `chat_image_2` — 最新，质量最佳。
- `chat_image_2.5_flare` — 2.5 系列速度档，质量对标 `chat_image_2`，明显更快。
- `chat_image_2.5_sunburst` — 2.5 系列精修档，编辑时对画面其余部分的保真度最好。

### prompt

- **Type:** string
- **Required:** 必选

图像生成的文本提示词。支持中文和英文。


- 推荐：不超过 300 个中文字符或 600 个英文单词。
- 将最重要的元素放在前面。
- 反向提示词：在 `--no` 后追加。

### size

- **Type:** string
- **Required:** 可选
- **Default:** `2048x2048`

输出图像尺寸。可传语义关键字（如 2K / 4K）或精确像素（如 2048x2048）；不同模型支持的取值不同，见下方分模型。
### quality

- **Type:** string
- **Required:** 可选
- **Default:** `low`

渲染质量档位。仅 `chat_image_2`、`chat_image_2.5_flare`、`chat_image_2.5_sunburst` 支持该参数，其它模型传入会直接报错。


- `chat_image_2` — `low`、`medium`、`high`。
- `chat_image_2.5_flare` / `chat_image_2.5_sunburst` — `low`、`medium`、`high`、`xhigh`、`max`。
不传等同于 `low`。请注意这与 OpenAI 官方默认的 `auto` 不同，且本接口**不支持** `auto` —— 计价需要在请求前就确定档位。

`high`、`xhigh`、`max` 会消耗更多积分且耗时明显增加；`low` 与 `medium` 按基础价计费。详见定价页。



### background

- **Type:** string
- **Required:** 可选

背景处理方式。仅 `chat_image_2.5_flare` 与 `chat_image_2.5_sunburst` 支持，取值为 `auto`、`opaque`、`transparent` 之一。

不传则由模型自行决定。其它模型传入会被忽略而非报错，请求照常成功，但背景仍由模型决定。

`transparent` 必须搭配 `output_format=png`。JPEG 不支持 alpha 通道，两者同时传入会直接报错，而不是悄悄把透明背景压平。


### aspect_ratio

- **Type:** string
- **Required:** 可选
- **Default:** `1:1`

输出宽高比。不传时默认 `1:1`（仅 banana 系列；当 `size` 与 `aspect_ratio` 均未传时由 gateway 填充）。
- `banana` / `banana_pro`：`1:1`、`2:3`、`3:2`、`3:4`、`4:3`、`4:5`、`5:4`、`9:16`、`16:9`、`21:9`。
- `banana2` 额外支持 `1:8`、`1:4`、`4:1`、`8:1`。
仅 **banana** 系列支持此字段；seedream / chat_image 按 `size` 出图，请改用 `size` 参数。

### output_format

- **Type:** string
- **Required:** 可选
- **Default:** `png`

输出图像格式。
- `png`：无损，支持透明度。
- `jpeg`：文件体积更小，不支持透明度。

### watermark

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

添加 AI 生成内容水印。仅对 seedream 系列生效；banana 系列会强制嵌入不可关闭的隐形水印，chat_image 系列不支持水印控制。
### template

- **Type:** string
- **Required:** 可选

生成模板。
- `asset_extraction`：从场景中提取主体。
- `character_completion`：补全不完整的角色。
- `t_pose`：生成 T-pose 姿态的角色。
- `variants`：生成设计变体。
- `figure`：生成全身人物。


## Request Example

### seedream_v5

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-image \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A high-fashion editorial portrait, dramatic studio lighting.",
  "model": "seedream_v5",
  "size": "2K",
  "output_format": "png",
  "watermark": false
}'
```

### banana

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-image \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A cinematic product render of a glass sneaker on a dark stage.",
  "model": "banana",
  "size": "1248x832",
  "output_format": "png"
}'
```

### banana_pro

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-image \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A cinematic product render of a glass sneaker on a dark stage.",
  "model": "banana_pro",
  "size": "2K",
  "aspect_ratio": "3:2",
  "output_format": "png"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_image",
    "status": "success",
    "progress": 100,
    "output": {
      "generated_image_url": "https://cdn.tripo3d.ai/output/image.png"
    },
    "credits_consumed": 20.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:00:08Z"
  }
}
```
