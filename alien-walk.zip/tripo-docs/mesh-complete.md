# 网格部件补全

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /mesh/complete`

补全分割的网格部件并修复缺失区域。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

`mesh/segment` 任务的 task_id，以 `task_` 开头。
### model

- **Type:** string
- **Required:** 可选
- **Default:** `v1.0-20250506`

补全模型版本。
- `v1.0-20250506`：默认（当前唯一版本）。

### part_names

- **Type:** string[]
- **Required:** 可选

要补全的部件名称列表。若省略，将补全所有部件。
### completion_mode

- **Type:** string
- **Required:** 可选
- **Default:** `ai_completion`

补全模式。
- `ai_completion`：AI 扩散补全（默认）。生成真实几何以填充缺失区域。
- `quick_cap`：快速封口。快速封闭开放边界，不使用 AI 生成。


## Request Example

### AI 补全

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/complete \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "part_names": [
    "head",
    "body"
  ]
}'
```

### 快速封口

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/complete \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "completion_mode": "quick_cap"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```
