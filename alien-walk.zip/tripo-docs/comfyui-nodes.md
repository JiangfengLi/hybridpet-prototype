# ComfyUI 节点

ComfyUI-Tripo 是 Tripo 官方提供的 ComfyUI 自定义节点扩展，可在 ComfyUI 工作流中通过文本、单张图片或多视图图片生成 3D 模型，并支持模型导入、贴图、精修、网格处理、低模化、风格化、绑骨、动画重定向、格式转换和重拓扑。

| 项目 | 值 |
| --- | --- |
| Node 项目版本 | <code>1.3.0</code> |
| 源码标签 | <code>v1.3.1.1</code> |
| 源码仓库 | [VAST-AI-Research/ComfyUI-Tripo](https://github.com/VAST-AI-Research/ComfyUI-Tripo) |

## 功能与变更记录

### 功能

- 根据文本提示生成 3D 模型。
- 根据图片生成 3D 模型。
- 通过 <code>model_url</code> 从 URL 导入模型。
- 支持模型拆件能力。
- 为 3D 模型绑骨并生成动画。
- 转换模型格式并重新拓扑。

### 变更记录

- 2026-06-30：新增 Mesh Segmentation v2.0 模型拆件，并支持通过 <code>model_url</code> 直接导入 URL。
- 2026-05-28：新增模型导入。
- 2025-06-19：更新到最新 API，并增加更多节点。
- 2025-03-31：改用 <code>tripo3d</code> 包。
- 2025-02-24：移除 <code>glbviewer</code>。
- 2025-02-01：适配新版 API，并改用 Preview 3D 查看模型。
- 2024-11-11：适配新版 API。
- 2024-10-14：新增模型转换。
- 2024-09-13：支持 <code>model_version</code> <code>v2.0-20240919</code>。

## 安装方式

**任选一种**方式安装，完成后重启 ComfyUI。

### ComfyUI-Manager

打开 [Custom Nodes Manager](https://github.com/ltdrdata/ComfyUI-Manager)，搜索 <code>Tripo for ComfyUI</code> 并安装。

### comfy-cli

通过 [Comfy Registry](https://registry.comfy.org/) 安装 [comfy-cli](https://github.com/Comfy-Org/comfy-cli)，然后执行：

~~~bash
comfy node registry-install comfyui-tripo
~~~

### 从源码安装

将仓库放到 <code>ComfyUI/custom_nodes/ComfyUI-Tripo</code>，然后安装依赖：

~~~bash
cd ComfyUI/custom_nodes
git clone https://github.com/VAST-AI-Research/ComfyUI-Tripo.git
python -m pip install -r ComfyUI-Tripo/requirements.txt
~~~

## API Key 配置

先在 [Tripo 平台](https://platform.tripo3d.ai/)创建 API Key，再使用以下任一方式配置。

节点项目按以下顺序获取 API Key：

1. 节点中非空的 <code>apikey</code> 输入。
2. <code>TRIPO_API_KEY</code> 环境变量。
3. ComfyUI-Tripo 项目目录中 <code>config.json</code> 的 <code>TRIPO_API_KEY</code> 字段。

Generate 和 Import 节点提供 <code>apikey</code> 输入；下游节点通过 <code>MODEL_INFO</code> 接收已经解析的 Key。

不得在截图、共享工作流、日志或代码仓库中暴露真实 API Key。共享工作流前应清空 <code>apikey</code>，本地使用优先选择环境变量。

### 环境变量启动示例

Windows：

~~~shell
set TRIPO_API_KEY=tsk_XXXXXXX
python.exe main.py [--cpu]
~~~

Linux 或 macOS：

~~~bash
TRIPO_API_KEY=tsk_XXXXXXX python main.py [--cpu]
~~~

## 节点总览

ComfyUI-Tripo 提供以下 11 个 Tripo 节点：

| 内部 ID | 界面名称 | 能力 | 输出 |
| --- | --- | --- | --- |
| <code>TripoAPIDraft</code> | Tripo: Generate model | 文本、图片或多视图生成模型 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoImportModel</code> | Tripo: Import model | 导入本地模型或模型 URL | <code>MODEL_INFO</code> |
| <code>TripoTextureModel</code> | Tripo: Texture model | 模型贴图 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoRefineModel</code> | Tripo: Refine Draft model | 草模精修 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoMeshSegmentation</code> | Tripo: Segment mesh | 网格分割 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoMeshCompletion</code> | Tripo: Complete mesh | 网格补全 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoSmartLowPoly</code> | Tripo: Smart low poly | 智能低模 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoStylizeModel</code> | Tripo: Stylize model | 模型风格化 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoAnimateRigNode</code> | Tripo: Rig model | 自动绑骨 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoAnimateRetargetNode</code> | Tripo: Retarget rigged model | 动画重定向 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoConvertNode</code> | Tripo: Convert model | 模型格式转换与导出 | <code>model_file</code> |

Preview 3D 是 ComfyUI 提供的预览节点，不计入以上 11 个 Tripo Node。

## 节点连接与数据流

~~~mermaid
flowchart LR
    G["Generate model"] -->|MODEL_INFO| P["模型处理"]
    I["Import model"] -->|MODEL_INFO| P
    P -->|MODEL_INFO| R["Rig model"]
    R -->|MODEL_INFO| A["Retarget rigged model"]
    A -->|MODEL_INFO| C["Convert model"]
~~~

- <code>model_file</code> 是生成或处理任务下载后的文件路径，可连接 ComfyUI 的预览或文件处理节点。
- <code>MODEL_INFO</code> 是下游 Tripo Node 使用的任务上下文，包含 <code>task_id</code>、解析后的 <code>apikey</code>、<code>file_prefix</code> 和 <code>output_directory</code>。
- 来自节点链外部的普通模型必须先经过 <code>TripoImportModel</code>；单独的文件路径不能替代 <code>MODEL_INFO</code>。
- 需要继续执行 Tripo 处理时应连接 <code>MODEL_INFO</code>，而不是把 <code>model_file</code> 当作任务上下文。

## 完整节点参数

“必填”表示节点参数是否必须提供；<code>apikey</code> 可留空以使用环境变量或配置文件回退。“—”表示没有显式默认值。

### 生成与导入

### TripoAPIDraft — Tripo: Generate model

创建工作流中的第一个 Tripo 任务，无前置节点。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>mode</code> | ENUM | 是 | 第一个枚举值 | <code>text_to_model</code>、<code>image_to_model</code>、<code>multiview_to_model</code> |
| <code>apikey</code> | STRING | 是 | 空 | API Key 或回退配置 |
| <code>prompt</code> | STRING，多行 | 否 | 空 | 文本提示词 |
| <code>negative_prompt</code> | STRING，多行 | 否 | 空 | 负向提示词 |
| <code>image</code> | IMAGE | 否 | — | 单图输入；多视图模式下为正面图 |
| <code>image_left</code> | IMAGE | 否 | — | 可选左视图 |
| <code>image_back</code> | IMAGE | 否 | — | 可选后视图 |
| <code>image_right</code> | IMAGE | 否 | — | 可选右视图 |
| <code>model_version</code> | ENUM | 否 | <code>v3.1-20260211</code> | <code>v1.4-20240625</code>、<code>v2.0-20240919</code>、<code>v2.5-20250123</code>、<code>v3.0-20250812</code>、<code>v3.1-20260211</code> |
| <code>texture</code> | BOOLEAN | 否 | <code>true</code> | 是否生成贴图 |
| <code>pbr</code> | BOOLEAN | 否 | <code>true</code> | 是否生成 PBR 贴图 |
| <code>image_seed</code> | INT | 否 | <code>42</code> | 文本模式使用的图像种子 |
| <code>model_seed</code> | INT | 否 | <code>42</code> | 模型种子 |
| <code>texture_seed</code> | INT | 否 | <code>42</code> | 贴图种子 |
| <code>texture_quality</code> | ENUM | 否 | <code>standard</code> | <code>standard</code>、<code>detailed</code> |
| <code>geometry_quality</code> | ENUM | 否 | <code>standard</code> | <code>standard</code>、<code>detailed</code>；仅图片模式 |
| <code>texture_alignment</code> | ENUM | 否 | <code>original_image</code> | <code>original_image</code>、<code>geometry</code> |
| <code>face_limit</code> | INT | 否 | <code>-1</code> | <code>-1</code>–<code>500000</code>；小于等于 0 时按未设置传递 |
| <code>quad</code> | BOOLEAN | 否 | <code>false</code> | 是否请求四边面拓扑 |
| <code>compress</code> | BOOLEAN | 否 | <code>false</code> | 是否压缩输出 |
| <code>generate_parts</code> | BOOLEAN | 否 | <code>false</code> | 是否生成部件 |
| <code>smart_low_poly</code> | BOOLEAN | 否 | <code>false</code> | 是否启用智能低模 |
| <code>auto_size</code> | BOOLEAN | 否 | <code>false</code> | 是否自动调整模型尺寸 |
| <code>orientation</code> | ENUM | 否 | <code>default</code> | <code>default</code>、<code>align_image</code>；图片和多视图模式 |
| <code>file_prefix</code> | STRING | 否 | 空 | 下载文件名前缀 |
| <code>output_directory</code> | STRING | 否 | 空 | 目标目录覆盖值 |

模式限制：

| 模式 | 条件必填输入 | 说明 |
| --- | --- | --- |
| <code>text_to_model</code> | <code>prompt</code> | 为空时提示 “Prompt is required” |
| <code>image_to_model</code> | <code>image</code> | 缺失时提示 “Image is required” |
| <code>multiview_to_model</code> | <code>image</code> | <code>image</code> 是正面图；左、后、右视图可选 |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。常见失败：条件输入缺失、API Key 缺失或无效、API 任务失败、输出文件移动失败。最小连接：提示词或图片 → <code>TripoAPIDraft</code> → Preview 3D；需要后处理时连接 <code>MODEL_INFO</code>。

### TripoImportModel — Tripo: Import model

为不在当前节点链中产生的模型建立 Tripo 任务上下文。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>apikey</code> | STRING | 是 | 空 | API Key 或回退配置 |
| <code>model_file</code> | 文件选择 | 否 | <code>none</code> | ComfyUI 输入目录中的模型 |
| <code>model_url</code> | STRING | 否 | 空 | 模型直链 |
| <code>file_prefix</code> | STRING | 否 | 空 | 传递给下游下载文件的前缀 |
| <code>output_directory</code> | STRING | 否 | 空 | 传递给下游下载文件的目录 |

非空 <code>model_url</code> 的优先级高于 <code>model_file</code>；二者都为空时节点失败。上传控件接受 <code>.glb</code>、<code>.fbx</code>、<code>.obj</code>、<code>.stl</code>、<code>.ply</code>、<code>.3mf</code> 和 <code>.gltf</code>，后端输入扫描还识别 <code>.zip</code>。

输出：仅 <code>MODEL_INFO</code>。常见失败：没有提供来源、本地文件不存在、URL 无法获取、格式被拒绝或导入任务失败。最小连接：本地文件或 URL → <code>TripoImportModel</code> → 任意接收 <code>MODEL_INFO</code> 的处理节点。

### 模型处理

### TripoTextureModel — Tripo: Texture model

需要来自 Generate、Import 或兼容处理节点的 <code>MODEL_INFO</code>。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>model_version</code> | ENUM | 否 | <code>v3.0-20250812</code> | <code>v2.5-20250123</code>、<code>v3.0-20250812</code> |
| <code>texture</code> | BOOLEAN | 否 | <code>true</code> | 是否启用贴图 |
| <code>pbr</code> | BOOLEAN | 否 | <code>true</code> | 是否生成 PBR 贴图 |
| <code>texture_seed</code> | INT | 否 | <code>42</code> | 贴图种子 |
| <code>texture_quality</code> | ENUM | 否 | <code>standard</code> | <code>standard</code>、<code>detailed</code> |
| <code>texture_alignment</code> | ENUM | 否 | <code>original_image</code> | <code>original_image</code>、<code>geometry</code> |
| <code>text_prompt</code> | STRING，多行 | 否 | 空 | 贴图引导文本 |
| <code>image_prompt</code> | IMAGE | 否 | — | 贴图参考图 |
| <code>style_image</code> | IMAGE | 否 | — | 风格参考图 |
| <code>part_names</code> | STRING，多行 | 否 | 空 | 每行一个部件名 |
| <code>compress</code> | BOOLEAN | 否 | <code>false</code> | 是否压缩输出 |
| <code>bake</code> | BOOLEAN | 否 | <code>true</code> | 是否烘焙贴图 |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。常见失败：任务上下文不兼容、参考图无效或 API 任务失败。最小连接：Generate/Import 的 <code>MODEL_INFO</code> → <code>TripoTextureModel</code> → Preview 3D 或其他处理节点。

### TripoRefineModel — Tripo: Refine Draft model

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 草模任务上下文 |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。上游任务必须是可精修的草模；上下文不兼容或 API 任务失败都会导致失败。最小连接：Generate 草模的 <code>MODEL_INFO</code> → <code>TripoRefineModel</code> → Preview 3D。

### TripoMeshSegmentation — Tripo: Segment mesh

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>model_version</code> | ENUM | 是 | <code>v1.0-20250506</code> | <code>v1.0-20250506</code>、<code>v2.0-20260430</code> |
| <code>segmentation_granularity</code> | ENUM | 否 | <code>balanced</code> | <code>simple</code>、<code>balanced</code>、<code>detailed</code> |
| <code>ref_image</code> | IMAGE | 否 | — | 分割参考图 |
| <code>split_by_connectivity</code> | BOOLEAN | 否 | <code>true</code> | 是否按连通性拆分 |

<code>segmentation_granularity</code>、<code>ref_image</code> 和 <code>split_by_connectivity</code> 只在 <code>v2.0-20260430</code> 下发送，v1 会忽略它们。输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。常见失败：模型不兼容、参考图无效或 API 任务失败。最小连接：Generate/Import 的 <code>MODEL_INFO</code> → <code>TripoMeshSegmentation</code> → Completion 或 Preview 3D。

### TripoMeshCompletion — Tripo: Complete mesh

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 分割模型任务上下文 |
| <code>model_version</code> | ENUM | 是 | <code>v1.0-20250506</code> | <code>v1.0-20250506</code> |
| <code>part_names</code> | STRING，多行 | 否 | 空 | 每行一个部件名 |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。任务不适合补全或 API 任务失败会导致失败。最小连接：Segment 的 <code>MODEL_INFO</code> → <code>TripoMeshCompletion</code> → Preview 3D。

### TripoSmartLowPoly — Tripo: Smart low poly

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>model_version</code> | ENUM | 是 | <code>P-v2.0-20251225</code> | <code>P-v2.0-20251225</code> |
| <code>quad</code> | BOOLEAN | 否 | <code>false</code> | 是否请求四边面拓扑 |
| <code>part_names</code> | STRING，多行 | 否 | 空 | 每行一个部件名 |
| <code>face_limit</code> | INT | 否 | <code>10000</code> | <code>-1</code>–<code>20000</code> |
| <code>bake</code> | BOOLEAN | 否 | <code>true</code> | 是否烘焙输出 |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。常见失败：模型或部件不兼容、API 任务失败。最小连接：Generate/Import 的 <code>MODEL_INFO</code> → <code>TripoSmartLowPoly</code> → Preview 3D 或 Convert。

### TripoStylizeModel — Tripo: Stylize model

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>style</code> | ENUM | 是 | 第一个枚举值 | <code>lego</code>、<code>voxel</code>、<code>voronoi</code>、<code>minecraft</code> |
| <code>block_size</code> | INT | 是 | <code>80</code> | <code>1</code>–<code>1000</code> |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。常见失败：模型不兼容、当前任务不支持指定风格或 API 任务失败。最小连接：Generate/Import 的 <code>MODEL_INFO</code> → <code>TripoStylizeModel</code> → Preview 3D。

### 绑骨与动画

### TripoAnimateRigNode — Tripo: Rig model

提交绑骨任务前，节点会先检查模型能否绑骨并获取 rig type。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>model_version</code> | ENUM | 是 | <code>v2.0-20250506</code> | <code>v1.0-20240301</code>、<code>v2.0-20250506</code> |
| <code>out_format</code> | ENUM | 是 | <code>glb</code> | <code>glb</code>、<code>fbx</code> |
| <code>spec</code> | ENUM | 是 | <code>tripo</code> | <code>mixamo</code>、<code>tripo</code> |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。模型不可绑骨、找不到合适的 rig type 或 API 任务失败时会终止。最小连接：Generate/Import 的 <code>MODEL_INFO</code> → <code>TripoAnimateRigNode</code> → Retarget 或 Preview 3D。

### TripoAnimateRetargetNode — Tripo: Retarget rigged model

需要已经成功绑骨的模型对应的 <code>MODEL_INFO</code>。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 已绑骨模型的任务上下文 |
| <code>animation</code> | ENUM | 是 | 第一个枚举值 | 见下方 16 个预设 |
| <code>out_format</code> | ENUM | 是 | <code>glb</code> | <code>glb</code>、<code>fbx</code> |
| <code>bake_animation</code> | BOOLEAN | 否 | <code>true</code> | 是否烘焙动画 |
| <code>export_with_geometry</code> | BOOLEAN | 否 | <code>false</code> | 导出时是否包含几何体 |

16 个动画枚举为：<code>preset:idle</code>、<code>preset:walk</code>、<code>preset:run</code>、<code>preset:dive</code>、<code>preset:climb</code>、<code>preset:jump</code>、<code>preset:slash</code>、<code>preset:shoot</code>、<code>preset:hurt</code>、<code>preset:fall</code>、<code>preset:turn</code>、<code>preset:quadruped:walk</code>、<code>preset:hexapod:walk</code>、<code>preset:octopod:walk</code>、<code>preset:serpentine:march</code> 和 <code>preset:aquatic:march</code>。

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。模型未绑骨、上下文不兼容或 API 任务失败会导致失败。最小连接：Rig 的 <code>MODEL_INFO</code> → <code>TripoAnimateRetargetNode</code> → Preview 3D 或 Convert。

### 格式输出

### TripoConvertNode — Tripo: Convert model

这是一个输出节点，不返回 <code>MODEL_INFO</code>。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>format</code> | ENUM | 是 | 第一个枚举值 | <code>GLTF</code>、<code>USDZ</code>、<code>FBX</code>、<code>OBJ</code>、<code>STL</code>、<code>3MF</code> |
| <code>quad</code> | BOOLEAN | 否 | <code>false</code> | 是否请求四边面拓扑 |
| <code>force_symmetry</code> | BOOLEAN | 否 | <code>false</code> | 是否强制对称 |
| <code>face_limit</code> | INT | 否 | <code>-1</code> | <code>-1</code>–<code>500000</code> |
| <code>flatten_bottom</code> | BOOLEAN | 否 | <code>false</code> | 是否压平底部 |
| <code>flatten_bottom_threshold</code> | FLOAT | 否 | <code>0.01</code> | <code>0.0</code>–<code>1.0</code> |
| <code>texture_size</code> | INT | 否 | <code>4096</code> | <code>128</code>–<code>4096</code> |
| <code>texture_format</code> | ENUM | 否 | <code>JPEG</code> | <code>BMP</code>、<code>DPX</code>、<code>HDR</code>、<code>JPEG</code>、<code>OPEN_EXR</code>、<code>PNG</code>、<code>TARGA</code>、<code>TIFF</code>、<code>WEBP</code> |
| <code>pivot_to_center_bottom</code> | BOOLEAN | 否 | <code>false</code> | 是否把轴心移动到中心底部 |
| <code>scale_factor</code> | FLOAT | 否 | <code>1.0</code> | 最小值 <code>0</code> |
| <code>with_animation</code> | BOOLEAN | 否 | <code>true</code> | 是否保留动画 |
| <code>pack_uv</code> | BOOLEAN | 否 | <code>false</code> | 是否打包 UV |
| <code>bake</code> | BOOLEAN | 否 | <code>true</code> | 是否烘焙输出 |
| <code>part_names</code> | STRING，多行 | 否 | 空 | 每行一个部件名 |
| <code>fbx_preset</code> | ENUM | 否 | <code>blender</code> | <code>blender</code>、<code>mixamo</code>、<code>3dsmax</code> |
| <code>export_vertex_colors</code> | BOOLEAN | 否 | <code>false</code> | 是否导出顶点色 |
| <code>export_orientation</code> | ENUM | 否 | <code>+x</code> | <code>+x</code>、<code>+y</code>、<code>-x</code>、<code>-y</code> |
| <code>animate_in_place</code> | BOOLEAN | 否 | <code>false</code> | 是否原地导出动画 |

输出：STRING <code>model_file</code>。常见失败：源任务不支持目标转换、导出设置无效、API 任务或输出移动失败。最小连接：任意兼容的 <code>MODEL_INFO</code> → <code>TripoConvertNode</code>。

## 工作流示例

Preview 3D 仅作为可选的 ComfyUI 查看器，不计入 Tripo 节点数量。

~~~mermaid
flowchart LR
    T["文本"] --> GT["Generate model<br/>mode: text_to_model"]
    IM["图片"] --> GI["Generate model<br/>mode: image_to_model"]
    MV["正面图 + 可选视图"] --> GM["Generate model<br/>mode: multiview_to_model"]
    GT --> V["Preview 3D"]
    GI --> V
    GM --> V
~~~

1. **Text to Model：** 填写 <code>prompt</code>，选择 <code>text_to_model</code>，把 <code>model_file</code> 连接到 Preview 3D。
2. **Image to Model：** 将 IMAGE 连接到 <code>image</code>，选择 <code>image_to_model</code>，预览 <code>model_file</code>。
3. **Multiview to Model：** 正面图连接 <code>image</code>，可选视图依次连接 <code>image_left</code>、<code>image_back</code> 和 <code>image_right</code>。
4. **Texture Model：** Generate 或 Import → 用 <code>MODEL_INFO</code> 连接 Texture → 预览新的 <code>model_file</code>。
5. **Refine Model：** 生成兼容草模 → 用 <code>MODEL_INFO</code> 连接 Refine → 预览精修文件。
6. **Rig and Retarget：** Generate 或 Import → Rig → Retarget；两段都连接 <code>MODEL_INFO</code>，最后预览或 Convert。
7. **Import and Process：** 本地文件或 URL → Import → Segment/Smart low poly/Stylize/Texture。Import 返回任务上下文，不返回预览文件。
8. **Convert and Export：** 把 Generate、Import、模型处理、Rig 或 Retarget 最终输出的 <code>MODEL_INFO</code> 连接到 Convert，并选择输出格式。

### 官方工作流 PNG

以下 6 张 PNG 包含内嵌的 ComfyUI 工作流数据。通过下载链接保存原始 PNG 后，可以将文件拖入 ComfyUI 或手动加载。截图中的参数值仅为工作流示例，实际默认值请查看上方参数表。

#### Text to Mesh

![Tripo Generate model 连接 Preview 3D 的 ComfyUI 文本生成模型工作流](/assets/images/docs/comfyui-nodes/text_to_model.png)

根据文本提示生成模型，并把 <code>model_file</code> 连接到 Preview 3D。

<a href="/assets/images/docs/comfyui-nodes/text_to_model.png" download>下载原始工作流 PNG</a>

#### Image to Mesh

![Load Image、Tripo Generate model 和 Preview 3D 组成的 ComfyUI 图片生成模型工作流](/assets/images/docs/comfyui-nodes/image_to_model.png)

加载图片，将其连接到 <code>image_to_model</code> 模式的 Generate model，并预览结果。

<a href="/assets/images/docs/comfyui-nodes/image_to_model.png" download>下载原始工作流 PNG</a>

#### Multiview Images to Mesh

![三个 Load Image 节点连接 Tripo Generate model 和 Preview 3D 的 ComfyUI 多视图工作流](/assets/images/docs/comfyui-nodes/multiview_to_model.png)

把正面图和可选侧视图连接到 <code>multiview_to_model</code> 模式的 Generate model。

<a href="/assets/images/docs/comfyui-nodes/multiview_to_model.png" download>下载原始工作流 PNG</a>

#### Texture a generated model

![Generate model 连接 Texture model 并分别连接 Preview 3D 的 ComfyUI 贴图工作流](/assets/images/docs/comfyui-nodes/texture_model.png)

把 Generate model 的 <code>MODEL_INFO</code> 传给 Texture model，并预览处理前后的输出。

<a href="/assets/images/docs/comfyui-nodes/texture_model.png" download>下载原始工作流 PNG</a>

#### Refine a draft Mesh

![草模 Generate model 任务连接 Refine Draft model 和 Preview 3D 的 ComfyUI 精修工作流](/assets/images/docs/comfyui-nodes/refine_model.png)

生成兼容草模，把 <code>MODEL_INFO</code> 传给 Refine Draft model，并预览精修后的文件。

<a href="/assets/images/docs/comfyui-nodes/refine_model.png" download>下载原始工作流 PNG</a>

#### Animation / Rig and export

![Generate model、Rig model、Preview 3D 和 Convert model 组成的 ComfyUI 绑骨与导出工作流](/assets/images/docs/comfyui-nodes/retarget.png)

<a href="/assets/images/docs/comfyui-nodes/retarget.png" download>下载原始工作流 PNG</a>

## 输出与排障

默认情况下，下载的模型写入 <code>ComfyUI/output</code>。Generate 和 Import 确定 <code>file_prefix</code> 与 <code>output_directory</code>，并通过下游 <code>MODEL_INFO</code> 持续传递。非空前缀会添加到下载文件名开头；非空目录会把文件移动到该目录，目录不存在时会尝试创建。

| 现象 | 检查项 |
| --- | --- |
| <code>TRIPO API key is required</code> | 设置非空节点 Key、<code>TRIPO_API_KEY</code> 或 <code>config.json</code> 中的字段。 |
| 提示缺少 Prompt/正面图 | 检查 <code>mode</code> 与条件必填输入是否匹配。 |
| Import 不启动 | 提供可访问的 <code>model_url</code> 或存在的 <code>model_file</code>；URL 优先。 |
| 模型不可绑骨 | 改用适合的角色模型；riggable 检查失败或没有 rig type 时 Rig 会终止。 |
| API 任务失败 | 查看返回的 <code>error_code</code> 和 <code>error_msg</code>，同时检查账号权限与余额。 |
| 输出无法移动 | 检查 <code>output_directory</code> 是否有效、可写，以及源文件是否仍然存在。 |
| 节点没有出现 | 重启 ComfyUI，核对仓库目录，并安装 <code>requirements.txt</code>。 |
| Import 上传按钮失败 | 核对上传控件支持的扩展名，并查看 ComfyUI 上传响应。 |
