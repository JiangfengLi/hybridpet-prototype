# 重拓扑

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /mesh/decimate`

通过两种算法减少模型面数。使用 model=v2.0（默认）进行智能低模重拓扑，保留干净拓扑结构；使用 model=v1.0 进行基础减面。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型来源。接受 task_id 或 file_token。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前 3D 生成任务（`text_to_model`、`image_to_model` 或 `multiview_to_model`）返回的任务 ID。系统会自动使用该任务的 3D 模型输出。
示例： `task_abc123`
- file_token：先通过文件上传 API上传 3D 模型文件，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的 3D 模型文件直链。
示例： `https://example.com/model.glb`



- 支持格式：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`
- 最大文件大小：**150 MB**

### model

- **Type:** string
- **Required:** 可选
- **Default:** `v2.0`

重拓扑算法版本。
### face_limit

- **Type:** integer
- **Required:** 条件必填

目标面数。
### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

输出四边面网格。v1.0 和 v2.0 均支持。
### bake

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`
- **Note:** v1.0 不支持该参数。

将贴图烘焙到低面数模型上。
### part_names

- **Type:** string[]
- **Required:** 可选
- **Note:** v1.0 不支持该参数。

要减面的部件名称（来自语义分割）。

## Request Example

### v2.0 智能重拓扑

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/decimate \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "model": "v2.0",
  "face_limit": 5000,
  "quad": false,
  "bake": true
}'
```

### v1.0 基础减面

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/decimate \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "model": "v1.0",
  "face_limit": 3000
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```
