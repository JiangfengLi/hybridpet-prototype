# 编辑多视图

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/edit-multiview`

编辑现有的多视图图像。在所有视图间应用一致的修改。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

要编辑的多视图源图像。接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前多视图生成任务返回的任务 ID。系统会自动使用输出的多视图图像。如需先生成多视图图像，请使用 图像生成多视图 API。
示例： `task_abc123`
- file_token：先通过文件上传 API上传多视图图像。
示例： `file_abc123`
- URL：可公开访问的多视图图像直链。
示例： `https://example.com/multiview.png`

### prompts

- **Type:** object[]
- **Required:** 必选

编辑指令列表，每条指令针对一个特定视角。每个元素包含：
- prompt：描述所需变更的编辑指令。
示例： `将衬衫颜色改为红色`
- view：要应用编辑的视角。
- `front`：正面
- `left`：左侧
- `back`：背面
- `right`：右侧



## Request Example

### 编辑视图

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/edit-multiview \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "prompts": [
    {
      "prompt": "change the shirt color to red",
      "view": "front"
    },
    {
      "prompt": "add a logo on the back",
      "view": "back"
    }
  ]
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```
