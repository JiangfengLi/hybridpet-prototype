# 计费说明

## 积分制

Tripo API 采用积分（Credits）计费。不同任务类型消耗不同数量的积分。

## 积分冻结/扣除模型

| 阶段 | 说明 |
| :-: | :-: |
| 创建任务 | 从可用余额中冻结对应积分 |
| 任务成功 | 冻结积分转为已消耗，正式扣除 |
| 任务失败 | 冻结积分退回可用余额 |
| 任务取消 | 冻结积分退回可用余额 |

失败和取消的任务不收费。

## 查询余额

> **GET** `/v3/account/balance`

### curl

```bash
curl -X GET https://openapi.tripo3d.com/v3/account/balance \
  -H "Authorization: Bearer {api_key}"
```

### Python

```python
import requests

url = "https://openapi.tripo3d.com/v3/account/balance"
headers = {
    "Authorization": "Bearer {api_key}"
}

response = requests.get(url, headers=headers)
print(response.json())
```

### JavaScript

```javascript
const response = await fetch("https://openapi.tripo3d.com/v3/account/balance", {
  headers: {
    "Authorization": "Bearer {api_key}"
  }
});

const data = await response.json();
console.log(data);
```

### 响应示例

```json
{
  "code": 0,
  "data": {
    "balance": 10000.00,
    "frozen": 200.00
  }
}
```

| 字段 | 类型 | 说明 |
| :-: | :-: | :-: |
| balance | number | 可用积分余额 |
| frozen | number | 冻结积分（进行中的任务预扣） |

## 查看用量

> **GET** `/v3/account/usage`

### curl

```bash
curl -X GET https://openapi.tripo3d.com/v3/account/usage \
  -H "Authorization: Bearer {api_key}"
```

### Python

```python
import requests

url = "https://openapi.tripo3d.com/v3/account/usage"
headers = {
    "Authorization": "Bearer {api_key}"
}

response = requests.get(url, headers=headers)
print(response.json())
```

### JavaScript

```javascript
const response = await fetch("https://openapi.tripo3d.com/v3/account/usage", {
  headers: {
    "Authorization": "Bearer {api_key}"
  }
});

const data = await response.json();
console.log(data);
```

### 响应示例

```json
{
  "code": 0,
  "data": [
    {
      "task_id": "task_abc123",
      "type": "text_to_model",
      "credits_consumed": 100.00,
      "created_at": "2026-01-01T00:00:00Z"
    }
  ]
}
```

| 字段 | 类型 | 说明 |
| :-: | :-: | :-: |
| task_id | string | 任务唯一标识 |
| type | string | 任务类型 |
| credits_consumed | number | 消耗积分 |
| created_at | string | 创建时间（ISO 8601） |
