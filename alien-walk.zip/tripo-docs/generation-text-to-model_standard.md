# 文本生成 3D 模型 — H 系列

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/text-to-model`

根据文本提示词生成 3D 模型。生成几何体、可选贴图和可选 PBR 材质贴图。

## Request Parameters

### prompt

- **Type:** string
- **Required:** 必选

文本提示词，最多 1024 个字符。描述形状、材质、风格和尺寸。


- 好的示例："一个低面数中世纪木质宝箱，带有铁铰链和生锈的锁。"
- 差的示例："一个箱子。"
- 加入材质和风格描述可提升 PBR 贴图效果。

### model

- **Type:** string
- **Required:** 必选

AI 模型版本。
- `v3.1-20260211`：最新版，最佳质量。
- `v3.0-20250812`：稳定版，高级功能。
- `v2.5-20250123`：均衡版。

### negative_prompt

- **Type:** string
- **Required:** 可选

反向提示词，最多 255 个字符。描述不希望在生成模型中出现的内容。例如："blurry, low quality, broken mesh"。
### model_seed

- **Type:** integer
- **Required:** 可选

几何体生成的随机种子。使用相同种子和相同输入将生成相同的 3D 网格。若未设置，每次会使用随机种子。
### image_seed

- **Type:** integer
- **Required:** 可选

内部文本转图像阶段的随机种子。控制从文本提示词生成的参考图像，然后再进行 3D 转换。若未设置，每次会使用随机种子。
### face_limit

- **Type:** integer
- **Required:** 可选

输出网格的最大面数。


- 省略时模型使用自适应拓扑。
各模式面数上限
| 模式 | 标准 | 超清 | 
| 纯三角面 — v3.1 | **1,500,000** | **2,000,000** | 
| 纯三角面 — v3.0 | **1,000,000** | **2,000,000** | 
| 纯三角面 — v2.5 | **500,000** | / | 
| 四边面（`quad: true`） | **150,000** | 


- 游戏资产推荐：**50,000 – 100,000**。Web/移动端：**10,000 – 50,000**。
- 开启 `smart_low_poly: true` 时，面数限制与模型版本无关，统一为： 三角面 **500 – 20,000**，四边面 **500 – 10,000**。

### texture

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

是否为模型生成贴图。设为 false 可获取无贴图的纯几何体。默认为 true。
### pbr

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

启用 PBR 材质贴图（`base_color`、`metallic`、`roughness`、`normal`）。当 `pbr` 设为 `true` 时，`texture` 会自动强制设为 `true`。

### texture_seed

- **Type:** integer
- **Required:** 可选

贴图生成的随机种子。使用相同种子将生成相同的贴图。若未设置，每次会使用随机种子。如需获取相同几何体但不同贴图的模型，请保持 model_seed 不变并更改 texture_seed。
### texture_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

贴图质量等级。
- `fast`：生成最快，以细节换速度；输出贴图尺寸与 `standard` 相同。 需要贴图版本 `v3.5-20260815`；积分与 `standard` 相同。
- `standard`：质量与速度的平衡。
- `detailed`：更高保真度，生成速度较慢。
- `extreme`：8K 贴图，最高保真度。相比 detailed 额外消耗积分。


`fast` 仅在贴图版本 `v3.5-20260815` 下可用。生成接口需将 `texture_version` 设为该版本；`/v3/models/texture` 则是 `model`。其它贴图版本会返回 `1004`，不会静默回退到 `standard`。
### texture_version

- **Type:** string
- **Required:** 可选

独立指定贴图模型，与几何体 `model` 解耦。
- `v3.5-20260815`：最新贴图模型。使用 `texture_quality=fast` 与 `delight` 时必填。
- `v3.0-20250812`：`v3.x` 与 P 系列几何体的默认值。
- `v2.5-20250123`：`v2.5-20250123` 几何体的默认值。
省略时按上表根据几何体 `model` 自动推导。
### delight

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

贴图前去除参考图中的光照信息。设为 `false` 可保留原有明暗。仅 `v3.5-20260815` 贴图模型支持，更早的贴图版本会忽略该参数。
### geometry_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

几何体质量等级。
- `standard`：质量与速度的平衡。
- `detailed`：Ultra 模式，更精细的几何细节。
该参数只对 v3.0 以上模型版本生效，v2.5 切勿使用该参数。

### auto_size

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否自动将生成的模型缩放至真实世界尺寸。启用后，模型尺寸将以米为单位，适用于 AR/VR 或游戏引擎场景。默认为 false。
### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否输出四边面网格（四边形多边形）而非三角面。若未设置 `face_limit`，默认面数为 10,000。启用 `quad` 会强制输出格式为 `FBX`。

### smart_low_poly

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否生成具有手工风格、干净拓扑的低面数模型。最适合简单、非复杂的输入。复杂模型可能偶尔失败。默认为 false。
### generate_parts

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

生成可编辑的分割部件。与 `texture`、`pbr`、`quad`、`smart_low_poly` 不兼容：
- `texture=true` 或 `pbr=true`（包括不传 `texture`，其默认值为 `true`）—— 请求被拒绝，返回错误码 `1004`。
- `quad=true` —— quad 被忽略，返回的分块为三角面网格。
- `smart_low_poly=true` —— smart_low_poly 优先，不会产出分块。
如需生成分块，请设置 `texture=false` 与 `pbr=false`，且不要传 `quad` 与 `smart_low_poly`。


### compress

- **Type:** string
- **Required:** 可选

压缩类型。
- `geometry`：meshopt 压缩，减小文件体积。



- 以下参数仅在 `model ≥ v3.0-20250812` 时有效：`texture_quality`、`geometry_quality`、`auto_size`、`quad`、`smart_low_poly`、`generate_parts`、`compress`。

### export_orientation

- **Type:** string
- **Required:** 可选
- **Default:** `+x`

导出朝向（前向轴）。
- `+x`：默认，X 轴正方向朝前。
- `-x`：X 轴负方向朝前。
- `-y`：Y 轴负方向朝前。
- `+y`：Y 轴正方向朝前。



- 仅作用于本次生成。如需用于后续的贴图、绑定、重定向、格式转换等后处理任务，不建议设置该参数。
- 设置该参数后，用于其他后处理任务时，可能因模型方向错误影响最终效果，但任务状态仍为`success`、不会报错，请谨慎使用该参数。
- 若计划对模型做后处理，建议本参数留空，改为在最后一步用`/v3/models/convert` 转换朝向。

### export_uv

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

控制生成过程中的 UV 展开。设为 `false` 可加快生成速度并减小文件体积。UV 展开将在贴图阶段处理。

## Request Example

### 基础示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A cat wearing a spacesuit",
  "model": "v3.1-20260211",
  "texture": true,
  "pbr": true,
  "texture_quality": "detailed"
}'
```

### 进阶示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A futuristic sci-fi helmet with glowing blue visor.",
  "model": "v3.1-20260211",
  "face_limit": 80000,
  "geometry_quality": "detailed",
  "auto_size": true
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```
