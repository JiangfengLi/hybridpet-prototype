# 网格分割

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /mesh/segment`

对 3D 模型进行语义分割，自动拆分为各个部件。支持 v1（几何拓扑，默认）和 v2（语义标注 + 几何，Beta）。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型来源。接受 task_id、file_token 或 URL。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前 3D 生成任务（`text_to_model`、`image_to_model` 或 `multiview_to_model`）返回的任务 ID。系统会自动使用该任务的 3D 模型输出。
示例： `task_abc123`
- file_token：先通过文件上传 API上传 3D 模型文件，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的 3D 模型文件直链。
示例： `https://example.com/model.glb`



- 支持格式：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`
- 最大文件大小：**150 MB**

### model

- **Type:** string
- **Required:** 可选
- **Default:** `v1.0-20250506`

分割模型版本。
- `v1.0-20250506`：默认，基于几何拓扑的分割。
- `v2.0-20260430` Beta：语义标注 + 几何分割。

### segmentation_granularity

- **Type:** string
- **Required:** 可选
- **Default:** `balanced`

**仅 v2。**分割粒度。
- `simple`
- `balanced`：默认
- `detailed`

### split_by_connectivity

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

**仅 v2。**是否按连通域拆分。
### ref_image

- **Type:** string
- **Required:** 可选

**仅 v2。**辅助语义分析的参考图，接受 `file_token`（文件上传返回）或外部 URL。当传入 `ref_image` 时，`segmentation_granularity` 与 `split_by_connectivity` **无效**。
左：3D 模型 (.glb)  |  右：作为 `ref_image` 传入的分割 mask




## Request Example

### 分割示例 (v1)

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/segment \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123"
}'
```

### 分割示例 (v2 + 粒度)

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/segment \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "model": "v2.0-20260430",
  "input": "task_abc123",
  "segmentation_granularity": "balanced",
  "split_by_connectivity": true
}'
```

### 分割示例 (v2 + 参考图)

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/segment \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "model": "v2.0-20260430",
  "input": "task_abc123",
  "ref_image": "file_a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_def456",
    "type": "mesh_segmentation",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/mesh_seg.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/mesh_seg.webp"
    },
    "credits_consumed": 40.00,
    "created_at": "2026-05-27T02:22:56Z",
    "completed_at": "2026-05-27T02:25:33Z"
  }
}
```
