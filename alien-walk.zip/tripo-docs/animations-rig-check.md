# 可绑骨检查

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /animations/rig-check`

检查模型是否可以绑骨，并返回推荐的骨骼类型。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型来源。接受 task_id、file_token 或 URL。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前 3D 生成任务（`text_to_model`、`image_to_model` 或 `multiview_to_model`）返回的任务 ID。系统会自动使用该任务的 3D 模型输出。
示例： `task_abc123`
- file_token：先通过文件上传 API上传 3D 模型文件，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的 3D 模型文件直链。
示例： `https://example.com/model.glb`



- 支持格式：`GLB`
- 最大文件大小：**150 MB**


## Response Fields

### riggable

- **Type:** boolean
- **Required:** 必选

模型是否可绑骨。
### rig_type

- **Type:** string
- **Required:** 必选

推荐的骨骼类型。
- `biped`：双足人形。
- `quadruped`：四足动物。
- `hexapod`：六足生物。
- `octopod`：八足生物。
- `avian`：鸟类/有翼生物。
- `serpentine`：蛇形生物。
- `aquatic`：鱼类/水生生物。


## Request Example

### 检查示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/animations/rig-check \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_def456",
    "status": "success",
    "output": {
      "riggable": true,
      "rig_type": "biped"
    },
    "credits_consumed": 0.00
  }
}
```
