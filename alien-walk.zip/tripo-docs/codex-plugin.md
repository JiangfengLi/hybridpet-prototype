# 在 Codex 里使用 Tripo

像跟人说话一样对 Codex 下指令。你描述想要的 3D 模型，**Tripo 3D** 插件会生成它，并把文件存进你的项目。不需要懂 API、终端，也不需要会 3D 软件。

这是一份从零开始的逐步说明。请按顺序做；某一步没成功，先解决再往下。

> ChatGPT 与 Codex 在中国大陆不可用。本插件连接的是**海外** Tripo 服务（[developers.tripo3d.ai](https://developers.tripo3d.ai)）。请在能够打开 Codex 的环境里跟随本页操作。

## 开始前你需要准备什么

1. **一台电脑**（Mac 或 Windows）。
2. **Codex**：OpenAI 的编程助手。它在 ChatGPT 桌面应用或 Codex CLI 里，**不是**普通的 ChatGPT 对话窗口。
3. **Node.js 20 或更高版本**。插件会在后台用到它，你不用写 Node 代码。
4. **一个 Tripo 海外账号**。新账号会送免费积分。没有账号就先到 [developers.tripo3d.ai](https://developers.tripo3d.ai) 注册。

先检查 Node.js。打开「终端」（Mac）或 PowerShell（Windows），输入：

```bash
node -v
```

应看到类似 `v20.11.0` 或更高的版本号。如果提示找不到命令，到 [nodejs.org](https://nodejs.org/) 安装 LTS 版本，然后**关掉终端再打开**，再试一次。

安装插件和登录都是免费的。**真正生成模型时会消耗 Tripo 积分。**

## 第 1 步：打开 Codex，不要留在 ChatGPT 对话里

这是最常见的踩坑点。

1. 打开 **ChatGPT 桌面应用**（或 Codex CLI）。
2. 切换到 **Codex**。
3. 打开你希望 3D 文件出现的那个文件夹。还没有项目的话，新建一个空文件夹并打开它。

如果一直停在普通 ChatGPT 对话里，Tripo 插件不会出现。这是正常的：这个插件只在 Codex 里生效。

## 第 2 步：安装 Tripo 3D 插件

1. 在 Codex 里打开 **Plugins（插件）**。
2. 打开 **Plugins Directory（插件目录）**。
3. 搜索 **Tripo 3D**。
4. 安装，并确认它是 **enabled（已启用）**。

![Codex 插件目录中搜索“tripo”的结果，Tripo 3D 插件已高亮](/assets/images/docs/codex-plugin/plugin-search-zh.webp)

安装成功后，你会看到两类能力：生成 3D 资产，以及制作游戏向资产。不需要逐个开关，保持插件启用不关即可。

![Codex 中 Tripo 3D 插件的详情页，右上角是 Install plugin 按钮，下方列出两项技能](/assets/images/docs/codex-plugin/plugin-detail.webp)

<details>
<summary><strong>遇到问题？</strong> 找不到 Tripo 3D</summary>

- 确认你在 **Codex** 里，而不是 ChatGPT 对话。
- 完全退出 ChatGPT 桌面应用再打开，然后重新搜索。
- 如果仍然没有，改用 [Tripo CLI](/zh/docs/cli)。那是同一套生成引擎，只是在终端里操作。

</details>

## 第 3 步：发送第一条消息

把下面整段复制进 Codex：

```text
我想要一个带贴图的低多边形宝箱，把 GLB 文件存到 ./assets 文件夹。
如果 Tripo 还没配置好，请按我完全没接触过的程度，一步一步带我做完。
不要让我把 API Key 粘贴到对话里。
```

发送。接下来 Codex 通常会：

1. 检查这台电脑上 Tripo 是否就绪。
2. 如果你还没登录，给出一个**验证链接**和一组**一次性验证码**。
3. 等你在浏览器里完成登录。
4. 生成模型，并写入 `./assets`。

**永远不要把 API Key 粘到对话里。** 插件不需要你这么做。如果 Codex 向你要密钥，回复：`请用浏览器登录。不要向我要 Key。`

## 第 4 步：在浏览器里完成登录（只需第一次）

当 Codex 给出链接和验证码时，请你自己完成下面点击。**不要关掉 Codex**，也不要中止它正在跑的命令。

1. 在浏览器中打开那条验证链接。
2. 如果页面要求登录，先到 [developers.tripo3d.ai](https://developers.tripo3d.ai) 登录或注册，再回到验证页。
3. 把一次性验证码填进 **Verification code（验证码）** 输入框。必须和 Codex 里显示的**完全一致**。
4. 如果账号里已经有 API Key，任选一把即可；如果还没有，系统会自动创建，不用选。
5. 点击 **Authorize（授权）**。

![显示验证码的 Tripo CLI 浏览器设备授权页面](/assets/images/docs/cli/device-authorization-zh.webp)

授权成功后，Codex 会自己继续，你不用把任何内容复制回对话。

验证码过一段时间会失效。失败了就对 Codex 说：`请重新登录 Tripo。`

<details>
<summary><strong>遇到问题？</strong> 浏览器没打开，或登录没完成</summary>

- 把 Codex 给出的链接复制到浏览器地址栏打开。
- 页面上的验证码必须和 Codex 里的一致。拿不准就让 Codex 重新登录，换一组新码。
- 让 Codex 继续等待。登录最长可能要几分钟；中途停掉等于作废这组码。

</details>

## 第 5 步：等文件生成，然后打开看看

保持 Codex 开着。第一次生成常常要几分钟。Codex 是在等 Tripo 做完，不是卡死。

完成后，Codex 一般会：

- 告诉你文件保存在哪里（通常是 `./assets`）
- 说明这次花了多少积分
- 如果有预览图，会看一眼效果

打开那个文件夹，通常能看到：

- 模型文件，例如 `model.glb`
- `preview.png`：模型的预览图
- `task.json`：这次任务的记录

预览图不对的话，对 Codex 说：`这不是我想要的，换个种子再试一次。`

## 接下来可以这样说

用日常语言即可。下面几条可以直接复制。

**把图片变成 3D**（先把 `concept.png` 放到项目文件夹里）：

```text
把 concept.png 变成 3D 模型，保存到 ./assets。
```

**接着上一次的模型继续做**（不会从头再生成一遍，更省积分）：

```text
基于刚才那个模型，再做一个 1500 面的 LOD，保存到 ./assets。
```

**游戏占位道具，并写进代码：**

```text
给我的场景做三个占位道具，存成 ./assets 里的 GLB，然后在项目代码里加载它们。
```

一次要好几个模型时，Codex 应**先问你确认**再花积分。这是正常行为。

## 出问题了怎么办

| 你看到的情况 | 怎么处理 |
| --- | --- |
| 插件根本不出现 | 你还在 ChatGPT 对话里。切到 Codex。 |
| Codex 让你粘贴 API Key | 拒绝。回复：`请用浏览器登录，不要向我要 Key。` |
| 登录页没有反应 | 把 Codex 里的链接粘到浏览器。核对验证码是否一致。 |
| 提示积分不足 | 模型没有生成完。到 [海外控制台](https://developers.tripo3d.ai) 充值后，让 Codex 再试。 |
| 生成做到一半失败 | 失败任务的积分会自动退回。让 Codex 再试一次。 |
| 文件不在项目里 | 明确告诉它路径，例如 `保存到 ./assets`。 |
| 效果不好 | 让 Codex 重做。不要让它一声不响地连着重试很多遍。 |

## 相关页面

- [Tripo CLI](/zh/docs/cli) — 同一套引擎，在终端里使用
- [插件](/zh/docs/plugins) — Unity、Blender 等编辑器插件
- [认证方式](/zh/docs/authentication) — API Key 说明（用 Codex 时一般用不到）
- [计费说明](/zh/docs/billing) — 积分如何计算
