=== FILE: account.md ===
# 账户管理

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `GET /account/balance`

查询账户余额和用量详情。余额返回可用额度和冻结额度；用量返回按任务的消耗历史。

## Response Fields

### balance

- **Type:** number
- **Required:** 必选

可用额度余额。最多两位小数的数值（例如 41465.00）。
### frozen

- **Type:** number
- **Required:** 必选

为进行中任务冻结的额度。最多两位小数的数值（例如 0.00）。

## Request Example

### 余额

```
curl -s \
  -H "Authorization: Bearer YOUR_API_KEY" \
  https://openapi.tripo3d.com/v3/account/balance
```

### 用量

```
curl -s \
  -H "Authorization: Bearer YOUR_API_KEY" \
  https://openapi.tripo3d.com/v3/account/usage
```


## Response Example

### 余额

```json
{
  "code": 0,
  "data": {
    "balance": 10000.00,
    "frozen": 200.00
  }
}
```

### 用量

```json
{
  "code": 0,
  "data": [
    {
      "task_id": "task_abc123",
      "type": "text_to_model",
      "credits_consumed": 100.00,
      "created_at": "2025-01-01T00:00:00Z"
    }
  ]
}
```

=== FILE: animations-retarget.md ===
# 动画重定向

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /animations/retarget`

将预设动画应用到已绑骨的 3D 模型上。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

已绑骨模型的 task_id，以 `task_` 开头。
### animation

- **Type:** string
- **Required:** 条件必填

单个预设动画标识符。**与 `animations` 互斥，只能二选一。**


Rig v2.5-20260210 — 所有骨骼类型


- 双足：`preset:idle`、`preset:walk`、`preset:run`、`preset:dive`、`preset:climb`、`preset:jump`、`preset:slash`、`preset:shoot`、`preset:hurt`、`preset:fall`、`preset:turn`
- 四足：`preset:quadruped:walk`
- 其他：`preset:hexapod:walk`、`preset:octopod:walk`、`preset:serpentine:march`、`preset:aquatic:march`
Rig v1.0-20240301 — 仅双足（90+ 预设动画，点击展开）`preset:biped:afraid``preset:biped:agree``preset:biped:angry_01``preset:biped:angry_02``preset:biped:angry_03``preset:biped:basketball_shot``preset:biped:bow``preset:biped:box_01``preset:biped:box_02``preset:biped:box_03``preset:biped:cast_a_spell``preset:biped:cheer``preset:biped:chop``preset:biped:clap``preset:biped:climb``preset:biped:complain_01``preset:biped:complain_02``preset:biped:cross_body_crunch``preset:biped:crossover_dribble``preset:biped:cry``preset:biped:dance_01``preset:biped:dance_02``preset:biped:dance_03``preset:biped:dance_04``preset:biped:dance_05``preset:biped:dance_06``preset:biped:defeat_02``preset:biped:defeat_03``preset:biped:depressed``preset:biped:dig``preset:biped:dive``preset:biped:dribble``preset:biped:fall``preset:biped:fire``preset:biped:flee_01``preset:biped:flee_02``preset:biped:flip``preset:biped:fold_arms``preset:biped:football_catch``preset:biped:football_save``preset:biped:football_pass``preset:biped:freaky``preset:biped:frightened``preset:biped:front_kick_01``preset:biped:front_kick_02``preset:biped:frustrated_01``preset:biped:frustrated_02``preset:biped:golf``preset:biped:greet_01``preset:biped:greet_02``preset:biped:greet_03``preset:biped:greet_04``preset:biped:heart_pose``preset:biped:hit_to_body_01``preset:biped:hit_to_body_02``preset:biped:hit_to_head``preset:biped:hit_to_side``preset:biped:hit_to_stomach``preset:biped:hug``preset:biped:hurt``preset:biped:idle``preset:biped:jump_down``preset:biped:jump``preset:biped:jump_rope_01``preset:biped:jump_rope_02``preset:biped:laugh_01``preset:biped:laugh_02``preset:biped:lift_heavy``preset:biped:look_around``preset:biped:make_a_call_01``preset:biped:make_a_call_02``preset:biped:pitch_baseball``preset:biped:play_mobile_game``preset:biped:play_video_game``preset:biped:press-up``preset:biped:run_upstairs``preset:biped:run``preset:biped:scared_01``preset:biped:scared_02``preset:biped:scratch``preset:biped:shoot``preset:biped:shovel``preset:biped:sing_01``preset:biped:sing_02``preset:biped:sing_03``preset:biped:sing_04``preset:biped:sit``preset:biped:slash``preset:biped:sob``preset:biped:standing_relax``preset:biped:surf``preset:biped:swagger``preset:biped:swim``preset:biped:turn``preset:biped:victory_celebration``preset:biped:volleyball``preset:biped:wait``preset:biped:walk``preset:biped:warm_up``preset:biped:wave_goodbye_01``preset:biped:wave_goodbye_02`

### animations

- **Type:** string[]
- **Required:** 条件必填

多个预设动画标识符列表。**与 `animation` 互斥，只能二选一。**

### out_format

- **Type:** string
- **Required:** 可选
- **Default:** `glb`

输出格式。
- `glb`：二进制 glTF，适用于 Web。
- `fbx`：FBX，适用于 DCC 工具和游戏引擎。

### bake_animation

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

将动画烘焙到模型中。仅对 `glb` 输出有效。
### export_with_geometry

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

导出时包含几何体。
### animate_in_place

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

原地播放动画，无位移。

## Request Example

### 单个动画

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/animations/retarget \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "animation": "preset:walk",
  "out_format": "glb",
  "bake_animation": true
}'
```

### 批量动画

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/animations/retarget \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "animations": [
    "preset:idle",
    "preset:walk",
    "preset:run"
  ],
  "out_format": "fbx"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_def456",
    "status": "success",
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/animated.glb"
    },
    "credits_consumed": 20.00
  }
}
```

=== FILE: animations-rig-check.md ===
# 可绑骨检查

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /animations/rig-check`

检查模型是否可以绑骨，并返回推荐的骨骼类型。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型来源。接受 task_id、file_token 或 URL。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前 3D 生成任务（`text_to_model`、`image_to_model` 或 `multiview_to_model`）返回的任务 ID。系统会自动使用该任务的 3D 模型输出。
示例： `task_abc123`
- file_token：先通过文件上传 API上传 3D 模型文件，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的 3D 模型文件直链。
示例： `https://example.com/model.glb`



- 支持格式：`GLB`
- 最大文件大小：**150 MB**


## Response Fields

### riggable

- **Type:** boolean
- **Required:** 必选

模型是否可绑骨。
### rig_type

- **Type:** string
- **Required:** 必选

推荐的骨骼类型。
- `biped`：双足人形。
- `quadruped`：四足动物。
- `hexapod`：六足生物。
- `octopod`：八足生物。
- `avian`：鸟类/有翼生物。
- `serpentine`：蛇形生物。
- `aquatic`：鱼类/水生生物。


## Request Example

### 检查示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/animations/rig-check \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_def456",
    "status": "success",
    "output": {
      "riggable": true,
      "rig_type": "biped"
    },
    "credits_consumed": 0.00
  }
}
```

=== FILE: animations-rig.md ===
# 自动绑骨

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /animations/rig`

自动为 3D 模型添加骨骼绑定。请先运行可绑骨检查以验证兼容性。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型来源。接受 task_id 或 file_token。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前 3D 生成任务（`text_to_model`、`image_to_model` 或 `multiview_to_model`）返回的任务 ID。系统会自动使用该任务的 3D 模型输出。
示例： `task_abc123`
- file_token：先通过文件上传 API上传 3D 模型文件，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的 3D 模型文件直链。
示例： `https://example.com/model.glb`



- 支持格式：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`
- 最大文件大小：**150 MB**

### model

- **Type:** string
- **Required:** 可选
- **Default:** `v1.0-20240301`

绑骨模型版本。
- `v1.0-20240301`：仅适用于（且推荐用于）双足类人型绑骨。支持 90+ 预设动画。
- `v2.5-20260210`：适用于非类人型的动物绑骨（四足、六足、八足、蛇形、水生、鸟类）。

### rig_type

- **Type:** string
- **Required:** 可选
- **Default:** `biped`

骨骼类型。建议先调用 `rig-check`。
- `biped`：双足人形。
- `quadruped`：四足动物。
- `hexapod`：六足生物。
- `octopod`：八足生物。
- `avian`：鸟类/有翼生物。
- `serpentine`：蛇形生物。
- `aquatic`：鱼类/水生生物。

### spec

- **Type:** string
- **Required:** 可选
- **Default:** `tripo`

绑骨规范。
- `tripo`：Tripo 原生骨骼命名。
- `mixamo`：兼容 Mixamo 的骨骼命名。

### out_format

- **Type:** string
- **Required:** 可选
- **Default:** `glb`

输出格式。
- `glb`：二进制 glTF，适用于 Web。
- `fbx`：FBX，适用于 DCC 工具和游戏引擎。


## Request Example

### 自动绑骨

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/animations/rig \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "model": "v2.5-20260210",
  "rig_type": "biped",
  "spec": "mixamo",
  "out_format": "glb"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_def456",
    "status": "success",
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/rigged.glb"
    },
    "credits_consumed": 30.00
  }
}
```

=== FILE: authentication.md ===
# 认证方式

所有 Tripo API 请求需要在 HTTP 请求头中携带 API Key 进行身份认证。

## 认证方式

在请求头中添加 `Authorization` 字段，值为 `Bearer {api_key}`：

```
Authorization: Bearer {api_key}
```

## 获取 API Key

1. 登录 [Tripo 控制台](https://platform.tripo3d.ai)
2. 进入「API 密钥」页面
3. 点击「创建密钥」生成新的 API Key
4. 复制并妥善保存（创建后仅显示一次）

## 请求示例

### curl

```bash
curl -X GET https://openapi.tripo3d.com/v3/account/balance \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Python

```python
import requests

headers = {
    "Authorization": "Bearer YOUR_API_KEY"
}

response = requests.get(
    "https://openapi.tripo3d.com/v3/account/balance",
    headers=headers
)
print(response.json())
```

### JavaScript

```javascript
const response = await fetch("https://openapi.tripo3d.com/v3/account/balance", {
  headers: {
    "Authorization": "Bearer YOUR_API_KEY"
  }
});

const data = await response.json();
console.log(data);
```

## 安全建议

- **使用环境变量存储 API Key**，不要硬编码在源代码中
- **不要将 API Key 提交到代码仓库**，在 `.gitignore` 中添加 `.env` 文件
- **前端应用不要直接使用 API Key**，通过后端服务代理请求
- **定期轮换密钥**，如果怀疑泄露，立即在控制台删除并重新创建

```bash
# 推荐：通过环境变量读取 API Key
export TRIPO_API_KEY="your_api_key_here"
```

```python
import os

api_key = os.environ["TRIPO_API_KEY"]
```

```javascript
const apiKey = process.env.TRIPO_API_KEY;
```

=== FILE: b2b-payment.md ===
# 公对公支付

面向企业用户的对公转账充值指南：在充值页发起「公对公充值」订单后，通过支付宝企业收银台获取本次订单的专属收款账户，再用企业网银按订单金额完成转账。以下 7 个步骤覆盖从发起订单到转账完成的完整流程。

## 01｜进入充值页面

进入「账单与余额」页面，查看当前可用积分与冻结积分。点击右上角「充值」按钮，进入积分充值页面。

![步骤 1：账单与余额页面，右上角为充值按钮](/assets/images/docs/b2b-payment/step-01-billing-topup.webp)

## 02｜选择公对公充值

切换至「公对公充值」，根据实际需要选择充值套餐。确认积分数量和充值金额后，点击下方「公对公银行转账」发起充值订单。

![步骤 2：充值弹窗切换到公对公充值并选择套餐，底部为公对公银行转账按钮](/assets/images/docs/b2b-payment/step-02-choose-b2b.webp)

## 03｜登录支付宝账户

进入支付宝收银台后，确认订单名称与付款金额无误，点击右侧「登录账户付款」，使用企业支付宝账户继续支付。

![步骤 3：支付宝收银台展示订单信息，右侧为登录账户付款入口](/assets/images/docs/b2b-payment/step-03-alipay-login.webp)

## 04｜切换其他付款方式

登录支付宝后，点击「其他方式付款」，展开更多企业付款方式。请勿直接输入个人支付宝支付密码，以免使用错误的付款渠道。

![步骤 4：支付宝付款页底部的其他方式付款入口](/assets/images/docs/b2b-payment/step-04-other-payment-methods.webp)

## 05｜选择银行转账

在付款方式列表中选择「复制转账」或「企业支付」。推荐选择「复制转账」，通过企业网银将款项转入本次订单对应的专属收款账户。

![步骤 5：付款方式列表中的复制转账与企业支付选项](/assets/images/docs/b2b-payment/step-05-bank-transfer.webp)

## 06｜复制收款信息

选择付款银行，复制页面提供的收款编号、账户名、收款行及转账金额。随后登录企业网银完成转账，付款金额需与订单金额保持一致。转账完成后等待 1～5 分钟，再点击「我已转账，查询支付结果」。

![步骤 6：收款信息页展示收款编号、账户名、收款行与转账金额，可一键复制](/assets/images/docs/b2b-payment/step-06-copy-account-info.webp)

## 07｜登录企业网银付款

进入所选银行官网，选择「企业网银登录」，使用企业账户完成转账。请仔细核对收款信息与金额，并以本次订单页面展示的动态收款账户为准。

![步骤 7：银行官网的企业网银登录入口](/assets/images/docs/b2b-payment/step-07-ebank-payment.webp)

## 注意事项

<div class="doc-callout doc-callout--warn rounded-lg p-4 text-sm text-[var(--text-block)]">
每笔订单生成的收款账户可能不同，仅限本次转账使用，请勿保存或重复付款。完成转账前请不要关闭支付宝订单页面；如积分未及时到账，可返回订单记录查询状态。
</div>

=== FILE: billing.md ===
# 计费说明

## 积分制

Tripo API 采用积分（Credits）计费。不同任务类型消耗不同数量的积分。

## 积分冻结/扣除模型

| 阶段 | 说明 |
| :-: | :-: |
| 创建任务 | 从可用余额中冻结对应积分 |
| 任务成功 | 冻结积分转为已消耗，正式扣除 |
| 任务失败 | 冻结积分退回可用余额 |
| 任务取消 | 冻结积分退回可用余额 |

失败和取消的任务不收费。

## 查询余额

> **GET** `/v3/account/balance`

### curl

```bash
curl -X GET https://openapi.tripo3d.com/v3/account/balance \
  -H "Authorization: Bearer {api_key}"
```

### Python

```python
import requests

url = "https://openapi.tripo3d.com/v3/account/balance"
headers = {
    "Authorization": "Bearer {api_key}"
}

response = requests.get(url, headers=headers)
print(response.json())
```

### JavaScript

```javascript
const response = await fetch("https://openapi.tripo3d.com/v3/account/balance", {
  headers: {
    "Authorization": "Bearer {api_key}"
  }
});

const data = await response.json();
console.log(data);
```

### 响应示例

```json
{
  "code": 0,
  "data": {
    "balance": 10000.00,
    "frozen": 200.00
  }
}
```

| 字段 | 类型 | 说明 |
| :-: | :-: | :-: |
| balance | number | 可用积分余额 |
| frozen | number | 冻结积分（进行中的任务预扣） |

## 查看用量

> **GET** `/v3/account/usage`

### curl

```bash
curl -X GET https://openapi.tripo3d.com/v3/account/usage \
  -H "Authorization: Bearer {api_key}"
```

### Python

```python
import requests

url = "https://openapi.tripo3d.com/v3/account/usage"
headers = {
    "Authorization": "Bearer {api_key}"
}

response = requests.get(url, headers=headers)
print(response.json())
```

### JavaScript

```javascript
const response = await fetch("https://openapi.tripo3d.com/v3/account/usage", {
  headers: {
    "Authorization": "Bearer {api_key}"
  }
});

const data = await response.json();
console.log(data);
```

### 响应示例

```json
{
  "code": 0,
  "data": [
    {
      "task_id": "task_abc123",
      "type": "text_to_model",
      "credits_consumed": 100.00,
      "created_at": "2026-01-01T00:00:00Z"
    }
  ]
}
```

| 字段 | 类型 | 说明 |
| :-: | :-: | :-: |
| task_id | string | 任务唯一标识 |
| type | string | 任务类型 |
| credits_consumed | number | 消耗积分 |
| created_at | string | 创建时间（ISO 8601） |

=== FILE: changelog.md ===
# 更新日志

## 贴图模型 v3.5-20260815（2026-09）

新一代贴图模型，两个入口：

- **`POST /v3/models/texture`**：`model` 新增 `v3.5-20260815`。默认值仍为 `v3.0-20250812`，不传参数行为不变。
- **生成接口**（`text-to-model`、`image-to-model`、`multiview-to-model`，含 P1 / P2）：新增 `texture_version`，可独立指定贴图模型，与几何体 `model` 解耦。可选值 `v3.5-20260815`、`v3.0-20250812`、`v2.5-20250123`；省略时按几何体版本推导（v2.5 几何体 → `v2.5-20250123`，其余 → `v3.0-20250812`）。

配套两个新参数，**均仅在 v3.5 贴图下生效**：

- **`texture_quality=fast`**：新增质量档，生成最快，以细节换速度。**输出贴图尺寸与积分均与 `standard` 相同**，仅细节表现更低。在非 v3.5 贴图上使用会返回 `1004`，不会静默降级为 `standard`。
- **`delight`**（boolean，默认 `true`）：贴图前去除参考图中的光照信息；设为 `false` 保留原有明暗。更早的贴图版本会忽略该参数。

## GPT Image 2.5、quality 档位与透明背景（2026-09）

`POST /v3/generation/text-to-image` 与 `POST /v3/generation/image-to-image` 新增两个模型，GPT Image 2/2.5 系列新增 `quality` 参数，两个 2.5 模型新增 `background` 参数。

- **新增模型**：`chat_image_2.5_flare` 与 `chat_image_2.5_sunburst`。两者积分相同，差别在取舍 —— flare 明显更快，sunburst 在编辑时对未指定修改的部分保持得更接近原图。
- **`quality`**：仅 `chat_image_2`（`low`、`medium`、`high`）与两个 2.5 模型（另支持 `xhigh`、`max`）可用。不传等同于 `low` —— 请注意这与 OpenAI 官方默认的 `auto` 不同，且本接口不支持 `auto`。`high`/`xhigh`/`max` 会额外消耗积分，详见定价页。
- **`background`**：取值 `auto`、`opaque`、`transparent`，仅两个 2.5 模型支持。不传则由模型自行决定。其它模型传入会被忽略而非报错，因此现有请求行为不变。
- **`transparent` 必须搭配 `output_format=png`**：JPEG 不支持 alpha 通道，两者同时传入会直接报错，而不是悄悄把透明背景压平。
- **自定义尺寸**：`chat_image_2` 与 2.5 系列支持任意 `宽x高`，需满足单边不超过 3840、两边均为 16 的倍数、长边不超过短边 3 倍、总像素在 655,360 与 8,294,400 之间。原有预设尺寸继续可用。
- **下线计划**：`chat_image_1` 将于 **2026-10-23** 下线，`chat_image_1.5` 将于 **2026-12-01** 下线。请在此之前迁移到 `chat_image_2` 或 2.5 系列。

## P2 系列模型（2026-08）

`POST /v3/generation/text-to-model`、`image-to-model`、`multiview-to-model` 现支持 `model=P2-20260801`（P1 升级版）。

- **P2 独有参数**：`quad`（四边面）。P1 传入 `quad=true` 会 `400`，请改用 P2 或去掉该字段。
- **`face_limit`**：三角面 48–50,000；`quad=true` 时 48–25,000。省略则自适应。
- **积分**：无贴图 100；`standard` / `detailed` / `extreme` 为 110 / 120 / 130（贴图加价与 P1 相同）。
- **P1**（`P1-20260311`）仍可用；P1 不支持 `quad`、`smart_low_poly`、`generate_parts`、`geometry_quality`。

## 文档更正（2026-08）

`credits_consumed`、`balance`、`frozen` 在 JSON 中为**数值（number）**，最多两位小数（例如 `48.00`、`41465.00`）。请使用浮点或 decimal 解析——**禁止**用整数解析（`int`、`parseInt` 等），否则会失败或截断小数部分（如 VIP 折扣）。

## v3.0 (2026-04)

### 全新 API 架构

- **独立端点替代万能 POST**：按能力分组的独立端点（如 `POST /v3/generation/text-to-model`）替代原有的 `POST /v2/openapi/task` + `type` 字段的万能接口
- **统一 `{input}-to-{output}` 命名规范**：所有生成类端点采用直观的命名方式，如 `text-to-model`、`image-to-multiview`、`multiview-to-model`
- **统一 `input` 字段**：支持 `task_id` / `file_token` / URL 自动推断输入来源，无需手动指定输入类型
- **去除 `/openapi` 冗余路径**：Base URL 从 `/v2/openapi/` 简化为 `/v3/`
- **文生图和图生图分离为独立端点**：`text-to-image` 和 `image-to-image` 不再合并为同一个接口

### 端点变更明细

| v2 端点 | v3 端点 |
| :-: | :-: |
| `POST /v2/openapi/task` type=text_to_model | `POST /v3/generation/text-to-model` |
| `POST /v2/openapi/task` type=image_to_model | `POST /v3/generation/image-to-model` |
| `POST /v2/openapi/task` type=multiview_to_model | `POST /v3/generation/multiview-to-model` |
| `POST /v2/openapi/task` type=text_to_image | `POST /v3/generation/text-to-image` |
| `POST /v2/openapi/task` type=generate_image | `POST /v3/generation/image-to-image` |
| `POST /v2/openapi/task` type=generate_multiview_image | `POST /v3/generation/image-to-multiview` |
| `POST /v2/openapi/task` type=edit_multiview_image | `POST /v3/generation/edit-multiview` |
| `POST /v2/openapi/task` type=refine_model | `POST /v3/models/refine` |
| `POST /v2/openapi/task` type=convert_model | `POST /v3/models/convert` |
| `POST /v2/openapi/task` type=import_model | `POST /v3/models/import` |
| `POST /v2/openapi/task` type=stylize_model | `POST /v3/models/stylize` |
| `POST /v2/openapi/task` type=texture_model | `POST /v3/models/texture` |
| `POST /v2/openapi/task` type=animate_prerigcheck | `POST /v3/animations/rig-check` |
| `POST /v2/openapi/task` type=animate_rig | `POST /v3/animations/rig` |
| `POST /v2/openapi/task` type=animate_retarget | `POST /v3/animations/retarget` |
| `POST /v2/openapi/task` type=mesh_segmentation | `POST /v3/mesh/segment` |
| `POST /v2/openapi/task` type=mesh_completion | `POST /v3/mesh/complete` |
| `POST /v2/openapi/task` type=highpoly_to_lowpoly | `POST /v3/mesh/decimate` |
| `GET /v2/openapi/task/{task_id}` | `GET /v3/tasks/{task_id}` |

### 字段变更

| v2 字段 | v3 字段 |
| :-: | :-: |
| `create_time` | `created_at` |
| `consumed_credit` | `credits_consumed` |
| `file` / `file_token` / `url` / `object` | 统一为 `input` |

### 新增能力

- `POST /v3/tasks/list`：批量查询任务
- `POST /v3/files/upload-credentials`：获取文件直传凭证
- `GET /v3/account/usage`：查询用量明细

=== FILE: cli.md ===
# Tripo CLI：让 AI 帮你把文字和图片变成 3D 模型

Tripo CLI 为 AI Agent 而设计，让 3D 创作像聊天一样简单。无论是在 Codex、Claude Code、Cursor 等 AI 编码工具中，还是直接使用 CLI，只需一句自然语言描述、一张图片或一个现有模型，即可生成或转换 3D 模型、动画等资产。CLI 会自动完成整个流程，无需理解 API、模型版本或复杂参数。

## 我该用 CLI 还是 API？

Tripo 有两种使用方式，先花 10 秒确认哪种最适合你：

| 产品 | 适合谁 | 入口 |
| --- | --- | --- |
| **Tripo CLI（本页）** | 小白用户，借助主流 Vibe Coding 工具快速调用 AI 3D 能力 | 继续往下读 |
| **Tripo API** | 专业开发者，将 AI 3D 能力集成至网站、App 或自有业务系统 | [快速开始](/zh/docs/quick-start) |

拿不准的话，就按本页先试一次：安装是免费的，只有真正生成模型时才消耗积分。

## 安装并登录（两种方式，选一种）

以下安装方式二选一

### 方式一：让 AI 帮我安装（推荐）

如果你正在使用 Cursor、Claude Code、Codex 等可以操作终端的 AI 助手，这是最省心的方式。把下面的提示词完整复制并发送给它：

```text
请帮我安装并配置 Tripo CLI，同时解释每一步。先确认本机已安装 Node.js 20 或更高版本，再执行 npm install -g tripo-cli。如果当前是 Windows PowerShell 且提示禁止运行脚本，请先执行 Set-ExecutionPolicy -Scope CurrentUser RemoteSigned（不要用管理员身份），然后再重试。然后请让我在浏览器中完成 tripo login，不要让我把 API Key 粘贴到聊天中。最后运行 tripo doctor，并告诉我认证、网络和余额检查是否通过。
```

接下来会发生什么：

1. AI 检查电脑环境，缺 Node.js 时会先带你装好；
2. AI 运行安装命令；
3. 轮到你：浏览器会打开 Tripo 登录页，登录并确认终端里显示的验证码（这一步必须本人完成，不要把任何密钥发给 AI）；
4. AI 运行 `tripo doctor` 检查，全部通过就安装完成了。

完成后直接跳到下一节“生成你的第一个 3D 模型”。

<details>
<summary><strong>遇到问题？</strong>AI 卡住或报错了</summary>

- 把终端里的报错原样发给 AI，让它继续处理，绝大多数问题它都能解决；
- 登录没有完成：重新打开登录页面，核对终端里显示的验证码后再确认；
- 实在不行，改用下面的“方式二：我自己安装”，一共只有三条命令。

</details>

### 方式二：我自己安装

不使用 AI 助手也完全没问题，全程只有三条命令。

**第 1 步：安装 Tripo CLI**

这条命令会把 `tripo` 命令安装到电脑里：

```bash
npm install -g tripo-cli
```

正常情况下，安装进度结束后没有红色报错，就说明装好了。

<details>
<summary><strong>遇到问题？</strong>找不到 npm，或提示权限不足</summary>

- 提示找不到 `npm`：说明 Node.js 还没装好。前往 [Node.js 官网](https://nodejs.org/) 安装当前 LTS 版本（20 或更高），装完后重新打开终端再运行一次；
- macOS 提示权限不足（EACCES）：改用 `sudo npm install -g tripo-cli`，按提示输入电脑密码；
- Windows 提示“禁止运行脚本”：在 PowerShell 中运行 `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`（不需要管理员权限），重新打开终端后再试。更多示例见下文「Windows / PowerShell」。

</details>

**第 2 步：登录 Tripo 账号**

```bash
tripo login
```

浏览器会自动打开授权页面（还没有账号就先在页面上注册一个）。页面会显示一个验证码，**确认它和你终端里显示的验证码一致后再点确认**。登录成功后，终端会提示已登录。

![显示验证码的 Tripo CLI 浏览器设备授权页面](/assets/images/docs/cli/device-authorization-zh.webp)

<details>
<summary><strong>遇到问题？</strong>浏览器没打开，或登录没有完成</summary>

- 登录没有完成：重新运行 `tripo login`，在打开的页面里核对终端显示的验证码后确认；
- 浏览器一直没有反应：把终端里显示的网址手动复制到浏览器打开；
- 浏览器授权暂时不可用：CLI 会改为打开 API Key 页面，见本节末尾的“备用登录方式与区域说明”。

</details>

**第 3 步：检查一切是否就绪**

```bash
tripo doctor
```

它会依次检查登录状态、网络和积分余额。三项全部通过，安装就完成了。

<details>
<summary><strong>遇到问题？</strong>某一项检查没通过</summary>

- 认证未通过：登录没有完成，重新运行 `tripo login` 再登录一次；
- 网络未通过：确认电脑能正常打开网页；公司或校园网络可能需要配置代理；
- 余额未通过：当前积分不足，此时不会开始任何生成，也不会扣费。运行 `tripo topup` 打开充值页面。

</details>

<details>
<summary><strong>备用登录方式与区域说明</strong>（浏览器登录不可用时再看）</summary>

- 已有 API Key 时，可以运行 `tripo login --key tsk_...` 直接登录，或设置环境变量 `TRIPO_API_KEY`；
- API Key 相当于账号凭证，不要粘贴到聊天、代码、截图或日志中；
- 同一套安装同时支持海外与中国大陆账号：CLI 会用 Key 探测两个区域，并自动保存可用区域，无需手动选择。

</details>

## Windows / PowerShell

本页命令以 Bash 为例。它们在 Windows 上同样可用，但 PowerShell 对部分符号的解析与 Bash / cURL 不同——在 PowerShell 中请复制下面的示例，不要直接粘贴 Bash 代码块。

**允许运行 `tripo` 命令**

npm 会安装 `tripo.ps1` 包装脚本，PowerShell 的默认执行策略会拦截它：

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

重新打开终端后再运行 `tripo doctor`。这一步不需要管理员权限。如果希望不改策略，改用命令提示符（`cmd.exe`），其中可以直接运行 `tripo`。

**给 `@last` 和带逗号的参数加引号**

PowerShell 会把 `@name` 当成特殊语法，把 `,` 当成数组分隔符：

```powershell
tripo make "一只可爱的低多边形狐狸"
tripo view '@last'
tripo make hero.glb --then 'texture,rig'
tripo make '@last' --then 'convert:fbx'
```

在命令提示符中不需要这些额外引号。

**设置环境变量**

```powershell
# 仅当前窗口有效
$env:TRIPO_API_KEY = "tsk_..."
$env:TRIPO_PROFILE = "work-cn"

# 为当前 Windows 用户持久保存
[System.Environment]::SetEnvironmentVariable("TRIPO_API_KEY", "tsk_...", "User")
```

配置和历史默认保存在 `%USERPROFILE%\.tripo`（即 Windows 上的 `~/.tripo`）。

**JSON 管道**

```powershell
# PowerShell 7 或更高版本（推荐）
tripo make cat.png --json | tripo model texture --json | tripo anim rig --json

# Windows PowerShell 5.1：先把输出接到变量里
$json = tripo make cat.png --json --no-open
$json | tripo model texture --json
```

如果中文提示词出现乱码，请使用 [Windows Terminal](https://aka.ms/terminal)，或先运行 `chcp 65001`。

## 生成你的第一个 3D 模型

**第 1 步：用一句话生成**

引号里的文字就是提示词，把它换成你想要的任何物体：

```bash
tripo make "一只可爱的低多边形狐狸"
```

命令运行期间保持终端打开。Tripo CLI 会自动选择合适的生成流程和模型、等待任务完成，并把文件下载到当前目录的 `tripo-out` 文件夹。整个过程通常几分钟内结束，消耗账户中的少量积分。

<details>
<summary><strong>遇到问题？</strong>生成没有开始，或中途失败</summary>

- 提示积分不足：本次模型还没有开始生成，不会扣费。运行 `tripo topup` 充值后重试；
- 网络错误：确认电脑联网正常后，重新运行同一条命令即可；
- 任务失败：已扣的积分会自动退回，换一个描述再试一次。

</details>

**第 2 步：打开预览**

```bash
tripo view @last
```

`@last` 表示“最近一次任务”。浏览器会打开一个可以拖动旋转的 3D 预览——看到你的模型，就成功了！在 PowerShell 中请写成 `tripo view '@last'`。

**成功之后，你现在拥有什么**

- **文件在哪**：`tripo-out` 下多了一个新文件夹，里面有下载好的 3D 模型文件和记录任务参数的 `task.json`；如果服务端提供预览图，还会有 `preview.png`。
- **再次打开**：随时运行 `tripo view @last`；也可以用 `tripo view 文件路径` 打开任意模型文件。
- **花了多少**：运行 `tripo balance` 查看积分余额。
- **不想记命令**：直接运行 `tripo` 会打开带引导的交互菜单，登录、生成、预览、充值都能在里面完成。
- **下一步**：用图片生成（下一节）、让 AI 助手替你操作（“让 AI 编码 Agent 深度使用 CLI”一节），或批量处理（“现成场景与流水线”一节）。

## 用图片或已有模型生成

文字生成跑通后，还可以把本地图片或模型文件作为输入。下面的 `concept.png`、`front.png`、`hero.glb` 都是示例文件名，请替换成你自己的文件路径：

```bash
tripo make concept.png --for print
tripo make front.png back.png
tripo make hero.glb --then texture,rig
tripo make @last --then convert:fbx
```

- 第 1 条：把一张概念图变成适合 3D 打印的模型；
- 第 2 条：用正、反两张图片一起生成，细节更准确；
- 第 3 条：给已有模型补贴图并绑定骨骼；
- 第 4 条：把最近一次的结果转换成 FBX 格式。

## 让 AI 编码 Agent 深度使用 CLI

如果你用的是 **Codex**，请先看 [Tripo 3D Codex 插件](/zh/docs/codex-plugin)：用日常语言说话即可，不用自己敲 CLI 命令。

不使用 AI 编码 Agent 可以跳过本节。npm 包内置一份 Agent Skill，包含命令参考、场景方案和错误恢复说明，帮助 Agent 正确使用 CLI。让 Agent 运行下面的命令，即可在终端中输出完整说明或单个主题：

```bash
tripo docs --llm
tripo docs --topic commands/make
tripo docs --topic examples/game-asset
```

<details>
<summary><strong>Skill 内置文件一览</strong></summary>

```text
skill/
├── SKILL.md
├── common-errors.md
├── commands/
│   ├── account.md
│   ├── batch.md
│   ├── generate.md
│   ├── make.md
│   ├── process.md
│   ├── task.md
│   └── view.md
└── examples/
    ├── animation.md
    ├── ar-web.md
    ├── film.md
    ├── game-asset.md
    ├── pipes.md
    └── print.md
```

</details>

## 命令参考

不需要记住整张表：新手日常只用得到 `tripo`（交互菜单）、`tripo make`（生成）、`tripo view`（预览）和 `tripo doctor`（检查环境）四个命令，其余命令在有明确需求时再展开查询。

<details>
<summary><strong>展开完整命令表与通用参数</strong></summary>

| 命令 | 作用 |
| --- | --- |
| `tripo make <input...>` | 用一个命令完成生成、处理和下载 |
| `tripo ai [description]` | 规划任务、确认方案并执行 |
| `tripo view [task\|file]` | 在浏览器中打开本地交互式 3D 预览 |
| `tripo redo [task]` | 使用新种子重新执行请求 |
| `tripo login / logout / whoami / use` | 授权并切换命名账号配置 |
| `tripo topup / balance / usage` | 打开对应区域的充值页并查询积分 |
| `tripo generate <endpoint>` | 明确调用全部 8 个生成接口 |
| `tripo model / anim / mesh <step>` | 执行精修、贴图、绑骨、转换、分割等处理 |
| `tripo task get/list/watch` | 查询、列出或等待任务 |
| `tripo history [--limit <n>]` | 查看最近的本地任务历史 |
| `tripo files upload <path>` | 上传文件并返回 `file_token` |
| `tripo batch run <manifest.yaml>` | 以并发、重试和断点续跑执行批量流水线 |
| `tripo config / doctor` | 管理设置并诊断本地环境 |
| `tripo docs [--topic <topic>]` | 输出内置 Agent 与命令文档 |
| `tripo mcp` | 以 MCP Server 方式运行 CLI |
| `tripo completion <shell>` | 为 Bash、Zsh 或 Fish 生成自动补全（不支持 PowerShell） |

`make`、`ai`、`generate` 命令，以及 `model`、`anim`、`mesh` 下的处理子命令，支持 `-o/--out`、`--no-wait`、`--no-download`、`--name`、`--timeout`、`--notify`，以及可重复的 `--param key=value`。全局自动化参数包括 `--json`、`--yes`、`--quiet`、`--no-open` 和 `--profile`。

</details>

## 现成场景与流水线

这是进阶内容，第一次生成时不需要。CLI 内置 7 个场景预设，通过 `--for 预设名` 一次性套用常用参数和后处理步骤：

`game-mobile` · `game-pc` · `film` · `print` · `ar-web` · `anim` · `toy`

```bash
# 移动游戏资产：低模生成、贴图并转换为 FBX
tripo make "科幻补给箱" --for game-mobile

# 3D 打印资产：封闭网格、STL 和平底处理
tripo make "国际象棋骑士" --for print

# 显式后处理链
tripo make cat.png --then texture,rig,convert:fbx

# 使用 NDJSON 管道组合同一处理链
tripo make cat.png --json | tripo model texture --json | tripo anim rig --json

# 可断点续跑的批量处理
tripo batch run assets.yaml --concurrency 2
```

凡是接受任务 ID 的位置，都可以使用 `@last`、`@2` 和 `@name` 等任务引用。

## 多账号与区域

如果只使用一个 Tripo 账号，可以跳过本节。凭证保存在命名配置（profile）中，登录第二个账号不会覆盖第一个账号的 Key：

```bash
tripo login
tripo login --profile work-cn
tripo use
tripo whoami
tripo make "一只狐狸" --profile work-cn
tripo logout
```

每个配置分别保存自己的 Key 和区域。环境变量 `TRIPO_PROFILE` 可为当前环境选择配置；`TRIPO_API_KEY` 会绕过所有配置，优先级最高。

## AI 编码 Agent 注意事项

普通用户可以跳过本节。这些规则用于帮助 Agent 正确等待任务并读取机器可读的输出。

- `tripo make` 和 `tripo task watch` 是阻塞命令。应等待进程结束，不要重复实现轮询。
- 使用 `--json` 时，大多数一次性命令会向 stdout 输出一行最终 JSON；`tripo task watch --json` 则会以 NDJSON 流式输出进度事件，最后输出最终结果。
- 如果存在 `preview.png`，应在继续流水线或执行 `tripo redo` 前先检查它。
- 不要编造参数或强制使用旧模型版本。通过 `tripo docs --topic ...` 查询支持的参数。
- 低模意图或面数预算不超过 20,000 时选择 `tripo-p1`，其他任务默认使用 `tripo-v3.1`。

<details>
<summary><strong>展开退出码表</strong></summary>

| 退出码 | 含义 |
| --- | --- |
| `0` | 成功 |
| `1` | 意外或内部错误 |
| `2` | 用法或参数错误 |
| `3` | 认证错误 |
| `4` | 积分不足 |
| `5` | 内容安全策略拒绝 |
| `6` | 任务失败；积分自动退回 |
| `7` | 网络错误 |
| `8` | 资源不存在 |
| `9` | 触发限流；应退避后重试 |

</details>

## 自动化环境变量

日常交互使用不需要配置环境变量，它们主要用于 CI、脚本和进阶 Agent 工作流。切记：不要把 API Key 提交到代码仓库、粘贴进文档，或包含在截图和日志中。

<details>
<summary><strong>展开环境变量表</strong></summary>

| 变量 | 用途 |
| --- | --- |
| `TRIPO_API_KEY` | API Key；优先级最高，适合 CI 或 Agent |
| `TRIPO_PROFILE` | 命名账号配置，等价于 `--profile` |
| `TRIPO_REGION` | 可选的 `ov` 或 `cn` 覆盖；通常由 CLI 自动识别 |
| `TRIPO_API_BASE_URL` | 覆盖 API 地址 |
| `TRIPO_PLATFORM_BASE_URL` | 覆盖平台地址 |
| `TRIPO_HOME` | 配置和历史目录，默认为 `~/.tripo` |
| `TRIPO_LLM_BASE_URL` | `tripo ai` 可选的 OpenAI 兼容接口 |
| `TRIPO_LLM_API_KEY` | `tripo ai` 可选的 LLM Key |
| `TRIPO_LLM_MODEL` | `tripo ai` 可选的 LLM 模型 |

</details>

=== FILE: codex-plugin.md ===
# 在 Codex 里使用 Tripo

像跟人说话一样对 Codex 下指令。你描述想要的 3D 模型，**Tripo 3D** 插件会生成它，并把文件存进你的项目。不需要懂 API、终端，也不需要会 3D 软件。

这是一份从零开始的逐步说明。请按顺序做；某一步没成功，先解决再往下。

> ChatGPT 与 Codex 在中国大陆不可用。本插件连接的是**海外** Tripo 服务（[developers.tripo3d.ai](https://developers.tripo3d.ai)）。请在能够打开 Codex 的环境里跟随本页操作。

## 开始前你需要准备什么

1. **一台电脑**（Mac 或 Windows）。
2. **Codex**：OpenAI 的编程助手。它在 ChatGPT 桌面应用或 Codex CLI 里，**不是**普通的 ChatGPT 对话窗口。
3. **Node.js 20 或更高版本**。插件会在后台用到它，你不用写 Node 代码。
4. **一个 Tripo 海外账号**。新账号会送免费积分。没有账号就先到 [developers.tripo3d.ai](https://developers.tripo3d.ai) 注册。

先检查 Node.js。打开「终端」（Mac）或 PowerShell（Windows），输入：

```bash
node -v
```

应看到类似 `v20.11.0` 或更高的版本号。如果提示找不到命令，到 [nodejs.org](https://nodejs.org/) 安装 LTS 版本，然后**关掉终端再打开**，再试一次。

安装插件和登录都是免费的。**真正生成模型时会消耗 Tripo 积分。**

## 第 1 步：打开 Codex，不要留在 ChatGPT 对话里

这是最常见的踩坑点。

1. 打开 **ChatGPT 桌面应用**（或 Codex CLI）。
2. 切换到 **Codex**。
3. 打开你希望 3D 文件出现的那个文件夹。还没有项目的话，新建一个空文件夹并打开它。

如果一直停在普通 ChatGPT 对话里，Tripo 插件不会出现。这是正常的：这个插件只在 Codex 里生效。

## 第 2 步：安装 Tripo 3D 插件

1. 在 Codex 里打开 **Plugins（插件）**。
2. 打开 **Plugins Directory（插件目录）**。
3. 搜索 **Tripo 3D**。
4. 安装，并确认它是 **enabled（已启用）**。

![Codex 插件目录中搜索“tripo”的结果，Tripo 3D 插件已高亮](/assets/images/docs/codex-plugin/plugin-search-zh.webp)

安装成功后，你会看到两类能力：生成 3D 资产，以及制作游戏向资产。不需要逐个开关，保持插件启用不关即可。

![Codex 中 Tripo 3D 插件的详情页，右上角是 Install plugin 按钮，下方列出两项技能](/assets/images/docs/codex-plugin/plugin-detail.webp)

<details>
<summary><strong>遇到问题？</strong> 找不到 Tripo 3D</summary>

- 确认你在 **Codex** 里，而不是 ChatGPT 对话。
- 完全退出 ChatGPT 桌面应用再打开，然后重新搜索。
- 如果仍然没有，改用 [Tripo CLI](/zh/docs/cli)。那是同一套生成引擎，只是在终端里操作。

</details>

## 第 3 步：发送第一条消息

把下面整段复制进 Codex：

```text
我想要一个带贴图的低多边形宝箱，把 GLB 文件存到 ./assets 文件夹。
如果 Tripo 还没配置好，请按我完全没接触过的程度，一步一步带我做完。
不要让我把 API Key 粘贴到对话里。
```

发送。接下来 Codex 通常会：

1. 检查这台电脑上 Tripo 是否就绪。
2. 如果你还没登录，给出一个**验证链接**和一组**一次性验证码**。
3. 等你在浏览器里完成登录。
4. 生成模型，并写入 `./assets`。

**永远不要把 API Key 粘到对话里。** 插件不需要你这么做。如果 Codex 向你要密钥，回复：`请用浏览器登录。不要向我要 Key。`

## 第 4 步：在浏览器里完成登录（只需第一次）

当 Codex 给出链接和验证码时，请你自己完成下面点击。**不要关掉 Codex**，也不要中止它正在跑的命令。

1. 在浏览器中打开那条验证链接。
2. 如果页面要求登录，先到 [developers.tripo3d.ai](https://developers.tripo3d.ai) 登录或注册，再回到验证页。
3. 把一次性验证码填进 **Verification code（验证码）** 输入框。必须和 Codex 里显示的**完全一致**。
4. 如果账号里已经有 API Key，任选一把即可；如果还没有，系统会自动创建，不用选。
5. 点击 **Authorize（授权）**。

![显示验证码的 Tripo CLI 浏览器设备授权页面](/assets/images/docs/cli/device-authorization-zh.webp)

授权成功后，Codex 会自己继续，你不用把任何内容复制回对话。

验证码过一段时间会失效。失败了就对 Codex 说：`请重新登录 Tripo。`

<details>
<summary><strong>遇到问题？</strong> 浏览器没打开，或登录没完成</summary>

- 把 Codex 给出的链接复制到浏览器地址栏打开。
- 页面上的验证码必须和 Codex 里的一致。拿不准就让 Codex 重新登录，换一组新码。
- 让 Codex 继续等待。登录最长可能要几分钟；中途停掉等于作废这组码。

</details>

## 第 5 步：等文件生成，然后打开看看

保持 Codex 开着。第一次生成常常要几分钟。Codex 是在等 Tripo 做完，不是卡死。

完成后，Codex 一般会：

- 告诉你文件保存在哪里（通常是 `./assets`）
- 说明这次花了多少积分
- 如果有预览图，会看一眼效果

打开那个文件夹，通常能看到：

- 模型文件，例如 `model.glb`
- `preview.png`：模型的预览图
- `task.json`：这次任务的记录

预览图不对的话，对 Codex 说：`这不是我想要的，换个种子再试一次。`

## 接下来可以这样说

用日常语言即可。下面几条可以直接复制。

**把图片变成 3D**（先把 `concept.png` 放到项目文件夹里）：

```text
把 concept.png 变成 3D 模型，保存到 ./assets。
```

**接着上一次的模型继续做**（不会从头再生成一遍，更省积分）：

```text
基于刚才那个模型，再做一个 1500 面的 LOD，保存到 ./assets。
```

**游戏占位道具，并写进代码：**

```text
给我的场景做三个占位道具，存成 ./assets 里的 GLB，然后在项目代码里加载它们。
```

一次要好几个模型时，Codex 应**先问你确认**再花积分。这是正常行为。

## 出问题了怎么办

| 你看到的情况 | 怎么处理 |
| --- | --- |
| 插件根本不出现 | 你还在 ChatGPT 对话里。切到 Codex。 |
| Codex 让你粘贴 API Key | 拒绝。回复：`请用浏览器登录，不要向我要 Key。` |
| 登录页没有反应 | 把 Codex 里的链接粘到浏览器。核对验证码是否一致。 |
| 提示积分不足 | 模型没有生成完。到 [海外控制台](https://developers.tripo3d.ai) 充值后，让 Codex 再试。 |
| 生成做到一半失败 | 失败任务的积分会自动退回。让 Codex 再试一次。 |
| 文件不在项目里 | 明确告诉它路径，例如 `保存到 ./assets`。 |
| 效果不好 | 让 Codex 重做。不要让它一声不响地连着重试很多遍。 |

## 相关页面

- [Tripo CLI](/zh/docs/cli) — 同一套引擎，在终端里使用
- [插件](/zh/docs/plugins) — Unity、Blender 等编辑器插件
- [认证方式](/zh/docs/authentication) — API Key 说明（用 Codex 时一般用不到）
- [计费说明](/zh/docs/billing) — 积分如何计算

=== FILE: comfyui-nodes.md ===
# ComfyUI 节点

ComfyUI-Tripo 是 Tripo 官方提供的 ComfyUI 自定义节点扩展，可在 ComfyUI 工作流中通过文本、单张图片或多视图图片生成 3D 模型，并支持模型导入、贴图、精修、网格处理、低模化、风格化、绑骨、动画重定向、格式转换和重拓扑。

| 项目 | 值 |
| --- | --- |
| Node 项目版本 | <code>1.3.0</code> |
| 源码标签 | <code>v1.3.1.1</code> |
| 源码仓库 | [VAST-AI-Research/ComfyUI-Tripo](https://github.com/VAST-AI-Research/ComfyUI-Tripo) |

## 功能与变更记录

### 功能

- 根据文本提示生成 3D 模型。
- 根据图片生成 3D 模型。
- 通过 <code>model_url</code> 从 URL 导入模型。
- 支持模型拆件能力。
- 为 3D 模型绑骨并生成动画。
- 转换模型格式并重新拓扑。

### 变更记录

- 2026-06-30：新增 Mesh Segmentation v2.0 模型拆件，并支持通过 <code>model_url</code> 直接导入 URL。
- 2026-05-28：新增模型导入。
- 2025-06-19：更新到最新 API，并增加更多节点。
- 2025-03-31：改用 <code>tripo3d</code> 包。
- 2025-02-24：移除 <code>glbviewer</code>。
- 2025-02-01：适配新版 API，并改用 Preview 3D 查看模型。
- 2024-11-11：适配新版 API。
- 2024-10-14：新增模型转换。
- 2024-09-13：支持 <code>model_version</code> <code>v2.0-20240919</code>。

## 安装方式

**任选一种**方式安装，完成后重启 ComfyUI。

### ComfyUI-Manager

打开 [Custom Nodes Manager](https://github.com/ltdrdata/ComfyUI-Manager)，搜索 <code>Tripo for ComfyUI</code> 并安装。

### comfy-cli

通过 [Comfy Registry](https://registry.comfy.org/) 安装 [comfy-cli](https://github.com/Comfy-Org/comfy-cli)，然后执行：

~~~bash
comfy node registry-install comfyui-tripo
~~~

### 从源码安装

将仓库放到 <code>ComfyUI/custom_nodes/ComfyUI-Tripo</code>，然后安装依赖：

~~~bash
cd ComfyUI/custom_nodes
git clone https://github.com/VAST-AI-Research/ComfyUI-Tripo.git
python -m pip install -r ComfyUI-Tripo/requirements.txt
~~~

## API Key 配置

先在 [Tripo 平台](https://platform.tripo3d.ai/)创建 API Key，再使用以下任一方式配置。

节点项目按以下顺序获取 API Key：

1. 节点中非空的 <code>apikey</code> 输入。
2. <code>TRIPO_API_KEY</code> 环境变量。
3. ComfyUI-Tripo 项目目录中 <code>config.json</code> 的 <code>TRIPO_API_KEY</code> 字段。

Generate 和 Import 节点提供 <code>apikey</code> 输入；下游节点通过 <code>MODEL_INFO</code> 接收已经解析的 Key。

不得在截图、共享工作流、日志或代码仓库中暴露真实 API Key。共享工作流前应清空 <code>apikey</code>，本地使用优先选择环境变量。

### 环境变量启动示例

Windows：

~~~shell
set TRIPO_API_KEY=tsk_XXXXXXX
python.exe main.py [--cpu]
~~~

Linux 或 macOS：

~~~bash
TRIPO_API_KEY=tsk_XXXXXXX python main.py [--cpu]
~~~

## 节点总览

ComfyUI-Tripo 提供以下 11 个 Tripo 节点：

| 内部 ID | 界面名称 | 能力 | 输出 |
| --- | --- | --- | --- |
| <code>TripoAPIDraft</code> | Tripo: Generate model | 文本、图片或多视图生成模型 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoImportModel</code> | Tripo: Import model | 导入本地模型或模型 URL | <code>MODEL_INFO</code> |
| <code>TripoTextureModel</code> | Tripo: Texture model | 模型贴图 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoRefineModel</code> | Tripo: Refine Draft model | 草模精修 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoMeshSegmentation</code> | Tripo: Segment mesh | 网格分割 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoMeshCompletion</code> | Tripo: Complete mesh | 网格补全 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoSmartLowPoly</code> | Tripo: Smart low poly | 智能低模 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoStylizeModel</code> | Tripo: Stylize model | 模型风格化 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoAnimateRigNode</code> | Tripo: Rig model | 自动绑骨 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoAnimateRetargetNode</code> | Tripo: Retarget rigged model | 动画重定向 | <code>model_file</code>、<code>MODEL_INFO</code> |
| <code>TripoConvertNode</code> | Tripo: Convert model | 模型格式转换与导出 | <code>model_file</code> |

Preview 3D 是 ComfyUI 提供的预览节点，不计入以上 11 个 Tripo Node。

## 节点连接与数据流

~~~mermaid
flowchart LR
    G["Generate model"] -->|MODEL_INFO| P["模型处理"]
    I["Import model"] -->|MODEL_INFO| P
    P -->|MODEL_INFO| R["Rig model"]
    R -->|MODEL_INFO| A["Retarget rigged model"]
    A -->|MODEL_INFO| C["Convert model"]
~~~

- <code>model_file</code> 是生成或处理任务下载后的文件路径，可连接 ComfyUI 的预览或文件处理节点。
- <code>MODEL_INFO</code> 是下游 Tripo Node 使用的任务上下文，包含 <code>task_id</code>、解析后的 <code>apikey</code>、<code>file_prefix</code> 和 <code>output_directory</code>。
- 来自节点链外部的普通模型必须先经过 <code>TripoImportModel</code>；单独的文件路径不能替代 <code>MODEL_INFO</code>。
- 需要继续执行 Tripo 处理时应连接 <code>MODEL_INFO</code>，而不是把 <code>model_file</code> 当作任务上下文。

## 完整节点参数

“必填”表示节点参数是否必须提供；<code>apikey</code> 可留空以使用环境变量或配置文件回退。“—”表示没有显式默认值。

### 生成与导入

### TripoAPIDraft — Tripo: Generate model

创建工作流中的第一个 Tripo 任务，无前置节点。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>mode</code> | ENUM | 是 | 第一个枚举值 | <code>text_to_model</code>、<code>image_to_model</code>、<code>multiview_to_model</code> |
| <code>apikey</code> | STRING | 是 | 空 | API Key 或回退配置 |
| <code>prompt</code> | STRING，多行 | 否 | 空 | 文本提示词 |
| <code>negative_prompt</code> | STRING，多行 | 否 | 空 | 负向提示词 |
| <code>image</code> | IMAGE | 否 | — | 单图输入；多视图模式下为正面图 |
| <code>image_left</code> | IMAGE | 否 | — | 可选左视图 |
| <code>image_back</code> | IMAGE | 否 | — | 可选后视图 |
| <code>image_right</code> | IMAGE | 否 | — | 可选右视图 |
| <code>model_version</code> | ENUM | 否 | <code>v3.1-20260211</code> | <code>v1.4-20240625</code>、<code>v2.0-20240919</code>、<code>v2.5-20250123</code>、<code>v3.0-20250812</code>、<code>v3.1-20260211</code> |
| <code>texture</code> | BOOLEAN | 否 | <code>true</code> | 是否生成贴图 |
| <code>pbr</code> | BOOLEAN | 否 | <code>true</code> | 是否生成 PBR 贴图 |
| <code>image_seed</code> | INT | 否 | <code>42</code> | 文本模式使用的图像种子 |
| <code>model_seed</code> | INT | 否 | <code>42</code> | 模型种子 |
| <code>texture_seed</code> | INT | 否 | <code>42</code> | 贴图种子 |
| <code>texture_quality</code> | ENUM | 否 | <code>standard</code> | <code>standard</code>、<code>detailed</code> |
| <code>geometry_quality</code> | ENUM | 否 | <code>standard</code> | <code>standard</code>、<code>detailed</code>；仅图片模式 |
| <code>texture_alignment</code> | ENUM | 否 | <code>original_image</code> | <code>original_image</code>、<code>geometry</code> |
| <code>face_limit</code> | INT | 否 | <code>-1</code> | <code>-1</code>–<code>500000</code>；小于等于 0 时按未设置传递 |
| <code>quad</code> | BOOLEAN | 否 | <code>false</code> | 是否请求四边面拓扑 |
| <code>compress</code> | BOOLEAN | 否 | <code>false</code> | 是否压缩输出 |
| <code>generate_parts</code> | BOOLEAN | 否 | <code>false</code> | 是否生成部件 |
| <code>smart_low_poly</code> | BOOLEAN | 否 | <code>false</code> | 是否启用智能低模 |
| <code>auto_size</code> | BOOLEAN | 否 | <code>false</code> | 是否自动调整模型尺寸 |
| <code>orientation</code> | ENUM | 否 | <code>default</code> | <code>default</code>、<code>align_image</code>；图片和多视图模式 |
| <code>file_prefix</code> | STRING | 否 | 空 | 下载文件名前缀 |
| <code>output_directory</code> | STRING | 否 | 空 | 目标目录覆盖值 |

模式限制：

| 模式 | 条件必填输入 | 说明 |
| --- | --- | --- |
| <code>text_to_model</code> | <code>prompt</code> | 为空时提示 “Prompt is required” |
| <code>image_to_model</code> | <code>image</code> | 缺失时提示 “Image is required” |
| <code>multiview_to_model</code> | <code>image</code> | <code>image</code> 是正面图；左、后、右视图可选 |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。常见失败：条件输入缺失、API Key 缺失或无效、API 任务失败、输出文件移动失败。最小连接：提示词或图片 → <code>TripoAPIDraft</code> → Preview 3D；需要后处理时连接 <code>MODEL_INFO</code>。

### TripoImportModel — Tripo: Import model

为不在当前节点链中产生的模型建立 Tripo 任务上下文。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>apikey</code> | STRING | 是 | 空 | API Key 或回退配置 |
| <code>model_file</code> | 文件选择 | 否 | <code>none</code> | ComfyUI 输入目录中的模型 |
| <code>model_url</code> | STRING | 否 | 空 | 模型直链 |
| <code>file_prefix</code> | STRING | 否 | 空 | 传递给下游下载文件的前缀 |
| <code>output_directory</code> | STRING | 否 | 空 | 传递给下游下载文件的目录 |

非空 <code>model_url</code> 的优先级高于 <code>model_file</code>；二者都为空时节点失败。上传控件接受 <code>.glb</code>、<code>.fbx</code>、<code>.obj</code>、<code>.stl</code>、<code>.ply</code>、<code>.3mf</code> 和 <code>.gltf</code>，后端输入扫描还识别 <code>.zip</code>。

输出：仅 <code>MODEL_INFO</code>。常见失败：没有提供来源、本地文件不存在、URL 无法获取、格式被拒绝或导入任务失败。最小连接：本地文件或 URL → <code>TripoImportModel</code> → 任意接收 <code>MODEL_INFO</code> 的处理节点。

### 模型处理

### TripoTextureModel — Tripo: Texture model

需要来自 Generate、Import 或兼容处理节点的 <code>MODEL_INFO</code>。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>model_version</code> | ENUM | 否 | <code>v3.0-20250812</code> | <code>v2.5-20250123</code>、<code>v3.0-20250812</code> |
| <code>texture</code> | BOOLEAN | 否 | <code>true</code> | 是否启用贴图 |
| <code>pbr</code> | BOOLEAN | 否 | <code>true</code> | 是否生成 PBR 贴图 |
| <code>texture_seed</code> | INT | 否 | <code>42</code> | 贴图种子 |
| <code>texture_quality</code> | ENUM | 否 | <code>standard</code> | <code>standard</code>、<code>detailed</code> |
| <code>texture_alignment</code> | ENUM | 否 | <code>original_image</code> | <code>original_image</code>、<code>geometry</code> |
| <code>text_prompt</code> | STRING，多行 | 否 | 空 | 贴图引导文本 |
| <code>image_prompt</code> | IMAGE | 否 | — | 贴图参考图 |
| <code>style_image</code> | IMAGE | 否 | — | 风格参考图 |
| <code>part_names</code> | STRING，多行 | 否 | 空 | 每行一个部件名 |
| <code>compress</code> | BOOLEAN | 否 | <code>false</code> | 是否压缩输出 |
| <code>bake</code> | BOOLEAN | 否 | <code>true</code> | 是否烘焙贴图 |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。常见失败：任务上下文不兼容、参考图无效或 API 任务失败。最小连接：Generate/Import 的 <code>MODEL_INFO</code> → <code>TripoTextureModel</code> → Preview 3D 或其他处理节点。

### TripoRefineModel — Tripo: Refine Draft model

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 草模任务上下文 |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。上游任务必须是可精修的草模；上下文不兼容或 API 任务失败都会导致失败。最小连接：Generate 草模的 <code>MODEL_INFO</code> → <code>TripoRefineModel</code> → Preview 3D。

### TripoMeshSegmentation — Tripo: Segment mesh

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>model_version</code> | ENUM | 是 | <code>v1.0-20250506</code> | <code>v1.0-20250506</code>、<code>v2.0-20260430</code> |
| <code>segmentation_granularity</code> | ENUM | 否 | <code>balanced</code> | <code>simple</code>、<code>balanced</code>、<code>detailed</code> |
| <code>ref_image</code> | IMAGE | 否 | — | 分割参考图 |
| <code>split_by_connectivity</code> | BOOLEAN | 否 | <code>true</code> | 是否按连通性拆分 |

<code>segmentation_granularity</code>、<code>ref_image</code> 和 <code>split_by_connectivity</code> 只在 <code>v2.0-20260430</code> 下发送，v1 会忽略它们。输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。常见失败：模型不兼容、参考图无效或 API 任务失败。最小连接：Generate/Import 的 <code>MODEL_INFO</code> → <code>TripoMeshSegmentation</code> → Completion 或 Preview 3D。

### TripoMeshCompletion — Tripo: Complete mesh

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 分割模型任务上下文 |
| <code>model_version</code> | ENUM | 是 | <code>v1.0-20250506</code> | <code>v1.0-20250506</code> |
| <code>part_names</code> | STRING，多行 | 否 | 空 | 每行一个部件名 |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。任务不适合补全或 API 任务失败会导致失败。最小连接：Segment 的 <code>MODEL_INFO</code> → <code>TripoMeshCompletion</code> → Preview 3D。

### TripoSmartLowPoly — Tripo: Smart low poly

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>model_version</code> | ENUM | 是 | <code>P-v2.0-20251225</code> | <code>P-v2.0-20251225</code> |
| <code>quad</code> | BOOLEAN | 否 | <code>false</code> | 是否请求四边面拓扑 |
| <code>part_names</code> | STRING，多行 | 否 | 空 | 每行一个部件名 |
| <code>face_limit</code> | INT | 否 | <code>10000</code> | <code>-1</code>–<code>20000</code> |
| <code>bake</code> | BOOLEAN | 否 | <code>true</code> | 是否烘焙输出 |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。常见失败：模型或部件不兼容、API 任务失败。最小连接：Generate/Import 的 <code>MODEL_INFO</code> → <code>TripoSmartLowPoly</code> → Preview 3D 或 Convert。

### TripoStylizeModel — Tripo: Stylize model

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>style</code> | ENUM | 是 | 第一个枚举值 | <code>lego</code>、<code>voxel</code>、<code>voronoi</code>、<code>minecraft</code> |
| <code>block_size</code> | INT | 是 | <code>80</code> | <code>1</code>–<code>1000</code> |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。常见失败：模型不兼容、当前任务不支持指定风格或 API 任务失败。最小连接：Generate/Import 的 <code>MODEL_INFO</code> → <code>TripoStylizeModel</code> → Preview 3D。

### 绑骨与动画

### TripoAnimateRigNode — Tripo: Rig model

提交绑骨任务前，节点会先检查模型能否绑骨并获取 rig type。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>model_version</code> | ENUM | 是 | <code>v2.0-20250506</code> | <code>v1.0-20240301</code>、<code>v2.0-20250506</code> |
| <code>out_format</code> | ENUM | 是 | <code>glb</code> | <code>glb</code>、<code>fbx</code> |
| <code>spec</code> | ENUM | 是 | <code>tripo</code> | <code>mixamo</code>、<code>tripo</code> |

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。模型不可绑骨、找不到合适的 rig type 或 API 任务失败时会终止。最小连接：Generate/Import 的 <code>MODEL_INFO</code> → <code>TripoAnimateRigNode</code> → Retarget 或 Preview 3D。

### TripoAnimateRetargetNode — Tripo: Retarget rigged model

需要已经成功绑骨的模型对应的 <code>MODEL_INFO</code>。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 已绑骨模型的任务上下文 |
| <code>animation</code> | ENUM | 是 | 第一个枚举值 | 见下方 16 个预设 |
| <code>out_format</code> | ENUM | 是 | <code>glb</code> | <code>glb</code>、<code>fbx</code> |
| <code>bake_animation</code> | BOOLEAN | 否 | <code>true</code> | 是否烘焙动画 |
| <code>export_with_geometry</code> | BOOLEAN | 否 | <code>false</code> | 导出时是否包含几何体 |

16 个动画枚举为：<code>preset:idle</code>、<code>preset:walk</code>、<code>preset:run</code>、<code>preset:dive</code>、<code>preset:climb</code>、<code>preset:jump</code>、<code>preset:slash</code>、<code>preset:shoot</code>、<code>preset:hurt</code>、<code>preset:fall</code>、<code>preset:turn</code>、<code>preset:quadruped:walk</code>、<code>preset:hexapod:walk</code>、<code>preset:octopod:walk</code>、<code>preset:serpentine:march</code> 和 <code>preset:aquatic:march</code>。

输出：STRING <code>model_file</code> 和 <code>MODEL_INFO</code>。模型未绑骨、上下文不兼容或 API 任务失败会导致失败。最小连接：Rig 的 <code>MODEL_INFO</code> → <code>TripoAnimateRetargetNode</code> → Preview 3D 或 Convert。

### 格式输出

### TripoConvertNode — Tripo: Convert model

这是一个输出节点，不返回 <code>MODEL_INFO</code>。

| 输入参数 | 类型 | 必填 | 默认值 | 枚举或范围 |
| --- | --- | --- | --- | --- |
| <code>model_info</code> | MODEL_INFO | 是 | — | 上游任务上下文 |
| <code>format</code> | ENUM | 是 | 第一个枚举值 | <code>GLTF</code>、<code>USDZ</code>、<code>FBX</code>、<code>OBJ</code>、<code>STL</code>、<code>3MF</code> |
| <code>quad</code> | BOOLEAN | 否 | <code>false</code> | 是否请求四边面拓扑 |
| <code>force_symmetry</code> | BOOLEAN | 否 | <code>false</code> | 是否强制对称 |
| <code>face_limit</code> | INT | 否 | <code>-1</code> | <code>-1</code>–<code>500000</code> |
| <code>flatten_bottom</code> | BOOLEAN | 否 | <code>false</code> | 是否压平底部 |
| <code>flatten_bottom_threshold</code> | FLOAT | 否 | <code>0.01</code> | <code>0.0</code>–<code>1.0</code> |
| <code>texture_size</code> | INT | 否 | <code>4096</code> | <code>128</code>–<code>4096</code> |
| <code>texture_format</code> | ENUM | 否 | <code>JPEG</code> | <code>BMP</code>、<code>DPX</code>、<code>HDR</code>、<code>JPEG</code>、<code>OPEN_EXR</code>、<code>PNG</code>、<code>TARGA</code>、<code>TIFF</code>、<code>WEBP</code> |
| <code>pivot_to_center_bottom</code> | BOOLEAN | 否 | <code>false</code> | 是否把轴心移动到中心底部 |
| <code>scale_factor</code> | FLOAT | 否 | <code>1.0</code> | 最小值 <code>0</code> |
| <code>with_animation</code> | BOOLEAN | 否 | <code>true</code> | 是否保留动画 |
| <code>pack_uv</code> | BOOLEAN | 否 | <code>false</code> | 是否打包 UV |
| <code>bake</code> | BOOLEAN | 否 | <code>true</code> | 是否烘焙输出 |
| <code>part_names</code> | STRING，多行 | 否 | 空 | 每行一个部件名 |
| <code>fbx_preset</code> | ENUM | 否 | <code>blender</code> | <code>blender</code>、<code>mixamo</code>、<code>3dsmax</code> |
| <code>export_vertex_colors</code> | BOOLEAN | 否 | <code>false</code> | 是否导出顶点色 |
| <code>export_orientation</code> | ENUM | 否 | <code>+x</code> | <code>+x</code>、<code>+y</code>、<code>-x</code>、<code>-y</code> |
| <code>animate_in_place</code> | BOOLEAN | 否 | <code>false</code> | 是否原地导出动画 |

输出：STRING <code>model_file</code>。常见失败：源任务不支持目标转换、导出设置无效、API 任务或输出移动失败。最小连接：任意兼容的 <code>MODEL_INFO</code> → <code>TripoConvertNode</code>。

## 工作流示例

Preview 3D 仅作为可选的 ComfyUI 查看器，不计入 Tripo 节点数量。

~~~mermaid
flowchart LR
    T["文本"] --> GT["Generate model<br/>mode: text_to_model"]
    IM["图片"] --> GI["Generate model<br/>mode: image_to_model"]
    MV["正面图 + 可选视图"] --> GM["Generate model<br/>mode: multiview_to_model"]
    GT --> V["Preview 3D"]
    GI --> V
    GM --> V
~~~

1. **Text to Model：** 填写 <code>prompt</code>，选择 <code>text_to_model</code>，把 <code>model_file</code> 连接到 Preview 3D。
2. **Image to Model：** 将 IMAGE 连接到 <code>image</code>，选择 <code>image_to_model</code>，预览 <code>model_file</code>。
3. **Multiview to Model：** 正面图连接 <code>image</code>，可选视图依次连接 <code>image_left</code>、<code>image_back</code> 和 <code>image_right</code>。
4. **Texture Model：** Generate 或 Import → 用 <code>MODEL_INFO</code> 连接 Texture → 预览新的 <code>model_file</code>。
5. **Refine Model：** 生成兼容草模 → 用 <code>MODEL_INFO</code> 连接 Refine → 预览精修文件。
6. **Rig and Retarget：** Generate 或 Import → Rig → Retarget；两段都连接 <code>MODEL_INFO</code>，最后预览或 Convert。
7. **Import and Process：** 本地文件或 URL → Import → Segment/Smart low poly/Stylize/Texture。Import 返回任务上下文，不返回预览文件。
8. **Convert and Export：** 把 Generate、Import、模型处理、Rig 或 Retarget 最终输出的 <code>MODEL_INFO</code> 连接到 Convert，并选择输出格式。

### 官方工作流 PNG

以下 6 张 PNG 包含内嵌的 ComfyUI 工作流数据。通过下载链接保存原始 PNG 后，可以将文件拖入 ComfyUI 或手动加载。截图中的参数值仅为工作流示例，实际默认值请查看上方参数表。

#### Text to Mesh

![Tripo Generate model 连接 Preview 3D 的 ComfyUI 文本生成模型工作流](/assets/images/docs/comfyui-nodes/text_to_model.png)

根据文本提示生成模型，并把 <code>model_file</code> 连接到 Preview 3D。

<a href="/assets/images/docs/comfyui-nodes/text_to_model.png" download>下载原始工作流 PNG</a>

#### Image to Mesh

![Load Image、Tripo Generate model 和 Preview 3D 组成的 ComfyUI 图片生成模型工作流](/assets/images/docs/comfyui-nodes/image_to_model.png)

加载图片，将其连接到 <code>image_to_model</code> 模式的 Generate model，并预览结果。

<a href="/assets/images/docs/comfyui-nodes/image_to_model.png" download>下载原始工作流 PNG</a>

#### Multiview Images to Mesh

![三个 Load Image 节点连接 Tripo Generate model 和 Preview 3D 的 ComfyUI 多视图工作流](/assets/images/docs/comfyui-nodes/multiview_to_model.png)

把正面图和可选侧视图连接到 <code>multiview_to_model</code> 模式的 Generate model。

<a href="/assets/images/docs/comfyui-nodes/multiview_to_model.png" download>下载原始工作流 PNG</a>

#### Texture a generated model

![Generate model 连接 Texture model 并分别连接 Preview 3D 的 ComfyUI 贴图工作流](/assets/images/docs/comfyui-nodes/texture_model.png)

把 Generate model 的 <code>MODEL_INFO</code> 传给 Texture model，并预览处理前后的输出。

<a href="/assets/images/docs/comfyui-nodes/texture_model.png" download>下载原始工作流 PNG</a>

#### Refine a draft Mesh

![草模 Generate model 任务连接 Refine Draft model 和 Preview 3D 的 ComfyUI 精修工作流](/assets/images/docs/comfyui-nodes/refine_model.png)

生成兼容草模，把 <code>MODEL_INFO</code> 传给 Refine Draft model，并预览精修后的文件。

<a href="/assets/images/docs/comfyui-nodes/refine_model.png" download>下载原始工作流 PNG</a>

#### Animation / Rig and export

![Generate model、Rig model、Preview 3D 和 Convert model 组成的 ComfyUI 绑骨与导出工作流](/assets/images/docs/comfyui-nodes/retarget.png)

<a href="/assets/images/docs/comfyui-nodes/retarget.png" download>下载原始工作流 PNG</a>

## 输出与排障

默认情况下，下载的模型写入 <code>ComfyUI/output</code>。Generate 和 Import 确定 <code>file_prefix</code> 与 <code>output_directory</code>，并通过下游 <code>MODEL_INFO</code> 持续传递。非空前缀会添加到下载文件名开头；非空目录会把文件移动到该目录，目录不存在时会尝试创建。

| 现象 | 检查项 |
| --- | --- |
| <code>TRIPO API key is required</code> | 设置非空节点 Key、<code>TRIPO_API_KEY</code> 或 <code>config.json</code> 中的字段。 |
| 提示缺少 Prompt/正面图 | 检查 <code>mode</code> 与条件必填输入是否匹配。 |
| Import 不启动 | 提供可访问的 <code>model_url</code> 或存在的 <code>model_file</code>；URL 优先。 |
| 模型不可绑骨 | 改用适合的角色模型；riggable 检查失败或没有 rig type 时 Rig 会终止。 |
| API 任务失败 | 查看返回的 <code>error_code</code> 和 <code>error_msg</code>，同时检查账号权限与余额。 |
| 输出无法移动 | 检查 <code>output_directory</code> 是否有效、可写，以及源文件是否仍然存在。 |
| 节点没有出现 | 重启 ComfyUI，核对仓库目录，并安装 <code>requirements.txt</code>。 |
| Import 上传按钮失败 | 核对上传控件支持的扩展名，并查看 ComfyUI 上传响应。 |

=== FILE: error-handling.md ===
# 错误处理

## 统一错误响应格式

所有 API 错误返回统一的 JSON 格式：

```json
{
  "code": 2010,
  "message": "Insufficient credits",
  "suggestion": "Please top up your account at https://platform.tripo3d.ai",
  "request_id": "req_abc123"
}
```

| 字段 | 类型 | 说明 |
| :-: | :-: | :-: |
| code | integer | 错误码 |
| message | string | 错误描述 |
| suggestion | string | 修复建议 |
| request_id | string | 请求唯一标识，用于排查问题 |

## HTTP 状态码

| 状态码 | 含义 | 说明 |
| :-: | :-: | :-: |
| 200 | 成功 | 请求处理成功 |
| 400 | 参数错误 | 请求参数缺失或格式不合法 |
| 401 | 未认证 | API Key 缺失或无效 |
| 403 | 权限不足 | 无权访问该资源或积分不足 |
| 404 | 资源不存在 | 请求的任务或资源不存在 |
| 429 | 请求过多 | 触发速率限制，请降低请求频率 |
| 500 | 服务错误 | 服务端内部错误，请稍后重试 |

## 错误码表

| 错误码 | 含义 | 建议处理方式 |
| :-: | :-: | :-: |
| 1000 | API Key 无效 | 检查 API Key 是否正确，是否已被删除 |
| 1001 | 未授权 | 检查请求头中是否携带了 Authorization |
| 2000 | 超过速率限制 | 降低请求频率，实施指数退避重试 |
| 2002 | 不支持的请求参数 | 检查请求体字段名和值是否符合文档要求 |
| 2003 | 输入文件为空 | 确认上传的文件不为空且格式正确 |
| 2004 | 不支持的文件类型 | 检查文件格式是否在支持列表内 |
| 2008 | 内容政策违规 | 修改输入内容，避免违规词汇或图片 |
| 2010 | 积分不足 | 前往控制台充值积分 |
| 2015 | 版本已弃用 | 升级到最新 API 版本 |
| 2018 | 模型太复杂 | 降低输入模型的复杂度或面数 |

## 错误处理示例

### Python

```python
import time
import requests

def call_api_with_retry(url, headers, payload=None, max_retries=3):
    for attempt in range(max_retries):
        if payload:
            response = requests.post(url, headers=headers, json=payload)
        else:
            response = requests.get(url, headers=headers)

        if response.status_code == 200:
            return response.json()

        if response.status_code == 429:
            wait = 2 ** attempt
            print(f"触发限流，{wait} 秒后重试...")
            time.sleep(wait)
            continue

        error = response.json()
        raise Exception(
            f"API 错误 [{error['code']}]: {error['message']} "
            f"(建议: {error.get('suggestion', '无')})"
        )

    raise Exception("重试次数已用尽")
```

### JavaScript

```javascript
async function callApiWithRetry(url, options, maxRetries = 3) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const response = await fetch(url, options);

    if (response.ok) {
      return await response.json();
    }

    if (response.status === 429) {
      const wait = 2 ** attempt * 1000;
      console.log(`触发限流，${wait / 1000} 秒后重试...`);
      await new Promise(resolve => setTimeout(resolve, wait));
      continue;
    }

    const error = await response.json();
    throw new Error(
      `API 错误 [${error.code}]: ${error.message} (建议: ${error.suggestion || "无"})`
    );
  }

  throw new Error("重试次数已用尽");
}
```

## 重试策略建议

对于可重试的错误（429 限流、500 服务错误），建议使用指数退避策略：

1. 第 1 次重试：等待 1 秒
2. 第 2 次重试：等待 2 秒
3. 第 3 次重试：等待 4 秒
4. 最大重试次数不超过 5 次

对于不可重试的错误（400、401、403），应直接抛出异常并修复问题。

=== FILE: files-presign.md ===
# 文件上传(大文件)

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /files/presign`

获取预签名上传 URL，文件直传存储——**大文件上传性能更优**。 客户端无需 SDK，仅需标准 HTTP PUT 即可完成上传。 建议文件超过 60MB 时使用；小文件也可使用 文件上传（multipart，最大 150MB）。上传流程
- 调用 `POST /v3/files/presign`，传入 `format`，获取 `presigned_url` 与 `file_token`。
- 使用 **HTTP PUT** 将文件直传到 `presigned_url`（直达存储，无需 Auth 头）。
- 在后续 API 的 `input` 字段中使用 `file_token`（如 导入模型、重拓扑、格式转换）。




## Request Parameters

### format

- **Type:** string
- **Required:** 必选

文件扩展名，不含前导点（如 glb、fbx、png）。


- 图片：`jpeg`、`jpg`、`png`、`webp`、`bmp`、`tiff`。
- 模型：`glb`、`gltf`、`fbx`、`obj`、`stl`、`3mf`、`usdz`。


## Response Fields

### presigned_url

- **Type:** string
- **Required:** 必选

预签名 PUT URL，30 分钟内有效。客户端使用 HTTP PUT 直传文件到该 URL。
### file_token

- **Type:** string
- **Required:** 必选

文件引用 token（如 `file_abc123`）。上传完成后在其他 API 的 `input` 字段中使用。
### expires_in

- **Type:** integer
- **Required:** 必选

预签名 URL 有效期（秒），固定为 1800（30 分钟）。

## Request Example

### curl

```
# Step 1: Get presigned URL
curl -s -X POST \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"format":"glb"}' \
  https://openapi.tripo3d.com/v3/files/presign

# Step 2: Upload file directly to storage (no Auth needed)
curl -X PUT \
  -H "Content-Type: application/octet-stream" \
  -T model.glb \
  "<presigned_url from step 1>"

# Step 3: Create task using file_token
curl -s -X POST \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"default","input":"<file_token from step 1>"}' \
  https://openapi.tripo3d.com/v3/models/import
```

### Python

```
import requests

API_KEY = "YOUR_API_KEY"
BASE = "https://openapi.tripo3d.com"
headers = {"Authorization": f"Bearer {API_KEY}"}

# 1. Get presigned URL
resp = requests.post(f"{BASE}/v3/files/presign",
                     json={"format": "glb"}, headers=headers)
data = resp.json()["data"]
presigned_url = data["presigned_url"]
file_token = data["file_token"]

# 2. Upload file directly to storage
with open("model.glb", "rb") as f:
    put_resp = requests.put(presigned_url, data=f,
                            headers={"Content-Type": "application/octet-stream"})
    assert put_resp.status_code == 200

# 3. Create task with file_token
task_resp = requests.post(f"{BASE}/v3/models/import",
    json={"model": "default", "input": file_token},
    headers=headers)
print(task_resp.json())
```

### JavaScript

```
import fs from 'fs';

const API_KEY = 'YOUR_API_KEY';
const BASE = 'https://openapi.tripo3d.com';

// 1. Get presigned URL
const presignRes = await fetch(`${BASE}/v3/files/presign`, {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
  body: JSON.stringify({ format: 'glb' }),
});
const { data } = await presignRes.json();
const { presigned_url, file_token } = data;

// 2. Upload file directly to storage
const fileBuffer = fs.readFileSync('model.glb');
await fetch(presigned_url, {
  method: 'PUT',
  headers: { 'Content-Type': 'application/octet-stream' },
  body: fileBuffer,
});

// 3. Create task with file_token
const taskRes = await fetch(`${BASE}/v3/models/import`, {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
  body: JSON.stringify({ model: 'default', input: file_token }),
});
console.log(await taskRes.json());
```


## Response Example

### 预签名响应

```json
{
  "code": 0,
  "data": {
    "presigned_url": "https://storage.example.com/bucket/path/input.glb?X-Amz-Signature=...",
    "file_token": "file_abc123",
    "expires_in": 1800
  }
}
```

=== FILE: files.md ===
# 文件管理

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /files`

上传文件并获取 file_token 以供后续 API 调用使用。

## Request Parameters

### file

- **Type:** binary
- **Required:** 必选

文件数据。使用 `multipart/form-data` 编码。


- 图片：`JPEG`、`PNG`。最大 **20 MB**。
- 模型：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`。最大 **150 MB**。
- 建议 > 60MB 的文件，可以参考文件上传(大文件)，有更快的性能体验。


## Response Fields

### file_token

- **Type:** string
- **Required:** 必选

文件引用 token（如 `file_abc123`）。在其他 API 调用的 `input` 字段中使用。

## Request Example

### 上传示例

```
curl -s \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -F "file=@product-photo.png" \
  https://openapi.tripo3d.com/v3/files
```


## Response Example

### 上传示例

```json
{
  "code": 0,
  "data": {
    "file_token": "file_abc123"
  }
}
```

=== FILE: generation-edit-multiview.md ===
# 编辑多视图

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/edit-multiview`

编辑现有的多视图图像。在所有视图间应用一致的修改。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

要编辑的多视图源图像。接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前多视图生成任务返回的任务 ID。系统会自动使用输出的多视图图像。如需先生成多视图图像，请使用 图像生成多视图 API。
示例： `task_abc123`
- file_token：先通过文件上传 API上传多视图图像。
示例： `file_abc123`
- URL：可公开访问的多视图图像直链。
示例： `https://example.com/multiview.png`

### prompts

- **Type:** object[]
- **Required:** 必选

编辑指令列表，每条指令针对一个特定视角。每个元素包含：
- prompt：描述所需变更的编辑指令。
示例： `将衬衫颜色改为红色`
- view：要应用编辑的视角。
- `front`：正面
- `left`：左侧
- `back`：背面
- `right`：右侧



## Request Example

### 编辑视图

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/edit-multiview \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "prompts": [
    {
      "prompt": "change the shirt color to red",
      "view": "front"
    },
    {
      "prompt": "add a logo on the back",
      "view": "back"
    }
  ]
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

=== FILE: generation-image-to-image.md ===
# 图像生成图像

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/image-to-image`

根据参考图像生成或编辑图像。支持编辑、风格迁移和多图融合。

## Request Parameters

### model

- **Type:** string
- **Required:** 可选
- **Default:** `seedream_v5`

图像编辑模型。
- `seedream_v5` — 最强编辑、风格迁移与多图融合能力。
- `banana` — 快速编辑。
- `banana_pro` — 更高质量编辑。
- `banana2` — 最新快速编辑。
- `chat_image_1` — 基础图像编辑。**2026-10-23 下线。**
- `chat_image_1.5` — 更高质量编辑。**2026-12-01 下线。**
- `chat_image_2` — 最新，质量最佳编辑。
- `chat_image_2.5_flare` — 2.5 系列速度档，与 sunburst 同等成本下明显更快。
- `chat_image_2.5_sunburst` — 2.5 系列精修档，对未指定修改的部分保持得最接近原图。

### input

- **Type:** string
- **Required:** 必选

主要参考图像。接受公开 URL、`file_token` 或 `task_id`。**以上三种方式任选其一**，不可同时传入多种类型。



- Formats: `jpeg`, `png` (recommended); `webp` is rejected on some provider routes
- Max file size: **20 MB**
- Max total pixels: **6000 × 6000 = 36 MP**
- Min width/height: 14 px
- Aspect ratio (W/H): **[1/3, 3]**
- URL images must be publicly accessible. Private files require `/v3/files` first.

### inputs

- **Type:** string[]
- **Required:** 可选

多张参考图像。每张图像的格式与 `input` 相同。


- 最多：**4** 张（seedream），**10** 张（banana），**16** 张（chat_image）
- 引用方式：`image[1]`、`image[2]` 等。

### prompt

- **Type:** string
- **Required:** 条件必填

编辑指令。**未指定模板时必填。**
### size

- **Type:** string
- **Required:** 可选
- **Default:** `2048x2048`

输出图像尺寸。可传语义关键字（如 2K / 4K）或精确像素（如 2048x2048）；不同模型支持的取值不同，见下方分模型。
### quality

- **Type:** string
- **Required:** 可选
- **Default:** `low`

渲染质量档位。仅 `chat_image_2`、`chat_image_2.5_flare`、`chat_image_2.5_sunburst` 支持该参数，其它模型传入会直接报错。


- `chat_image_2` — `low`、`medium`、`high`。
- `chat_image_2.5_flare` / `chat_image_2.5_sunburst` — `low`、`medium`、`high`、`xhigh`、`max`。
不传等同于 `low`。请注意这与 OpenAI 官方默认的 `auto` 不同，且本接口**不支持** `auto` —— 计价需要在请求前就确定档位。

`high`、`xhigh`、`max` 会消耗更多积分且耗时明显增加；`low` 与 `medium` 按基础价计费。详见定价页。



### background

- **Type:** string
- **Required:** 可选

背景处理方式。仅 `chat_image_2.5_flare` 与 `chat_image_2.5_sunburst` 支持，取值为 `auto`、`opaque`、`transparent` 之一。

不传则由模型自行决定。其它模型传入会被忽略而非报错，请求照常成功，但背景仍由模型决定。

`transparent` 必须搭配 `output_format=png`。JPEG 不支持 alpha 通道，两者同时传入会直接报错，而不是悄悄把透明背景压平。


### aspect_ratio

- **Type:** string
- **Required:** 可选
- **Default:** `1:1`

输出宽高比。不传时默认 `1:1`（仅 banana 系列；当 `size` 与 `aspect_ratio` 均未传时由 gateway 填充）。
- `banana` / `banana_pro`：`1:1`、`2:3`、`3:2`、`3:4`、`4:3`、`4:5`、`5:4`、`9:16`、`16:9`、`21:9`。
- `banana2` 额外支持 `1:8`、`1:4`、`4:1`、`8:1`。
仅 **banana** 系列支持此字段；seedream / chat_image 按 `size` 出图，请改用 `size` 参数。

### template

- **Type:** string
- **Required:** 可选

编辑模板。设置后 `prompt` 变为可选。
- `t_pose`：转换为 T-pose。
- `character_completion`：补全不完整的角色。
- `3d_enhance`：增强以用于 3D 生成。
- `variants`：生成设计变体。
- `figure`：生成全身人物。

### output_format

- **Type:** string
- **Required:** 可选
- **Default:** `png`

输出图像格式。
- `png`：无损，支持透明度。
- `jpeg`：文件体积更小，不支持透明度。


## Request Example

### 单图示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/image-to-image \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "https://example.com/reference.png",
  "prompt": "Change the silver outfit into transparent glass.",
  "model": "seedream_v5",
  "size": "2K"
}'
```

### 多图示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/image-to-image \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    "https://example.com/photo1.png",
    "https://example.com/photo2.png"
  ],
  "prompt": "Use character from image[1] and outfit from image[2].",
  "model": "seedream_v5"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "image_to_image",
    "status": "success",
    "progress": 100,
    "output": {
      "generated_image_url": "https://cdn.tripo3d.ai/output/image.png"
    },
    "credits_consumed": 20.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:00:08Z"
  }
}
```

=== FILE: generation-image-to-model_p.md ===
# 图像生成 3D 模型 — P 系列

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/image-to-model`

使用 P 系列根据图像生成 3D 模型。针对低面数输出和干净拓扑优化。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

图像来源。主体应清晰可见，遮挡最少。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- file_token：先通过文件上传 API上传图像，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的图像直链。
示例： `https://example.com/photo.png`
- task_id：此前图像生成任务（`text_to_image` 或 `image_to_image`）返回的任务 ID。系统会自动提取输出图像。
示例： `task_abc123`



- 支持格式：`PNG`、`JPEG`、`WebP`
- 最大文件大小：**20 MB**
- 推荐分辨率：至少 **256 × 256 px**。主体应清晰可见，背景干净，遮挡尽量少。

### model

- **Type:** string
- **Required:** 必选

P 系列模型版本。
- `P1-20260311`：针对低面数生成优化。
- `P2-20260801`：新一代 P 系列，支持四边面输出。 preview版

### enable_image_autofix

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否在生成前自动优化输入图像。用于AI补全和3D效果增强。启用后，系统将增强低分辨率或低质量图像以改善 3D 生成效果。默认为 false。
### texture_alignment

- **Type:** string
- **Required:** 可选
- **Default:** `original_image`

贴图对齐优先级。
- `original_image`：优先匹配输入图像的颜色。
- `geometry`：优先匹配生成的几何体。

### orientation

- **Type:** string
- **Required:** 可选
- **Default:** `default`

模型朝向。
- `default`：自动朝向。
- `align_image`：将模型对齐至输入图像的视角。
仅当 `texture` 为 `true` 时生效。未开启贴图时此参数无效。

### model_seed

- **Type:** integer
- **Required:** 可选

几何体生成的随机种子。使用相同种子和相同输入将生成相同的 3D 网格。若未设置，每次会使用随机种子。
### face_limit

- **Type:** integer
- **Required:** 可选

输出网格的最大面数。


- `P1-20260311`：**50 – 20,000**
- `P2-20260801` 三角面：**48 – 50,000**；`quad=true` 时：**48 – 25,000**
- 省略时自适应确定面数。
最佳质量建议：简单模型从 **150** 面起步，复杂模型从 **250** 面起步。面数过低可能导致生成质量下降。

### texture

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

是否为模型生成贴图。设为 false 可获取无贴图的纯几何体。默认为 true。
### pbr

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

启用 PBR 材质贴图（`base_color`、`metallic`、`roughness`、`normal`）。当 `pbr` 设为 `true` 时，`texture` 会自动强制设为 `true`。

### texture_seed

- **Type:** integer
- **Required:** 可选

贴图生成的随机种子。使用相同种子将生成相同的贴图。若未设置，每次会使用随机种子。如需获取相同几何体但不同贴图的模型，请保持 model_seed 不变并更改 texture_seed。
### texture_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

贴图质量等级。
- `fast`：生成最快，以细节换速度；输出贴图尺寸与 `standard` 相同。 需要贴图版本 `v3.5-20260815`；积分与 `standard` 相同。
- `standard`：质量与速度的平衡。
- `detailed`：更高保真度，生成速度较慢。
- `extreme`：8K 贴图，最高保真度。相比 detailed 额外消耗积分。


`fast` 仅在贴图版本 `v3.5-20260815` 下可用。生成接口需将 `texture_version` 设为该版本；`/v3/models/texture` 则是 `model`。其它贴图版本会返回 `1004`，不会静默回退到 `standard`。
### texture_version

- **Type:** string
- **Required:** 可选

独立指定贴图模型，与几何体 `model` 解耦。
- `v3.5-20260815`：最新贴图模型。使用 `texture_quality=fast` 与 `delight` 时必填。
- `v3.0-20250812`：`v3.x` 与 P 系列几何体的默认值。
- `v2.5-20250123`：`v2.5-20250123` 几何体的默认值。
省略时按上表根据几何体 `model` 自动推导。
### delight

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

贴图前去除参考图中的光照信息。设为 `false` 可保留原有明暗。仅 `v3.5-20260815` 贴图模型支持，更早的贴图版本会忽略该参数。
### auto_size

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否自动将生成的模型缩放至真实世界尺寸。启用后，模型尺寸将以米为单位，适用于 AR/VR 或游戏引擎场景。默认为 false。
### export_uv

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

控制 UV 展开。设为 `false` 可加快生成速度并减小文件体积。
### export_orientation

- **Type:** string
- **Required:** 可选
- **Default:** `+x`

导出朝向（前向轴）。
- `+x`：默认，X 轴正方向朝前。
- `-x`：X 轴负方向朝前。
- `-y`：Y 轴负方向朝前。
- `+y`：Y 轴正方向朝前。



- 仅作用于本次生成。如需用于后续的贴图、绑定、重定向、格式转换等后处理任务，不建议设置该参数。
- 设置该参数后，用于其他后处理任务时，可能因模型方向错误影响最终效果，但任务状态仍为`success`、不会报错，请谨慎使用该参数。
- 若计划对模型做后处理，建议本参数留空，改为在最后一步用`/v3/models/convert` 转换朝向。

### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

**仅 P2-20260801 支持。**是否输出四边面网格。

## Request Example

### P 系列示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/image-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "https://example.com/image.png",
  "model": "P1-20260311",
  "face_limit": 5000,
  "texture": true,
  "pbr": true
}'
```

### P2 系列示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/image-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "https://example.com/image.png",
  "model": "P2-20260801",
  "quad": true,
  "texture": true,
  "pbr": true
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: generation-image-to-model_standard.md ===
# 图像生成 3D 模型 — H 系列

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/image-to-model`

根据图像生成 3D 模型。系统从输入中推断几何体和贴图。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

图像来源。主体应清晰可见，遮挡最少。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- file_token：先通过文件上传 API上传图像，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的图像直链。
示例： `https://example.com/photo.png`
- task_id：此前图像生成任务（`text_to_image` 或 `image_to_image`）返回的任务 ID。系统会自动提取输出图像。
示例： `task_abc123`



- 支持格式：`PNG`、`JPEG`、`WebP`
- 最大文件大小：**20 MB**
- 推荐分辨率：至少 **256 × 256 px**。主体应清晰可见，背景干净，遮挡尽量少。

### model

- **Type:** string
- **Required:** 必选

AI 模型版本。
- `v3.1-20260211`：最新版，最佳质量。
- `v3.0-20250812`：稳定版，高级功能。
- `v2.5-20250123`：均衡版。

### enable_image_autofix

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否在生成前自动优化输入图像。用于AI补全和3D效果增强。启用后，系统将增强低分辨率或低质量图像以改善 3D 生成效果。默认为 false。
### texture_alignment

- **Type:** string
- **Required:** 可选
- **Default:** `original_image`

贴图对齐优先级。
- `original_image`：优先匹配输入图像的颜色。
- `geometry`：优先匹配生成的几何体。

### orientation

- **Type:** string
- **Required:** 可选
- **Default:** `default`

模型朝向。
- `default`：自动朝向。
- `align_image`：将模型对齐至输入图像的视角。
仅当 `texture` 为 `true` 时生效。未开启贴图时此参数无效。

### face_limit

- **Type:** integer
- **Required:** 可选

输出网格的最大面数。


- 省略时模型使用自适应拓扑。
各模式面数上限
| 模式 | 标准 | 超清 | 
| 纯三角面 — v3.1 | **1,500,000** | **2,000,000** | 
| 纯三角面 — v3.0 | **1,000,000** | **2,000,000** | 
| 纯三角面 — v2.5 | **500,000** | / | 
| 四边面（`quad: true`） | **150,000** | 


- 游戏资产推荐：**50,000 – 100,000**。Web/移动端：**10,000 – 50,000**。
- 开启 `smart_low_poly: true` 时，面数限制与模型版本无关，统一为： 三角面 **500 – 20,000**，四边面 **500 – 10,000**。

### texture

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

是否为模型生成贴图。设为 false 可获取无贴图的纯几何体。默认为 true。
### pbr

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

启用 PBR 材质贴图（`base_color`、`metallic`、`roughness`、`normal`）。当 `pbr` 设为 `true` 时，`texture` 会自动强制设为 `true`。

### texture_seed

- **Type:** integer
- **Required:** 可选

贴图生成的随机种子。使用相同种子将生成相同的贴图。若未设置，每次会使用随机种子。如需获取相同几何体但不同贴图的模型，请保持 model_seed 不变并更改 texture_seed。
### texture_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

贴图质量等级。
- `fast`：生成最快，以细节换速度；输出贴图尺寸与 `standard` 相同。 需要贴图版本 `v3.5-20260815`；积分与 `standard` 相同。
- `standard`：质量与速度的平衡。
- `detailed`：更高保真度，生成速度较慢。
- `extreme`：8K 贴图，最高保真度。相比 detailed 额外消耗积分。


`fast` 仅在贴图版本 `v3.5-20260815` 下可用。生成接口需将 `texture_version` 设为该版本；`/v3/models/texture` 则是 `model`。其它贴图版本会返回 `1004`，不会静默回退到 `standard`。
### texture_version

- **Type:** string
- **Required:** 可选

独立指定贴图模型，与几何体 `model` 解耦。
- `v3.5-20260815`：最新贴图模型。使用 `texture_quality=fast` 与 `delight` 时必填。
- `v3.0-20250812`：`v3.x` 与 P 系列几何体的默认值。
- `v2.5-20250123`：`v2.5-20250123` 几何体的默认值。
省略时按上表根据几何体 `model` 自动推导。
### delight

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

贴图前去除参考图中的光照信息。设为 `false` 可保留原有明暗。仅 `v3.5-20260815` 贴图模型支持，更早的贴图版本会忽略该参数。
### geometry_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

几何体质量等级。
- `standard`：质量与速度的平衡。
- `detailed`：Ultra 模式，更精细的几何细节。
该参数只对 v3.0 以上模型版本生效，v2.5 切勿使用该参数。

### auto_size

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否自动将生成的模型缩放至真实世界尺寸。启用后，模型尺寸将以米为单位，适用于 AR/VR 或游戏引擎场景。默认为 false。
### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否输出四边面网格（四边形多边形）而非三角面。若未设置 `face_limit`，默认面数为 10,000。启用 `quad` 会强制输出格式为 `FBX`。

### smart_low_poly

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否生成具有手工风格、干净拓扑的低面数模型。最适合简单、非复杂的输入。复杂模型可能偶尔失败。默认为 false。
### generate_parts

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

生成可编辑的分割部件。与 `texture`、`pbr`、`quad`、`smart_low_poly` 不兼容：
- `texture=true` 或 `pbr=true`（包括不传 `texture`，其默认值为 `true`）—— 请求被拒绝，返回错误码 `1004`。
- `quad=true` —— quad 被忽略，返回的分块为三角面网格。
- `smart_low_poly=true` —— smart_low_poly 优先，不会产出分块。
如需生成分块，请设置 `texture=false` 与 `pbr=false`，且不要传 `quad` 与 `smart_low_poly`。


### compress

- **Type:** string
- **Required:** 可选

压缩类型。
- `geometry`：meshopt 压缩，减小文件体积。



- 以下参数仅在 `model ≥ v3.0-20250812` 时有效：`texture_quality`、`geometry_quality`、`auto_size`、`quad`、`smart_low_poly`、`generate_parts`、`compress`。

### export_orientation

- **Type:** string
- **Required:** 可选
- **Default:** `+x`

导出朝向（前向轴）。
- `+x`：默认，X 轴正方向朝前。
- `-x`：X 轴负方向朝前。
- `-y`：Y 轴负方向朝前。
- `+y`：Y 轴正方向朝前。



- 仅作用于本次生成。如需用于后续的贴图、绑定、重定向、格式转换等后处理任务，不建议设置该参数。
- 设置该参数后，用于其他后处理任务时，可能因模型方向错误影响最终效果，但任务状态仍为`success`、不会报错，请谨慎使用该参数。
- 若计划对模型做后处理，建议本参数留空，改为在最后一步用`/v3/models/convert` 转换朝向。

### model_seed

- **Type:** integer
- **Required:** 可选

几何体生成的随机种子。使用相同种子和相同输入将生成相同的 3D 网格。若未设置，每次会使用随机种子。
### export_uv

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

控制生成过程中的 UV 展开。设为 `false` 可加快生成速度并减小文件体积。UV 展开将在贴图阶段处理。

## Request Example

### URL 示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/image-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "https://example.com/image.png",
  "model": "v3.1-20260211",
  "texture": true,
  "pbr": true,
  "texture_quality": "detailed"
}'
```

### Autofix 示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/image-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "file_abc123",
  "model": "v3.1-20260211",
  "enable_image_autofix": true,
  "orientation": "align_image"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: generation-image-to-multiview.md ===
# 图像生成多视图

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/image-to-multiview`

从单张图像生成多视图图像。可作为多视图转模型的预处理步骤，也可用于转台预览。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

多视图生成的源图像。接受以下输入类型：**以下方式任选其一**，不可同时传入多种类型。

- file_token：先通过文件上传 API上传图像，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的图像直链。
示例： `https://example.com/character.png`



- 支持格式：`PNG`、`JPEG`、`WebP`
- 主体应清晰可见，背景保持干净。


## Request Example

### 基础示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/image-to-multiview \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "https://example.com/character.png"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "status": "success",
    "output": {
      "front_view_url": "https://cdn.tripo3d.ai/front.png",
      "left_view_url": "https://cdn.tripo3d.ai/left.png",
      "back_view_url": "https://cdn.tripo3d.ai/back.png",
      "right_view_url": "https://cdn.tripo3d.ai/right.png"
    }
  }
}
```

=== FILE: generation-multiview-to-model_p.md ===
# 多视图生成 3D 模型 — P 系列

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/multiview-to-model`

使用 P 系列根据多视图图像生成 3D 模型。针对低面数输出和干净拓扑优化。

## Request Parameters

### inputs

- **Type:** object[] | string[]
- **Required:** 必选

**三种格式三选一，不可混用。**

- **view-key（推荐）**：对象数组，每项仅含一个键 `front`/`left`/`back`/`right`；值为 URL、`file_token` 或嵌套 `{url}` / `{file_token}` / `{object:{bucket,key}}`。顺序无关，服务端规范为 **[正面、左侧、背面、右侧]**。
- **legacy positional**：固定 4 个字符串，顺序为 **[front, left, back, right]**；无图视角传空字符串 `""`。
- **task_id**：传入此前 图像生成多视图 或编辑多视图任务的 ID，直接复用其 4 视角输出。仅接受 `[{"task_id":"<uuid>"}]`（单元素数组），不可与 view-key 或 positional 混用。原任务须为 `success`，类型为 `generate_multiview_image` 或 `edit_multiview_image`。
view-key 与 legacy positional 中，每个图像值支持：


- file_token：先通过文件上传 API上传图像，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的图像直链。
示例： `https://example.com/front.png`



- 正面视图**不可省略**。其他视图可省略，但至少需要 2 张图像。
- 所有图像应在一致光照下拍摄同一物体。
- 支持格式：`PNG`、`JPEG`、`WebP`
- 推荐分辨率：至少 **256 × 256 px**。

### model

- **Type:** string
- **Required:** 必选

P 系列模型版本。
- `P1-20260311`：针对低面数生成优化。
- `P2-20260801`：新一代 P 系列，支持四边面输出。 preview版

### texture_alignment

- **Type:** string
- **Required:** 可选
- **Default:** `original_image`

贴图对齐优先级。
- `original_image`：优先匹配输入图像的颜色。
- `geometry`：优先匹配生成的几何体。

### orientation

- **Type:** string
- **Required:** 可选
- **Default:** `default`

模型朝向。
- `default`：自动朝向。
- `align_image`：将模型对齐至输入图像的视角。
仅当 `texture` 为 `true` 时生效。未开启贴图时此参数无效。

### model_seed

- **Type:** integer
- **Required:** 可选

几何体生成的随机种子。使用相同种子和相同输入将生成相同的 3D 网格。若未设置，每次会使用随机种子。
### face_limit

- **Type:** integer
- **Required:** 可选

输出网格的最大面数。


- `P1-20260311`：**50 – 20,000**
- `P2-20260801` 三角面：**48 – 50,000**；`quad=true` 时：**48 – 25,000**
- 省略时自适应确定面数。
最佳质量建议：简单模型从 **150** 面起步，复杂模型从 **250** 面起步。面数过低可能导致生成质量下降。

### texture

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

是否为模型生成贴图。设为 false 可获取无贴图的纯几何体。默认为 true。
### pbr

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

启用 PBR 材质贴图（`base_color`、`metallic`、`roughness`、`normal`）。当 `pbr` 设为 `true` 时，`texture` 会自动强制设为 `true`。

### texture_seed

- **Type:** integer
- **Required:** 可选

贴图生成的随机种子。使用相同种子将生成相同的贴图。若未设置，每次会使用随机种子。如需获取相同几何体但不同贴图的模型，请保持 model_seed 不变并更改 texture_seed。
### texture_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

贴图质量等级。
- `fast`：生成最快，以细节换速度；输出贴图尺寸与 `standard` 相同。 需要贴图版本 `v3.5-20260815`；积分与 `standard` 相同。
- `standard`：质量与速度的平衡。
- `detailed`：更高保真度，生成速度较慢。
- `extreme`：8K 贴图，最高保真度。相比 detailed 额外消耗积分。


`fast` 仅在贴图版本 `v3.5-20260815` 下可用。生成接口需将 `texture_version` 设为该版本；`/v3/models/texture` 则是 `model`。其它贴图版本会返回 `1004`，不会静默回退到 `standard`。
### texture_version

- **Type:** string
- **Required:** 可选

独立指定贴图模型，与几何体 `model` 解耦。
- `v3.5-20260815`：最新贴图模型。使用 `texture_quality=fast` 与 `delight` 时必填。
- `v3.0-20250812`：`v3.x` 与 P 系列几何体的默认值。
- `v2.5-20250123`：`v2.5-20250123` 几何体的默认值。
省略时按上表根据几何体 `model` 自动推导。
### delight

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

贴图前去除参考图中的光照信息。设为 `false` 可保留原有明暗。仅 `v3.5-20260815` 贴图模型支持，更早的贴图版本会忽略该参数。
### auto_size

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否自动将生成的模型缩放至真实世界尺寸。启用后，模型尺寸将以米为单位，适用于 AR/VR 或游戏引擎场景。默认为 false。
### export_uv

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

控制 UV 展开。设为 `false` 可加快生成速度并减小文件体积。
### export_orientation

- **Type:** string
- **Required:** 可选
- **Default:** `+x`

导出朝向（前向轴）。
- `+x`：默认，X 轴正方向朝前。
- `-x`：X 轴负方向朝前。
- `-y`：Y 轴负方向朝前。
- `+y`：Y 轴正方向朝前。



- 仅作用于本次生成。如需用于后续的贴图、绑定、重定向、格式转换等后处理任务，不建议设置该参数。
- 设置该参数后，用于其他后处理任务时，可能因模型方向错误影响最终效果，但任务状态仍为`success`、不会报错，请谨慎使用该参数。
- 若计划对模型做后处理，建议本参数留空，改为在最后一步用`/v3/models/convert` 转换朝向。

### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

**仅 P2-20260801 支持。**是否输出四边面网格。

## Request Example

### view-key + URL

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/multiview-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    {
      "front": "https://example.com/front.png"
    },
    {
      "back": "https://example.com/back.png"
    },
    {
      "right": "https://example.com/right.png"
    }
  ],
  "model": "P1-20260311",
  "texture": true,
  "pbr": true
}'
```

### P2 系列示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/multiview-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    {
      "front": "https://example.com/front.png"
    },
    {
      "back": "https://example.com/back.png"
    }
  ],
  "model": "P2-20260801",
  "quad": true,
  "texture": true,
  "pbr": true
}'
```

### view-key + file_token

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/multiview-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    {
      "front": "3154b4b0-4647-4032-aa82-827441ae92ef"
    },
    {
      "back": "58ea3eab-6a08-4deb-98f9-e60f1802954d"
    },
    {
      "right": "584b0e07-8576-4eb4-bf49-2e149e0252f6"
    }
  ],
  "model": "P1-20260311",
  "texture": true,
  "pbr": true
}'
```

### legacy positional

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/multiview-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    "https://example.com/front.png",
    "",
    "https://example.com/back.png",
    "https://example.com/right.png"
  ],
  "model": "P1-20260311",
  "texture": true,
  "pbr": true
}'
```

### 复用多视图任务

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/multiview-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    {
      "task_id": "550e8400-e29b-41d4-a716-446655440000"
    }
  ],
  "model": "P1-20260311",
  "texture": true,
  "pbr": true
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: generation-multiview-to-model_standard.md ===
# 多视图生成 3D 模型 — H 系列

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/multiview-to-model`

根据多视图图像生成 3D 模型。多角度输入可提高几何体精度和贴图覆盖度。

## Request Parameters

### inputs

- **Type:** object[] | string[]
- **Required:** 必选

**三种格式三选一，不可混用。**

- **view-key（推荐）**：对象数组，每项仅含一个键 `front`/`left`/`back`/`right`；值为 URL、`file_token` 或嵌套 `{url}` / `{file_token}` / `{object:{bucket,key}}`。顺序无关，服务端规范为 **[正面、左侧、背面、右侧]**。
- **legacy positional**：固定 4 个字符串，顺序为 **[front, left, back, right]**；无图视角传空字符串 `""`。
- **task_id**：传入此前 图像生成多视图 或编辑多视图任务的 ID，直接复用其 4 视角输出。仅接受 `[{"task_id":"<uuid>"}]`（单元素数组），不可与 view-key 或 positional 混用。原任务须为 `success`，类型为 `generate_multiview_image` 或 `edit_multiview_image`。
view-key 与 legacy positional 中，每个图像值支持：


- file_token：先通过文件上传 API上传图像，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的图像直链。
示例： `https://example.com/front.png`



- 正面视图**不可省略**。其他视图可省略，但至少需要 2 张图像。
- 所有图像应在一致光照下拍摄同一物体。
- 支持格式：`PNG`、`JPEG`、`WebP`
- 推荐分辨率：至少 **256 × 256 px**。

### model

- **Type:** string
- **Required:** 必选

AI 模型版本。
- `v3.1-20260211`：最新版，最佳质量。
- `v3.0-20250812`：稳定版，高级功能。
- `v2.5-20250123`：均衡版。

### texture_alignment

- **Type:** string
- **Required:** 可选
- **Default:** `original_image`

贴图对齐优先级。
- `original_image`：优先匹配输入图像的颜色。
- `geometry`：优先匹配生成的几何体。

### orientation

- **Type:** string
- **Required:** 可选
- **Default:** `default`

模型朝向。
- `default`：自动朝向。
- `align_image`：将模型对齐至输入图像的视角。
仅当 `texture` 为 `true` 时生效。未开启贴图时此参数无效。

### face_limit

- **Type:** integer
- **Required:** 可选

输出网格的最大面数。


- 省略时模型使用自适应拓扑。
各模式面数上限
| 模式 | 标准 | 超清 | 
| 纯三角面 — v3.1 | **1,500,000** | **2,000,000** | 
| 纯三角面 — v3.0 | **1,000,000** | **2,000,000** | 
| 纯三角面 — v2.5 | **500,000** | / | 
| 四边面（`quad: true`） | **150,000** | 


- 游戏资产推荐：**50,000 – 100,000**。Web/移动端：**10,000 – 50,000**。
- 开启 `smart_low_poly: true` 时，面数限制与模型版本无关，统一为： 三角面 **500 – 20,000**，四边面 **500 – 10,000**。

### texture

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

是否为模型生成贴图。设为 false 可获取无贴图的纯几何体。默认为 true。
### pbr

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

启用 PBR 材质贴图（`base_color`、`metallic`、`roughness`、`normal`）。当 `pbr` 设为 `true` 时，`texture` 会自动强制设为 `true`。

### texture_seed

- **Type:** integer
- **Required:** 可选

贴图生成的随机种子。使用相同种子将生成相同的贴图。若未设置，每次会使用随机种子。如需获取相同几何体但不同贴图的模型，请保持 model_seed 不变并更改 texture_seed。
### texture_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

贴图质量等级。
- `fast`：生成最快，以细节换速度；输出贴图尺寸与 `standard` 相同。 需要贴图版本 `v3.5-20260815`；积分与 `standard` 相同。
- `standard`：质量与速度的平衡。
- `detailed`：更高保真度，生成速度较慢。
- `extreme`：8K 贴图，最高保真度。相比 detailed 额外消耗积分。


`fast` 仅在贴图版本 `v3.5-20260815` 下可用。生成接口需将 `texture_version` 设为该版本；`/v3/models/texture` 则是 `model`。其它贴图版本会返回 `1004`，不会静默回退到 `standard`。
### texture_version

- **Type:** string
- **Required:** 可选

独立指定贴图模型，与几何体 `model` 解耦。
- `v3.5-20260815`：最新贴图模型。使用 `texture_quality=fast` 与 `delight` 时必填。
- `v3.0-20250812`：`v3.x` 与 P 系列几何体的默认值。
- `v2.5-20250123`：`v2.5-20250123` 几何体的默认值。
省略时按上表根据几何体 `model` 自动推导。
### delight

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

贴图前去除参考图中的光照信息。设为 `false` 可保留原有明暗。仅 `v3.5-20260815` 贴图模型支持，更早的贴图版本会忽略该参数。
### geometry_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

几何体质量等级。
- `standard`：质量与速度的平衡。
- `detailed`：Ultra 模式，更精细的几何细节。
该参数只对 v3.0 以上模型版本生效，v2.5 切勿使用该参数。

### auto_size

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否自动将生成的模型缩放至真实世界尺寸。启用后，模型尺寸将以米为单位，适用于 AR/VR 或游戏引擎场景。默认为 false。
### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否输出四边面网格（四边形多边形）而非三角面。若未设置 `face_limit`，默认面数为 10,000。启用 `quad` 会强制输出格式为 `FBX`。

### smart_low_poly

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否生成具有手工风格、干净拓扑的低面数模型。最适合简单、非复杂的输入。复杂模型可能偶尔失败。默认为 false。
### generate_parts

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

生成可编辑的分割部件。与 `texture`、`pbr`、`quad`、`smart_low_poly` 不兼容：
- `texture=true` 或 `pbr=true`（包括不传 `texture`，其默认值为 `true`）—— 请求被拒绝，返回错误码 `1004`。
- `quad=true` —— quad 被忽略，返回的分块为三角面网格。
- `smart_low_poly=true` —— smart_low_poly 优先，不会产出分块。
如需生成分块，请设置 `texture=false` 与 `pbr=false`，且不要传 `quad` 与 `smart_low_poly`。


### compress

- **Type:** string
- **Required:** 可选

压缩类型。
- `geometry`：meshopt 压缩，减小文件体积。



- 以下参数仅在 `model ≥ v3.0-20250812` 时有效：`texture_quality`、`geometry_quality`、`auto_size`、`quad`、`smart_low_poly`、`generate_parts`、`compress`。

### export_orientation

- **Type:** string
- **Required:** 可选
- **Default:** `+x`

导出朝向（前向轴）。
- `+x`：默认，X 轴正方向朝前。
- `-x`：X 轴负方向朝前。
- `-y`：Y 轴负方向朝前。
- `+y`：Y 轴正方向朝前。



- 仅作用于本次生成。如需用于后续的贴图、绑定、重定向、格式转换等后处理任务，不建议设置该参数。
- 设置该参数后，用于其他后处理任务时，可能因模型方向错误影响最终效果，但任务状态仍为`success`、不会报错，请谨慎使用该参数。
- 若计划对模型做后处理，建议本参数留空，改为在最后一步用`/v3/models/convert` 转换朝向。

### model_seed

- **Type:** integer
- **Required:** 可选

几何体生成的随机种子。使用相同种子和相同输入将生成相同的 3D 网格。若未设置，每次会使用随机种子。
### export_uv

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

控制生成过程中的 UV 展开。设为 `false` 可加快生成速度并减小文件体积。UV 展开将在贴图阶段处理。

## Request Example

### view-key + URL

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/multiview-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    {
      "front": "https://example.com/front.png"
    },
    {
      "back": "https://example.com/back.png"
    },
    {
      "right": "https://example.com/right.png"
    }
  ],
  "model": "v3.1-20260211",
  "texture": false,
  "geometry_quality": "detailed"
}'
```

### view-key + file_token

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/multiview-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    {
      "front": "3154b4b0-4647-4032-aa82-827441ae92ef"
    },
    {
      "back": "58ea3eab-6a08-4deb-98f9-e60f1802954d"
    },
    {
      "right": "584b0e07-8576-4eb4-bf49-2e149e0252f6"
    }
  ],
  "model": "v3.1-20260211",
  "texture": false,
  "geometry_quality": "detailed"
}'
```

### legacy positional

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/multiview-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    "https://example.com/front.png",
    "",
    "https://example.com/back.png",
    "https://example.com/right.png"
  ],
  "model": "v3.1-20260211",
  "texture": true,
  "pbr": true,
  "texture_quality": "detailed"
}'
```

### 复用多视图任务

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/multiview-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    {
      "task_id": "550e8400-e29b-41d4-a716-446655440000"
    }
  ],
  "model": "v3.1-20260211",
  "texture": true,
  "pbr": true
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: generation-text-to-image.md ===
# 文本生成图像

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/text-to-image`

根据文本提示词生成图像。不接受参考图像 — 如需使用参考图请使用图像生图。

## Request Parameters

### model

- **Type:** string
- **Required:** 可选
- **Default:** `seedream_v4`

图像生成模型。可选模型：
- `seedream_v5` — 最新质量，提示词遵循更强。
- `seedream_v4` — 默认均衡模型。
- `banana` — 快速生成。
- `banana_pro` — 更高质量。
- `banana2` — 最新快速选项。
- `chat_image_1` — 基础图像模型。**2026-10-23 下线。**
- `chat_image_1.5` — 更高质量。**2026-12-01 下线。**
- `chat_image_2` — 最新，质量最佳。
- `chat_image_2.5_flare` — 2.5 系列速度档，质量对标 `chat_image_2`，明显更快。
- `chat_image_2.5_sunburst` — 2.5 系列精修档，编辑时对画面其余部分的保真度最好。

### prompt

- **Type:** string
- **Required:** 必选

图像生成的文本提示词。支持中文和英文。


- 推荐：不超过 300 个中文字符或 600 个英文单词。
- 将最重要的元素放在前面。
- 反向提示词：在 `--no` 后追加。

### size

- **Type:** string
- **Required:** 可选
- **Default:** `2048x2048`

输出图像尺寸。可传语义关键字（如 2K / 4K）或精确像素（如 2048x2048）；不同模型支持的取值不同，见下方分模型。
### quality

- **Type:** string
- **Required:** 可选
- **Default:** `low`

渲染质量档位。仅 `chat_image_2`、`chat_image_2.5_flare`、`chat_image_2.5_sunburst` 支持该参数，其它模型传入会直接报错。


- `chat_image_2` — `low`、`medium`、`high`。
- `chat_image_2.5_flare` / `chat_image_2.5_sunburst` — `low`、`medium`、`high`、`xhigh`、`max`。
不传等同于 `low`。请注意这与 OpenAI 官方默认的 `auto` 不同，且本接口**不支持** `auto` —— 计价需要在请求前就确定档位。

`high`、`xhigh`、`max` 会消耗更多积分且耗时明显增加；`low` 与 `medium` 按基础价计费。详见定价页。



### background

- **Type:** string
- **Required:** 可选

背景处理方式。仅 `chat_image_2.5_flare` 与 `chat_image_2.5_sunburst` 支持，取值为 `auto`、`opaque`、`transparent` 之一。

不传则由模型自行决定。其它模型传入会被忽略而非报错，请求照常成功，但背景仍由模型决定。

`transparent` 必须搭配 `output_format=png`。JPEG 不支持 alpha 通道，两者同时传入会直接报错，而不是悄悄把透明背景压平。


### aspect_ratio

- **Type:** string
- **Required:** 可选
- **Default:** `1:1`

输出宽高比。不传时默认 `1:1`（仅 banana 系列；当 `size` 与 `aspect_ratio` 均未传时由 gateway 填充）。
- `banana` / `banana_pro`：`1:1`、`2:3`、`3:2`、`3:4`、`4:3`、`4:5`、`5:4`、`9:16`、`16:9`、`21:9`。
- `banana2` 额外支持 `1:8`、`1:4`、`4:1`、`8:1`。
仅 **banana** 系列支持此字段；seedream / chat_image 按 `size` 出图，请改用 `size` 参数。

### output_format

- **Type:** string
- **Required:** 可选
- **Default:** `png`

输出图像格式。
- `png`：无损，支持透明度。
- `jpeg`：文件体积更小，不支持透明度。

### watermark

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

添加 AI 生成内容水印。仅对 seedream 系列生效；banana 系列会强制嵌入不可关闭的隐形水印，chat_image 系列不支持水印控制。
### template

- **Type:** string
- **Required:** 可选

生成模板。
- `asset_extraction`：从场景中提取主体。
- `character_completion`：补全不完整的角色。
- `t_pose`：生成 T-pose 姿态的角色。
- `variants`：生成设计变体。
- `figure`：生成全身人物。


## Request Example

### seedream_v5

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-image \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A high-fashion editorial portrait, dramatic studio lighting.",
  "model": "seedream_v5",
  "size": "2K",
  "output_format": "png",
  "watermark": false
}'
```

### banana

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-image \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A cinematic product render of a glass sneaker on a dark stage.",
  "model": "banana",
  "size": "1248x832",
  "output_format": "png"
}'
```

### banana_pro

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-image \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A cinematic product render of a glass sneaker on a dark stage.",
  "model": "banana_pro",
  "size": "2K",
  "aspect_ratio": "3:2",
  "output_format": "png"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_image",
    "status": "success",
    "progress": 100,
    "output": {
      "generated_image_url": "https://cdn.tripo3d.ai/output/image.png"
    },
    "credits_consumed": 20.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:00:08Z"
  }
}
```

=== FILE: generation-text-to-model_p.md ===
# 文本生成 3D 模型 — P 系列

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/text-to-model`

使用 P 系列根据文本提示词生成 3D 模型。针对低面数输出和干净拓扑优化。

## Request Parameters

### prompt

- **Type:** string
- **Required:** 必选

文本提示词，最多 1024 个字符。描述形状、材质、风格和尺寸。


- 好的示例："一个低面数中世纪木质宝箱，带有铁铰链和生锈的锁。"
- 差的示例："一个箱子。"
- 加入材质和风格描述可提升 PBR 贴图效果。

### negative_prompt

- **Type:** string
- **Required:** 可选

反向提示词，最多 255 个字符。描述不希望在生成模型中出现的内容。例如："blurry, low quality, broken mesh"。
### image_seed

- **Type:** integer
- **Required:** 可选

内部文本转图像阶段的随机种子。控制从文本提示词生成的参考图像，然后再进行 3D 转换。若未设置，每次会使用随机种子。
### model

- **Type:** string
- **Required:** 必选

P 系列模型版本。
- `P1-20260311`：针对低面数生成优化。
- `P2-20260801`：新一代 P 系列，支持四边面输出。 preview版

### model_seed

- **Type:** integer
- **Required:** 可选

几何体生成的随机种子。使用相同种子和相同输入将生成相同的 3D 网格。若未设置，每次会使用随机种子。
### face_limit

- **Type:** integer
- **Required:** 可选

输出网格的最大面数。


- `P1-20260311`：**50 – 20,000**
- `P2-20260801` 三角面：**48 – 50,000**；`quad=true` 时：**48 – 25,000**
- 省略时自适应确定面数。
最佳质量建议：简单模型从 **150** 面起步，复杂模型从 **250** 面起步。面数过低可能导致生成质量下降。

### texture

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

是否为模型生成贴图。设为 false 可获取无贴图的纯几何体。默认为 true。
### pbr

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

启用 PBR 材质贴图（`base_color`、`metallic`、`roughness`、`normal`）。当 `pbr` 设为 `true` 时，`texture` 会自动强制设为 `true`。

### texture_seed

- **Type:** integer
- **Required:** 可选

贴图生成的随机种子。使用相同种子将生成相同的贴图。若未设置，每次会使用随机种子。如需获取相同几何体但不同贴图的模型，请保持 model_seed 不变并更改 texture_seed。
### texture_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

贴图质量等级。
- `fast`：生成最快，以细节换速度；输出贴图尺寸与 `standard` 相同。 需要贴图版本 `v3.5-20260815`；积分与 `standard` 相同。
- `standard`：质量与速度的平衡。
- `detailed`：更高保真度，生成速度较慢。
- `extreme`：8K 贴图，最高保真度。相比 detailed 额外消耗积分。


`fast` 仅在贴图版本 `v3.5-20260815` 下可用。生成接口需将 `texture_version` 设为该版本；`/v3/models/texture` 则是 `model`。其它贴图版本会返回 `1004`，不会静默回退到 `standard`。
### texture_version

- **Type:** string
- **Required:** 可选

独立指定贴图模型，与几何体 `model` 解耦。
- `v3.5-20260815`：最新贴图模型。使用 `texture_quality=fast` 与 `delight` 时必填。
- `v3.0-20250812`：`v3.x` 与 P 系列几何体的默认值。
- `v2.5-20250123`：`v2.5-20250123` 几何体的默认值。
省略时按上表根据几何体 `model` 自动推导。
### delight

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

贴图前去除参考图中的光照信息。设为 `false` 可保留原有明暗。仅 `v3.5-20260815` 贴图模型支持，更早的贴图版本会忽略该参数。
### auto_size

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否自动将生成的模型缩放至真实世界尺寸。启用后，模型尺寸将以米为单位，适用于 AR/VR 或游戏引擎场景。默认为 false。
### export_uv

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

控制 UV 展开。设为 `false` 可加快生成速度并减小文件体积。
### export_orientation

- **Type:** string
- **Required:** 可选
- **Default:** `+x`

导出朝向（前向轴）。
- `+x`：默认，X 轴正方向朝前。
- `-x`：X 轴负方向朝前。
- `-y`：Y 轴负方向朝前。
- `+y`：Y 轴正方向朝前。



- 仅作用于本次生成。如需用于后续的贴图、绑定、重定向、格式转换等后处理任务，不建议设置该参数。
- 设置该参数后，用于其他后处理任务时，可能因模型方向错误影响最终效果，但任务状态仍为`success`、不会报错，请谨慎使用该参数。
- 若计划对模型做后处理，建议本参数留空，改为在最后一步用`/v3/models/convert` 转换朝向。

### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

**仅 P2-20260801 支持。**是否输出四边面网格。

## Request Example

### P 系列示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A cat wearing a spacesuit",
  "model": "P1-20260311",
  "face_limit": 3000,
  "texture": true,
  "pbr": true
}'
```

### P2 系列示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A low-poly wooden chair",
  "model": "P2-20260801",
  "quad": true,
  "face_limit": 5000,
  "texture": true,
  "pbr": true
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: generation-text-to-model_standard.md ===
# 文本生成 3D 模型 — H 系列

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/text-to-model`

根据文本提示词生成 3D 模型。生成几何体、可选贴图和可选 PBR 材质贴图。

## Request Parameters

### prompt

- **Type:** string
- **Required:** 必选

文本提示词，最多 1024 个字符。描述形状、材质、风格和尺寸。


- 好的示例："一个低面数中世纪木质宝箱，带有铁铰链和生锈的锁。"
- 差的示例："一个箱子。"
- 加入材质和风格描述可提升 PBR 贴图效果。

### model

- **Type:** string
- **Required:** 必选

AI 模型版本。
- `v3.1-20260211`：最新版，最佳质量。
- `v3.0-20250812`：稳定版，高级功能。
- `v2.5-20250123`：均衡版。

### negative_prompt

- **Type:** string
- **Required:** 可选

反向提示词，最多 255 个字符。描述不希望在生成模型中出现的内容。例如："blurry, low quality, broken mesh"。
### model_seed

- **Type:** integer
- **Required:** 可选

几何体生成的随机种子。使用相同种子和相同输入将生成相同的 3D 网格。若未设置，每次会使用随机种子。
### image_seed

- **Type:** integer
- **Required:** 可选

内部文本转图像阶段的随机种子。控制从文本提示词生成的参考图像，然后再进行 3D 转换。若未设置，每次会使用随机种子。
### face_limit

- **Type:** integer
- **Required:** 可选

输出网格的最大面数。


- 省略时模型使用自适应拓扑。
各模式面数上限
| 模式 | 标准 | 超清 | 
| 纯三角面 — v3.1 | **1,500,000** | **2,000,000** | 
| 纯三角面 — v3.0 | **1,000,000** | **2,000,000** | 
| 纯三角面 — v2.5 | **500,000** | / | 
| 四边面（`quad: true`） | **150,000** | 


- 游戏资产推荐：**50,000 – 100,000**。Web/移动端：**10,000 – 50,000**。
- 开启 `smart_low_poly: true` 时，面数限制与模型版本无关，统一为： 三角面 **500 – 20,000**，四边面 **500 – 10,000**。

### texture

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

是否为模型生成贴图。设为 false 可获取无贴图的纯几何体。默认为 true。
### pbr

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

启用 PBR 材质贴图（`base_color`、`metallic`、`roughness`、`normal`）。当 `pbr` 设为 `true` 时，`texture` 会自动强制设为 `true`。

### texture_seed

- **Type:** integer
- **Required:** 可选

贴图生成的随机种子。使用相同种子将生成相同的贴图。若未设置，每次会使用随机种子。如需获取相同几何体但不同贴图的模型，请保持 model_seed 不变并更改 texture_seed。
### texture_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

贴图质量等级。
- `fast`：生成最快，以细节换速度；输出贴图尺寸与 `standard` 相同。 需要贴图版本 `v3.5-20260815`；积分与 `standard` 相同。
- `standard`：质量与速度的平衡。
- `detailed`：更高保真度，生成速度较慢。
- `extreme`：8K 贴图，最高保真度。相比 detailed 额外消耗积分。


`fast` 仅在贴图版本 `v3.5-20260815` 下可用。生成接口需将 `texture_version` 设为该版本；`/v3/models/texture` 则是 `model`。其它贴图版本会返回 `1004`，不会静默回退到 `standard`。
### texture_version

- **Type:** string
- **Required:** 可选

独立指定贴图模型，与几何体 `model` 解耦。
- `v3.5-20260815`：最新贴图模型。使用 `texture_quality=fast` 与 `delight` 时必填。
- `v3.0-20250812`：`v3.x` 与 P 系列几何体的默认值。
- `v2.5-20250123`：`v2.5-20250123` 几何体的默认值。
省略时按上表根据几何体 `model` 自动推导。
### delight

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

贴图前去除参考图中的光照信息。设为 `false` 可保留原有明暗。仅 `v3.5-20260815` 贴图模型支持，更早的贴图版本会忽略该参数。
### geometry_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

几何体质量等级。
- `standard`：质量与速度的平衡。
- `detailed`：Ultra 模式，更精细的几何细节。
该参数只对 v3.0 以上模型版本生效，v2.5 切勿使用该参数。

### auto_size

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否自动将生成的模型缩放至真实世界尺寸。启用后，模型尺寸将以米为单位，适用于 AR/VR 或游戏引擎场景。默认为 false。
### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否输出四边面网格（四边形多边形）而非三角面。若未设置 `face_limit`，默认面数为 10,000。启用 `quad` 会强制输出格式为 `FBX`。

### smart_low_poly

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否生成具有手工风格、干净拓扑的低面数模型。最适合简单、非复杂的输入。复杂模型可能偶尔失败。默认为 false。
### generate_parts

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

生成可编辑的分割部件。与 `texture`、`pbr`、`quad`、`smart_low_poly` 不兼容：
- `texture=true` 或 `pbr=true`（包括不传 `texture`，其默认值为 `true`）—— 请求被拒绝，返回错误码 `1004`。
- `quad=true` —— quad 被忽略，返回的分块为三角面网格。
- `smart_low_poly=true` —— smart_low_poly 优先，不会产出分块。
如需生成分块，请设置 `texture=false` 与 `pbr=false`，且不要传 `quad` 与 `smart_low_poly`。


### compress

- **Type:** string
- **Required:** 可选

压缩类型。
- `geometry`：meshopt 压缩，减小文件体积。



- 以下参数仅在 `model ≥ v3.0-20250812` 时有效：`texture_quality`、`geometry_quality`、`auto_size`、`quad`、`smart_low_poly`、`generate_parts`、`compress`。

### export_orientation

- **Type:** string
- **Required:** 可选
- **Default:** `+x`

导出朝向（前向轴）。
- `+x`：默认，X 轴正方向朝前。
- `-x`：X 轴负方向朝前。
- `-y`：Y 轴负方向朝前。
- `+y`：Y 轴正方向朝前。



- 仅作用于本次生成。如需用于后续的贴图、绑定、重定向、格式转换等后处理任务，不建议设置该参数。
- 设置该参数后，用于其他后处理任务时，可能因模型方向错误影响最终效果，但任务状态仍为`success`、不会报错，请谨慎使用该参数。
- 若计划对模型做后处理，建议本参数留空，改为在最后一步用`/v3/models/convert` 转换朝向。

### export_uv

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

控制生成过程中的 UV 展开。设为 `false` 可加快生成速度并减小文件体积。UV 展开将在贴图阶段处理。

## Request Example

### 基础示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A cat wearing a spacesuit",
  "model": "v3.1-20260211",
  "texture": true,
  "pbr": true,
  "texture_quality": "detailed"
}'
```

### 进阶示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/text-to-model \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "prompt": "A futuristic sci-fi helmet with glowing blue visor.",
  "model": "v3.1-20260211",
  "face_limit": 80000,
  "geometry_quality": "detailed",
  "auto_size": true
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: introduction.md ===
# Tripo API 介绍

Tripo3D 是一个 AI 3D 生成平台，提供文生 3D、图生 3D、动画绑骨、网格编辑等能力。通过 Tripo API，开发者可以将高质量 3D 内容生成集成到自有产品中。

> 如果您在海外访问，请前往国际站：[developers.tripo3d.ai](https://developers.tripo3d.ai)

## Base URL

```baseurl
https://openapi.tripo3d.com/v3
```

## 认证方式

所有 API 请求需要在请求头中携带 API Key：

```apikey
Authorization: Bearer {api_key}
```

API Key 可在 [Tripo 控制台](/zh/keys) 创建和管理。

## 统一响应格式

### 成功响应

```json
{
  "code": 0,
  "data": {
    ...
  }
}
```

### 错误响应

```json
{
  "code": 2010,
  "message": "Insufficient credits",
  "suggestion": "Please top up your account"
}
```

### 公共字段

| 参数 | 类型 | 说明 |
| :-: | :-: | :-: |
| code | integer | 状态码，`0` 表示成功，非 `0` 表示错误 |
| data | object | 业务数据（仅成功时返回） |
| message | string | 错误描述（仅失败时返回） |
| suggestion | string | 修复建议（仅失败时返回） |

## 异步任务模式

大部分生成类接口采用异步任务模式：

1. **创建任务**：POST 请求创建任务，返回 `task_id`
2. **轮询结果**：使用 `GET /v3/tasks/{task_id}` 查询任务状态和结果

```
POST /v3/generation/text-to-model  →  {"code": 0, "data": {"task_id": "task_abc123"}}
                                              ↓
GET  /v3/tasks/task_abc123          →  {"code": 0, "data": {"status": "running", "progress": 50}}
                                              ↓
GET  /v3/tasks/task_abc123          →  {"code": 0, "data": {"status": "success", "output": {...}}}
```

### 任务状态

| 状态 | 说明 |
| :-: | :-: |
| `queued` | 排队中 |
| `running` | 运行中 |
| `success` | 成功 |
| `failed` | 失败 |
| `cancelled` | 已取消 |

## API 版本

当前版本：**v3**

## 端点总览

### 3D 模型生成

| 端点 | 说明 |
| :-: | :-: |
| [`POST /v3/generation/text-to-model`](/zh/docs/generation-text-to-model) | 文本生成 3D 模型 |
| [`POST /v3/generation/image-to-model`](/zh/docs/generation-image-to-model) | 图片生成 3D 模型 |
| [`POST /v3/generation/multiview-to-model`](/zh/docs/generation-multiview-to-model) | 多视角生成 3D 模型 |

### 图像生成

| 端点 | 说明 |
| :-: | :-: |
| [`POST /v3/generation/text-to-image`](/zh/docs/generation-text-to-image) | 文本生成图片 |
| [`POST /v3/generation/image-to-image`](/zh/docs/generation-image-to-image) | 图片风格转换 |
| [`POST /v3/generation/image-to-multiview`](/zh/docs/generation-image-to-multiview) | 图片生成多视角 |
| [`POST /v3/generation/edit-multiview`](/zh/docs/generation-edit-multiview) | 多视角编辑 |

### 模型后处理

| 端点 | 说明 |
| :-: | :-: |
| [`POST /v3/models/texture`](/zh/docs/models-texture) | 贴图 |
| [`POST /v3/models/convert`](/zh/docs/models-convert) | 格式转换 |
| [`POST /v3/mesh/segment`](/zh/docs/mesh-segment) | 语义分割 |
| [`POST /v3/mesh/complete`](/zh/docs/mesh-complete) | 网格补全 |
| [`POST /v3/mesh/decimate`](/zh/docs/mesh-decimate) | 重拓扑 |

### 动画

| 端点 | 说明 |
| :-: | :-: |
| [`POST /v3/animations/rig-check`](/zh/docs/animations-rig-check) | 骨骼绑定检查 |
| [`POST /v3/animations/rig`](/zh/docs/animations-rig) | 骨骼绑定 |
| [`POST /v3/animations/retarget`](/zh/docs/animations-retarget) | 动画重定向 |

### 任务管理

| 端点 | 说明 |
| :-: | :-: |
| [`GET /v3/tasks/{task_id}`](/zh/docs/task-query) | 查询任务 |
| [`POST /v3/tasks/list`](/zh/docs/task-batch-query) | 批量查询任务 |

### 文件管理

| 端点 | 说明 |
| :-: | :-: |
| [`POST /v3/files`](/zh/docs/files) | 上传文件 |

### 账户

| 端点 | 说明 |
| :-: | :-: |
| [`GET /v3/account/balance`](/zh/docs/account) | 查询余额 |

=== FILE: invoice-guide.md ===
# 开票引导

通过支付宝完成的积分充值订单，可在支付宝账单中自助申请电子发票，无需人工对接。以下 4 个步骤覆盖从查找账单到收取发票的完整流程。

![开票流程总览：查找支付账单、点击开发票、填写开票信息、邮箱收取发票](/assets/images/docs/invoice-guide/overview-steps.webp)

## 01｜找到支付账单

打开支付宝 App，在账单中搜索「tripo」，找到本次充值对应的账单记录（商品说明形如「Tripo 积分充值 600 Credits」），点击进入账单详情。

<img src="/assets/images/docs/invoice-guide/step-01-find-alipay-bill.webp" alt="步骤 1：支付宝账单搜索 tripo 后列出的充值记录" width="340" />

## 02｜点击开发票

在账单详情页核对支付时间、商品说明与收款方全称，下拉至底部的账单管理区域，点击「开发票」。

<img src="/assets/images/docs/invoice-guide/step-02-bill-detail-invoice.webp" alt="步骤 2：账单详情页底部账单管理区域中的开发票入口" width="340" />

## 03｜填写开票信息

进入票通发票服务平台后，确认开票金额与开票项目（技术服务费）无误，选择发票种类（普通发票 / 增值税专用发票）与抬头类型（企业 / 个人及非企业性单位），填写企业名称、企业税号与接收邮箱，点击「去开票」提交申请。

<img src="/assets/images/docs/invoice-guide/step-03-fill-invoice-info.webp" alt="步骤 3：票通发票服务平台的申请开票表单，含发票种类、抬头类型、企业名称、税号与接收邮箱" width="340" />

## 04｜邮箱收取发票

提交后稍等片刻，电子发票将发送至所填邮箱，邮件中附带 PDF 与 OFD 格式的发票文件，可直接下载用于报销与入账。

<img src="/assets/images/docs/invoice-guide/step-04-receive-invoice-email.webp" alt="步骤 4：邮箱收到的电子发票邮件，含 PDF 与 OFD 附件" width="340" />

## 注意事项

<div class="doc-callout doc-callout--warn rounded-lg p-4 text-sm text-[var(--text-block)]">
发票由票通电子发票服务平台开具，开票金额以该笔订单的实付金额为准，开票项目为技术服务费。提交后请注意查收邮箱（含垃圾邮件目录）。若在账单中未找到「开发票」入口，或需要换开、补开发票与对账单，请联系 business@tripo3d.com。
</div>

=== FILE: mesh-complete.md ===
# 网格部件补全

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /mesh/complete`

补全分割的网格部件并修复缺失区域。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

`mesh/segment` 任务的 task_id，以 `task_` 开头。
### model

- **Type:** string
- **Required:** 可选
- **Default:** `v1.0-20250506`

补全模型版本。
- `v1.0-20250506`：默认（当前唯一版本）。

### part_names

- **Type:** string[]
- **Required:** 可选

要补全的部件名称列表。若省略，将补全所有部件。
### completion_mode

- **Type:** string
- **Required:** 可选
- **Default:** `ai_completion`

补全模式。
- `ai_completion`：AI 扩散补全（默认）。生成真实几何以填充缺失区域。
- `quick_cap`：快速封口。快速封闭开放边界，不使用 AI 生成。


## Request Example

### AI 补全

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/complete \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "part_names": [
    "head",
    "body"
  ]
}'
```

### 快速封口

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/complete \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "completion_mode": "quick_cap"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: mesh-decimate.md ===
# 重拓扑

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /mesh/decimate`

通过两种算法减少模型面数。使用 model=v2.0（默认）进行智能低模重拓扑，保留干净拓扑结构；使用 model=v1.0 进行基础减面。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型来源。接受 task_id 或 file_token。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前 3D 生成任务（`text_to_model`、`image_to_model` 或 `multiview_to_model`）返回的任务 ID。系统会自动使用该任务的 3D 模型输出。
示例： `task_abc123`
- file_token：先通过文件上传 API上传 3D 模型文件，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的 3D 模型文件直链。
示例： `https://example.com/model.glb`



- 支持格式：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`
- 最大文件大小：**150 MB**

### model

- **Type:** string
- **Required:** 可选
- **Default:** `v2.0`

重拓扑算法版本。
### face_limit

- **Type:** integer
- **Required:** 条件必填

目标面数。
### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

输出四边面网格。v1.0 和 v2.0 均支持。
### bake

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`
- **Note:** v1.0 不支持该参数。

将贴图烘焙到低面数模型上。
### part_names

- **Type:** string[]
- **Required:** 可选
- **Note:** v1.0 不支持该参数。

要减面的部件名称（来自语义分割）。

## Request Example

### v2.0 智能重拓扑

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/decimate \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "model": "v2.0",
  "face_limit": 5000,
  "quad": false,
  "bake": true
}'
```

### v1.0 基础减面

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/decimate \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "model": "v1.0",
  "face_limit": 3000
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: mesh-segment.md ===
# 网格分割

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /mesh/segment`

对 3D 模型进行语义分割，自动拆分为各个部件。支持 v1（几何拓扑，默认）和 v2（语义标注 + 几何，Beta）。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型来源。接受 task_id、file_token 或 URL。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前 3D 生成任务（`text_to_model`、`image_to_model` 或 `multiview_to_model`）返回的任务 ID。系统会自动使用该任务的 3D 模型输出。
示例： `task_abc123`
- file_token：先通过文件上传 API上传 3D 模型文件，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的 3D 模型文件直链。
示例： `https://example.com/model.glb`



- 支持格式：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`
- 最大文件大小：**150 MB**

### model

- **Type:** string
- **Required:** 可选
- **Default:** `v1.0-20250506`

分割模型版本。
- `v1.0-20250506`：默认，基于几何拓扑的分割。
- `v2.0-20260430` Beta：语义标注 + 几何分割。

### segmentation_granularity

- **Type:** string
- **Required:** 可选
- **Default:** `balanced`

**仅 v2。**分割粒度。
- `simple`
- `balanced`：默认
- `detailed`

### split_by_connectivity

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

**仅 v2。**是否按连通域拆分。
### ref_image

- **Type:** string
- **Required:** 可选

**仅 v2。**辅助语义分析的参考图，接受 `file_token`（文件上传返回）或外部 URL。当传入 `ref_image` 时，`segmentation_granularity` 与 `split_by_connectivity` **无效**。
左：3D 模型 (.glb)  |  右：作为 `ref_image` 传入的分割 mask




## Request Example

### 分割示例 (v1)

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/segment \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123"
}'
```

### 分割示例 (v2 + 粒度)

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/segment \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "model": "v2.0-20260430",
  "input": "task_abc123",
  "segmentation_granularity": "balanced",
  "split_by_connectivity": true
}'
```

### 分割示例 (v2 + 参考图)

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/mesh/segment \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "model": "v2.0-20260430",
  "input": "task_abc123",
  "ref_image": "file_a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_def456",
    "type": "mesh_segmentation",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/mesh_seg.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/mesh_seg.webp"
    },
    "credits_consumed": 40.00,
    "created_at": "2026-05-27T02:22:56Z",
    "completed_at": "2026-05-27T02:25:33Z"
  }
}
```

=== FILE: migration-v2-to-v3.md ===
# v2 → v3 迁移指南

本文档帮助你将现有代码从 Tripo API v2 迁移到 v3。

## 用 Skill 快速从 V2 升级到 V3

不用先看懂所有 API 差异。下载这份 Skill，把它放到需要迁移的项目目录中，再让 AI 编程工具使用它。它会帮你找到项目里的 V2 调用，并一步步迁移到 V3。

### 第 1 步：下载 Skill

<a class="plugin-download-button" href="/assets/developer/tripo-v2-to-v3-migration/SKILL.md" download="SKILL.md">下载</a>

下载后会得到一个名为 `SKILL.md` 的文件，请不要修改文件名。

### 第 2 步：放入项目并使用 Skill

将下载的 `SKILL.md` 放到需要迁移的项目目录中。然后打开该项目，直接告诉 AI 使用这个 Skill。

### 第 3 步：复制这句话开始迁移

打开需要迁移的项目，把下面这句话完整发送给你的 AI 编程工具：

```text
请使用项目目录中的 `SKILL.md`，帮我把当前项目中的 Tripo API 从 V2 迁移到 V3。先告诉我需要改哪些地方，等我确认后再修改。最后按照文件里的清单检查，确保没有漏改。
```

工具会先找到 V2 调用并给出迁移计划，不需要你手动逐个文件查找。

## 主要变化

### 1. Base URL 变更

```
# v2
https://api.tripo3d.com/v2/openapi/

# v3
https://openapi.tripo3d.com/v3/
```

### 2. 万能端点拆分为独立端点

v2 使用单一 `POST /v2/openapi/task` 端点加 `type` 字段区分任务类型。v3 为每种能力提供独立端点，无需 `type` 字段。

```json
// v2
POST /v2/openapi/task
{ "type": "text_to_model", "prompt": "a cat" }

// v3
POST /v3/generation/text-to-model
{ "prompt": "a cat" }
```

### 3. 文件输入统一为 `input` 字段

v2 中根据输入来源使用不同字段名（`file`、`file_token`、`url`、`object`）。v3 统一为 `input` 字段，系统自动推断输入类型。

```json
// v2 — 需要指定不同字段名
{ "type": "refine_model", "draft_model_task_id": "task_abc123" }
{ "type": "convert_model", "original_model_task_id": "task_abc123" }

// v3 — 统一使用 input
{ "input": "task_abc123" }
{ "input": "https://example.com/model.glb" }
{ "input": "file_token_abc123" }
```

### 4. 字段名规范化

| v2 字段 | v3 字段 |
| :-: | :-: |
| `create_time` | `created_at` |
| `consumed_credit` | `credits_consumed` |

### 5. 文生图与图生图分离

v2 中文生图和图生图共用接口，v3 拆分为独立端点：

- `POST /v3/generation/text-to-image`：纯文本输入生成图片
- `POST /v3/generation/image-to-image`：基于参考图片生成/编辑图片

## 端点映射表

### 生成

| v2 type 值 | v3 端点 |
| :-: | :-: |
| `text_to_model` | `POST /v3/generation/text-to-model` |
| `image_to_model` | `POST /v3/generation/image-to-model` |
| `multiview_to_model` | `POST /v3/generation/multiview-to-model` |
| `text_to_image` | `POST /v3/generation/text-to-image` |
| `generate_image` | `POST /v3/generation/image-to-image` |
| `generate_multiview_image` | `POST /v3/generation/image-to-multiview` |
| `edit_multiview_image` | `POST /v3/generation/edit-multiview` |

### 模型处理

| v2 type 值 | v3 端点 |
| :-: | :-: |
| `refine_model` | `POST /v3/models/refine` |
| `convert_model` | `POST /v3/models/convert` |
| `import_model` | `POST /v3/models/import` |
| `stylize_model` | `POST /v3/models/stylize` |
| `texture_model` | `POST /v3/models/texture` |

### 动画

| v2 type 值 | v3 端点 |
| :-: | :-: |
| `animate_prerigcheck` | `POST /v3/animations/rig-check` |
| `animate_rig` | `POST /v3/animations/rig` |
| `animate_retarget` | `POST /v3/animations/retarget` |

### 网格编辑

| v2 type 值 | v3 端点 |
| :-: | :-: |
| `mesh_segmentation` | `POST /v3/mesh/segment` |
| `mesh_completion` | `POST /v3/mesh/complete` |
| `highpoly_to_lowpoly` | `POST /v3/mesh/decimate` |

### 任务与文件

| v2 端点 | v3 端点 |
| :-: | :-: |
| `GET /v2/openapi/task/{task_id}` | `GET /v3/tasks/{task_id}` |
| `POST /v2/openapi/upload` | `POST /v3/files` |

## 迁移步骤

### 第 1 步：更新 Base URL

```python
# v2
BASE_URL = "https://api.tripo3d.com/v2/openapi"

# v3
BASE_URL = "https://openapi.tripo3d.com/v3"
```

### 第 2 步：按映射表替换端点

```python
# v2
response = requests.post(f"{BASE_URL}/task", json={
    "type": "text_to_model",
    "prompt": "a cat"
})

# v3
response = requests.post(f"{BASE_URL}/generation/text-to-model", json={
    "prompt": "a cat"
})
```

### 第 3 步：移除 `type` 字段

v3 端点路径已隐含任务类型，请求体中不再需要 `type` 字段。

### 第 4 步：替换输入字段为 `input`

```python
# v2 — 不同任务类型使用不同字段名
payload = {"type": "refine_model", "draft_model_task_id": "task_abc123"}
payload = {"type": "convert_model", "original_model_task_id": "task_abc123"}

# v3 — 统一使用 input
payload = {"input": "task_abc123"}
```

### 第 5 步：更新响应字段名

```python
# v2
created = task["create_time"]
cost = task["consumed_credit"]

# v3
created = task["created_at"]
cost = task["credits_consumed"]
```

### 第 6 步：测试验证

1. 逐个端点替换并测试
2. 验证任务创建和轮询流程正常
3. 确认下载链接可用
4. 检查积分扣除和余额查询正常

## 注意事项

- v2 和 v3 可以并行运行，建议逐步迁移而非一次性切换
- API Key 在 v2 和 v3 之间通用，无需重新创建
- 任务 ID 格式不变，v2 创建的任务可在 v3 中查询

=== FILE: models-and-versions.md ===
# 模型与版本

## 3D 生成模型

用于 `POST /v3/generation/text-to-model` 和 `POST /v3/generation/image-to-model` 等 3D 生成端点的 `model` 参数。

| 模型标识 | 说明 | 推荐场景 |
| :-: | :-: | :-: |
| `tripo-p1` | 低面数表现更好 | 游戏管线制作 / UGC 生成式玩法 / 移动端设备 3D 资产生成 |
| `tripo-v3.1` | 最新高精度模型版本（默认） | 3A 作品制作管线 / 3D 打印柔性制造 |
| `tripo-v3.0` | 上一代稳定版 | 兼容性需求 |
| `tripo-v2.5` | 旧版 | 历史项目兼容 |

## 图像生成模型

用于 `POST /v3/generation/text-to-image` 和 `POST /v3/generation/image-to-image` 端点的 `model` 参数。

| 模型标识 | 提供商 | 特点 |
| :-: | :-: | :-: |
| `seedream_v4` | ByteDance | 默认模型，效果均衡 |
| `seedream_v5` | ByteDance | 最新版，质量提升 |
| `banana` | ByteDance | 快速生成 |
| `banana_pro` | ByteDance | 高质量生成 |
| `banana2` | ByteDance | 最新快速版本 |
| `chat_image_1` | OpenAI | GPT 图像生成（2026-10-23 下线） |
| `chat_image_1.5` | OpenAI | GPT 更高质量（2026-12-01 下线） |
| `chat_image_2` | OpenAI | GPT 最新 |

| `chat_image_2.5_flare` | OpenAI | GPT 2.5 速度档 |
| `chat_image_2.5_sunburst` | OpenAI | GPT 2.5 精修档 |
## 版本选择建议

- **新项目**：使用默认版本（3D 用 `tripo-v3.1`，图像用 `seedream_v4`），享受最佳的质量与稳定性平衡
- **生产环境**：锁定具体版本号，避免模型更新导致输出不一致
- **追求最高质量**：3D 使用 `tripo-p1`，图像根据场景选择 `banana_pro` 或 `seedream_v5`
- **低面数 / 游戏资产**：3D 使用 `tripo-p1`，拓扑更干净，面数控制更精确

## 请求示例

```bash
# 使用默认模型
curl -X POST https://openapi.tripo3d.com/v3/generation/text-to-model \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {api_key}" \
  -d '{"prompt": "a robot"}'

# 指定旗舰模型
curl -X POST https://openapi.tripo3d.com/v3/generation/text-to-model \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {api_key}" \
  -d '{"prompt": "a robot", "model": "tripo-p1"}'

# 使用图像生成模型
curl -X POST https://openapi.tripo3d.com/v3/generation/text-to-image \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {api_key}" \
  -d '{"prompt": "a futuristic city", "model": "seedream-v5"}'
```

=== FILE: models-convert.md ===
# 模型格式转换

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /models/convert`

将 3D 模型转换为其他格式，支持可选的网格处理、贴图烘焙和导出设置。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型来源。接受 task_id 或 file_token。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前 3D 生成任务（`text_to_model`、`image_to_model` 或 `multiview_to_model`）返回的任务 ID。系统会自动使用该任务的 3D 模型输出。
示例： `task_abc123`
- file_token：先通过文件上传 API上传 3D 模型文件，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的 3D 模型文件直链。
示例： `https://example.com/model.glb`



- 支持格式：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`
- 最大文件大小：**150 MB**

### format

- **Type:** string
- **Required:** 必选

目标导出格式。
- `GLTF`：Web 查看器、WebGL 引擎。
- `FBX`：Unreal、Unity、DCC 工具。
- `USDZ`：Apple AR Quick Look。
- `OBJ`：传统交换格式，无动画。
- `STL`：3D 打印，仅几何体。
- `3MF`：3D 打印，支持颜色。



- `GLTF`：Web 查看器、WebGL 引擎（Three.js、Babylon.js）。
- `FBX`：Unreal、Unity、DCC 工具（Maya、Blender）。
- `USDZ`：Apple AR Quick Look、RealityKit。
- `OBJ`：传统交换格式，不支持动画。
- `STL` / `3MF`：3D 打印，仅几何体。

### quad

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

是否输出四边面网格（四边形多边形）而非三角面。若未设置 `face_limit`，默认面数为 10,000。启用 `quad` 会强制输出格式为 `FBX`。

### force_symmetry

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

强制对称。仅 quad 为 true 时有效。
### face_limit

- **Type:** integer
- **Required:** 可选

转换时的输出网格最大面数。不传时保持原模型面数。
### flatten_bottom

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

展平模型底部。
### flatten_bottom_threshold

- **Type:** float
- **Required:** 可选
- **Default:** `0.01`

展平深度阈值。
### texture_size

- **Type:** integer
- **Required:** 可选
- **Default:** `4096`

漫反射贴图尺寸（像素）。
### texture_format

- **Type:** string
- **Required:** 可选
- **Default:** `JPEG`

贴图图像格式。
- `JPEG`：默认，文件体积最小。
- `PNG`：无损，支持透明度。
- `WEBP`：现代 Web 格式。
- `BMP` / `DPX` / `HDR` / `OPEN_EXR` / `TARGA` / `TIFF`：专业用途。

### bake

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

将高级材质烘焙为基础贴图。
### pack_uv

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

将所有 UV 打包为统一布局。
### export_vertex_colors

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

包含顶点颜色。**仅对 `OBJ` 和 `GLTF` 有效。**
### pivot_to_center_bottom

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

将轴心点移至底部中心。
### scale_factor

- **Type:** float
- **Required:** 可选
- **Default:** `1`

导出模型的缩放系数。
### with_animation

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

包含骨骼和动画数据。
### animate_in_place

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

原地动画（无根骨位移）。
### part_names

- **Type:** string[]
- **Required:** 可选

要导出的部件名称，来自网格/分割数据。
### export_orientation

- **Type:** string
- **Required:** 可选
- **Default:** `+x`

导出朝向（前向轴）。
- `+x`：默认，X 轴正方向朝前。
- `-x`：X 轴负方向朝前。
- `-y`：Y 轴负方向朝前。
- `+y`：Y 轴正方向朝前。

### fbx_preset

- **Type:** string
- **Required:** 可选
- **Default:** `blender`

FBX 兼容性预设。
- `blender`：针对 Blender 导入优化。
- `3dsmax`：针对 3ds Max 导入优化。
- `mixamo`：兼容 Mixamo 绑骨。
- `bake_scale`：导出 FBX 时将缩放变换烘焙进几何体，而不保留在节点 transform 上。


## Request Example

### 导出 FBX

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/models/convert \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "format": "FBX",
  "texture_size": 2048,
  "texture_format": "PNG",
  "pivot_to_center_bottom": true,
  "fbx_preset": "blender"
}'
```

### 导出 GLTF

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/models/convert \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "format": "GLTF",
  "texture_size": 4096,
  "bake": true
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: models-import.md ===
# 导入模型

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /models/import`

将外部 3D 模型文件导入 Tripo 平台以进行后续处理。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型文件来源。接受 `file_token`（前缀 `file_`）或 URL。


- 支持格式：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`
- 最大文件大小：**150 MB**


## Request Example

### 文件示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/models/import \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "file_abc123"
}'
```

### URL 示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/models/import \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "https://example.com/my-model.glb"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: models-texture.md ===
# 贴图

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /models/texture`

为现有模型重新生成贴图。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型来源。接受 task_id、file_token 或 URL。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前 3D 生成任务（`text_to_model`、`image_to_model` 或 `multiview_to_model`）返回的任务 ID。系统会自动使用该任务的 3D 模型输出。
示例： `task_abc123`
- file_token：先通过文件上传 API上传 3D 模型文件，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的 3D 模型文件直链。
示例： `https://example.com/model.glb`



- 支持格式：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`
- 最大文件大小：**150 MB**

### model

- **Type:** string
- **Required:** 可选
- **Default:** `v3.0-20250812`

贴图模型版本。请根据源 3D 模型的生成版本选择：
- `v3.5-20260815`：最新贴图模型。使用 `texture_quality=fast` 与 `delight` 时必填。
- `v3.0-20250812`：默认。推荐用于 `v3.0-20250812` 或 `v3.1-20260211` 生成的模型。
- `v2.5-20250123`：推荐用于 `v2.5-20250123` 生成的模型。

### texture_prompt

- **Type:** object
- **Required:** 可选

贴图引导输入。如果模型是通过 Tripo 生成的则可选。**`text` / `image` / `images` 三者互斥，只能选其一（`style_image` 可与 `text` 搭配）。**

- text：描述期望贴图风格的文本提示词。
示例： `{"text": "磨损的皮革带划痕"}`
- style_image：风格参考图片，仅可与 `text` 模式搭配使用。 接受 `file_token` 或 `url`。建议分辨率：至少 256×256 px。
示例： `{"text": "赛博朋克风格", "style_image": {"url": "https://..."}}`
- image：单张参考图片用于贴图生成。接受 file_token 或 URL。
- images：恰好 4 张参考图片，顺序为 [正面, 左侧, 背面, 右侧]，用于多角度贴图引导。



- 若基于已有 TaskID 发起贴图任务，**强烈建议**在本次请求中重新传入参考图。
- `text`、`image` 和 `images` 三者互斥，只能选其一。
- 可选的 `style_image` 可与 `text` 搭配使用，用于影响艺术风格。

### pbr

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

启用 PBR 材质生成。
### texture_seed

- **Type:** integer
- **Required:** 可选

贴图生成的随机种子。使用相同种子将生成相同的贴图。若未设置，每次会使用随机种子。如需获取相同几何体但不同贴图的模型，请保持 model_seed 不变并更改 texture_seed。
### texture_alignment

- **Type:** string
- **Required:** 可选
- **Default:** `original_image`

贴图对齐优先级。
- `original_image`：优先匹配输入图像的颜色。
- `geometry`：优先匹配生成的几何体。

### texture_quality

- **Type:** string
- **Required:** 可选
- **Default:** `standard`

贴图质量等级。
- `fast`：生成最快，以细节换速度；输出贴图尺寸与 `standard` 相同。 需要贴图版本 `v3.5-20260815`；积分与 `standard` 相同。
- `standard`：质量与速度的平衡。
- `detailed`：更高保真度，生成速度较慢。
- `extreme`：8K 贴图，最高保真度。相比 detailed 额外消耗积分。


`fast` 仅在贴图版本 `v3.5-20260815` 下可用。生成接口需将 `texture_version` 设为该版本；`/v3/models/texture` 则是 `model`。其它贴图版本会返回 `1004`，不会静默回退到 `standard`。
### part_names

- **Type:** string[]
- **Required:** 可选

来自之前网格分割任务的部件名称列表。如不填写，则对所有部件进行贴图。
### compress

- **Type:** string
- **Required:** 可选

压缩类型。
- `geometry`：meshopt 压缩，减小文件体积。



- 以下参数仅在 `model ≥ v3.0-20250812` 时有效：`texture_quality`、`geometry_quality`、`auto_size`、`quad`、`smart_low_poly`、`generate_parts`、`compress`。

### bake

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

将高级材质效果烘焙到基础贴图中，以提高兼容性。
### delight

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

贴图前去除参考图中的光照信息。设为 `false` 可保留原有明暗。仅 `v3.5-20260815` 贴图模型支持，更早的贴图版本会忽略该参数。

## Request Example

### 基础示例（v2.5 模型）

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/models/texture \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "model": "v2.5-20250123",
  "texture_quality": "detailed",
  "pbr": true
}'
```

### 快速模式（v3.5 模型）

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/models/texture \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "model": "v3.5-20260815",
  "texture_quality": "fast",
  "delight": true,
  "pbr": true
}'
```

### v3.x 模型贴图

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/models/texture \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "model": "v3.0-20250812",
  "texture_quality": "detailed",
  "pbr": true
}'
```

### 带提示词示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/models/texture \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "model": "v3.0-20250812",
  "texture_prompt": {
    "text": "worn leather with scratches"
  },
  "texture_quality": "detailed"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: openai-compat-images.md ===
# OpenAI 协议兼容 · 图像接口

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /openai/images/generations`

**全面兼容 OpenAI Images API 协议。**把客户端的 base URL 指到 `https://openapi.tripo3d.com/v3/openai`、换一下模型名即可接入， 其余调用代码无需改动。端点
- `POST /v3/openai/images/generations` — 文生图
- `POST /v3/openai/images/edits` — 图生图（multipart 或 JSON）

与 OpenAI 的两处有意差异
- **图片一律以加签 URL 返回**，位于 `data[0].url`，不返回 `b64_json`。显式传 `response_format="b64_json"` 会返回 400，而不是被静默忽略。
- **不返回 `usage` 字段。** 我们按积分计费而非 token。消费明细请查 账户或任务查询。

模型名模型名沿用 OpenAI 的官方写法，你代码里现有的模型字符串可以直接继续用。当前**只有**下面这三个版本，传其它任何值都会返回 404 `model_not_found`（带日期的快照名如 `gpt-image-2-2026-04-21` 同样不接受），错误信息里会列出这三个可用 ID。


- `gpt-image-2`
- `gpt-image-2.5-flare`
- `gpt-image-2.5-sunburst`

计费与耗时与文生图、图生图完全一致——同样的积分、同样的内容审核、 同样的并发限制。请求会一直阻塞到出图为止（通常 20–80 秒）。若 240 秒后仍在生成，会返回 400 且 code 为 `generation_in_progress`：**任务并未失败、积分已扣一次**，请改用 `GET /v3/tasks/{task_id}` 轮询 （task_id 在响应头 `X-Tripo-Task-Id` 与 `tripo.task_id` 中），**不要重新提交**。





## Request Parameters

### model

- **Type:** string
- **Required:** 必选

模型 ID，沿用 OpenAI 官方写法。不在下列三个版本内的取值一律返回 404 model_not_found。

取值：gpt-image-2、gpt-image-2.5-flare、gpt-image-2.5-sunburst，仅此三个。带日期的快照名不被接受；Tripo 的 chat_image_* ID 同样不接受，且 404 里会直接给出应改用的 ID。
### prompt

- **Type:** string
- **Required:** 必选

期望图像的文字描述。
### image

- **Type:** file | file[]
- **Required:** 条件必填

仅 edits，multipart 表单。'image' 与 'image[]' 两种 part 名都支持；每张输入图一个 part。
### images

- **Type:** object[]
- **Required:** 条件必填

仅 edits，JSON 请求体。每个元素只能二选一：image_url（公网 https URL，或 base64 data: URL，最大 10 MiB）或 file_id（POST /v3/files 返回的 Tripo file_token）。
### size

- **Type:** string
- **Required:** 可选
- **Default:** `1024x1024`

输出分辨率。传 'auto' 或不传都会解析为 1024x1024，以保证下单前积分可预知。

与原生端点规则一致：每条边必须是 16 像素的整数倍。
### quality

- **Type:** string
- **Required:** 可选
- **Default:** `low`

渲染档位。传 'auto' 或不传都表示基础档。

gpt-image-2 支持 low / medium / high；gpt-image-2.5-* 另外支持 xhigh 与 max。
### background

- **Type:** string
- **Required:** 可选

auto / opaque / transparent。仅对 gpt-image-2.5-* 生效；transparent 要求 output_format=png。
### output_format

- **Type:** string
- **Required:** 可选
- **Default:** `png`

png 或 jpeg；webp 会被拒绝。
### n

- **Type:** integer
- **Required:** 可选
- **Default:** `1`

必须为 1，每次请求出一张图；其它值返回 400。
### response_format

- **Type:** string
- **Required:** 可选
- **Default:** `url`

只支持 'url'。传 'b64_json' 会返回 400，而不是被静默降级。
### stream

- **Type:** boolean
- **Required:** 可选

不支持，必须为 false 或不传；不提供流式中间图。
### mask

- **Type:** file
- **Required:** 可选

可选的局部重绘遮罩，作用于第一张输入图。必须是带 alpha 通道的 PNG，且以文件 part 发送；完全透明的像素即为要重绘的区域。其他形式一律返回 400。

需与输入图同尺寸，且不超过 20 MiB。遮罩对模型是语义引导而非像素级裁剪，因此 prompt 应描述该区域，不要点名位于遮罩之外的对象。输入图本身上限为 10 MiB，上传与 data: URL 两种形式同此限制。

## Response Fields

### created

- **Type:** integer
- **Required:** 必选

Unix 时间戳（秒）。
### data[].url

- **Type:** string
- **Required:** 必选

生成图像的加签 CDN URL；本接口以此替代 b64_json。
### size / quality / output_format / background

- **Type:** string
- **Required:** 可选

回显实际生效的取值，可用于确认 'auto' 被解析成了什么。
### tripo.task_id

- **Type:** string
- **Required:** 必选

Tripo 扩展字段。同一 id 也会放在 X-Tripo-Task-Id 响应头中（出错时同样返回），便于用 GET /v3/tasks/{task_id} 对账。

## Request Example

### 文生图（官方 SDK）

```
from openai import OpenAI

client = OpenAI(
    api_key="<YOUR_API_KEY>",
    base_url="https://openapi.tripo3d.com/v3/openai",
)

result = client.images.generate(
    model="gpt-image-2.5-flare",
    prompt="a cute baby sea otter on a rock",
    n=1,
    size="auto",
    quality="auto",
)

print(result.data[0].url)
```

### 图生图（官方 SDK）

```
result = client.images.edit(
    model="gpt-image-2.5-flare",
    prompt="replace the background with pure white",
    image=open("input.png", "rb"),
    size="1024x1024",
)

print(result.data[0].url)
```

### 图生图（JSON 请求体）

```
curl -X POST 'https://openapi.tripo3d.com/v3/openai/images/edits' \
  -H 'Authorization: Bearer <YOUR_API_KEY>' \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "gpt-image-2.5-flare",
    "prompt": "replace the background with pure white",
    "images": [{ "image_url": "https://example.com/input.png" }],
    "size": "1024x1024"
  }'
```

### 图生图（multipart，多张图）

```
curl -X POST 'https://openapi.tripo3d.com/v3/openai/images/edits' \
  -H 'Authorization: Bearer <YOUR_API_KEY>' \
  -F 'model=gpt-image-2.5-flare' \
  -F 'prompt=combine both objects into one product photo' \
  -F 'image[]=@a.png;type=image/png' \
  -F 'image[]=@b.png;type=image/png' \
  -F 'size=1024x1024'
```


## Response Example

### 成功

```json
{
  "created": 1789598400,
  "data": [
    {
      "url": "https://cdn.tripo3d.com/.../generated_image.png?..."
    }
  ],
  "size": "1024x1024",
  "quality": "low",
  "output_format": "png",
  "tripo": {
    "task_id": "2f67cafc-c1aa-492f-85e8-93ec95fc6fd8"
  }
}
```

### 错误信封

```json
{
  "error": {
    "message": "model 'chat_image_2' is not supported here; use 'gpt-image-2' instead",
    "type": "invalid_request_error",
    "param": "model",
    "code": "model_not_found"
  }
}
```

### 超过等待上限仍在生成

```json
{
  "error": {
    "message": "the image is still being generated after 240s; it has not failed and you have been charged once — poll GET /v3/tasks/2f67cafc-... for the result instead of resubmitting",
    "type": "invalid_request_error",
    "code": "generation_in_progress"
  }
}
```

=== FILE: plugins.md ===
# Tripo 插件

在你熟悉的创作工具中直接使用 Tripo。选择适合当前工作流的插件，下载安装并连接 Tripo API Key，无需离开编辑器即可生成 3D 模型。

## 支持的插件

| 插件          | Tripo 版本 | 适配版本 | 适用场景                  | 下载                                                                                                                        |
| ------------- | ---------- | -------- | ------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| Unity         | `1.0.1`    | `Unity 2022+` | 生成并导入游戏资产        | <a class="plugin-download-button" href="https://assets-pub.tripo3d.com/archive/760058ab-1128-45b7-9b11-3a0aff142fec/Tripo_API_Unity-latest.zip" download>下载</a>     |
| Unreal Engine | `1.0`      | `5.6.0`  | 编辑器与 Blueprint 工作流 | <a class="plugin-download-button" href="https://assets-pub.tripo3d.com/archive/74c76766-33aa-4bb6-89cb-688f00b3c350/Tripo_API_Unreal-latest.zip" download>下载</a>   |
| Blender       | `0.7.3`    | `3.0+`   | 生成基础模型后继续编辑    | <a class="plugin-download-button" href="https://static.tripolabs.com/file/a7291e22-0922-46c9-b930-d3385d9af364.zip" download>下载</a> |
| Godot         | `0.02`     | `4.4+`    | 编辑器与 `Node3D` 工作流  | <a class="plugin-download-button" href="https://static.tripolabs.com/file/b30c5802-aad9-4e56-9015-27c10255c68f.zip" download>下载</a>     |
| Cocos Creator | `1.0.0`    | `3.8.6+` | 在 Cocos 项目中创建资产   | <a class="plugin-download-button" href="https://static.tripolabs.com/file/c234ca49-c791-40e9-b0ae-88161b78715d.zip" download>下载</a>     |
| ComfyUI       | `1.1.21`   | `0.3.14` | 节点式 3D 生成工作流      | <a class="plugin-download-button" href="https://static.tripolabs.com/file/b41d0b35-340e-4423-ab32-ad7930058d4a.zip" download>下载</a> |

不同插件开放的 Tripo 能力有所区别。以下案例只描述对应安装包中真实存在的功能。

## 插件使用案例

### Unity：生成游戏道具

**使用场景。** 在场景原型阶段快速创建占位道具或后续制作的起始资产。

**操作步骤。**

1. 打开 `Tools > Tripo API Unity` 并配置 API Key。
2. 选择 **Image to Model**，上传图片并开始生成。
3. 等待任务完成，由插件下载模型并导入项目。

如需使用可选的本地运行时 **Text to Model** 流程，也可以调用安装包提供的 `TripoRuntimeCore`：

```csharp
GetComponent<TripoRuntimeCore>()
  .SetAPIKey("<TRIPO_API_KEY>")
  .SetTextPrompt("a stylized wooden treasure chest")
  .TextToModel();
```

**生成结果。** 模型作为 Unity 项目资产导入，可继续配置材质、放入场景或编辑。

<a class="plugin-download-button" href="https://assets-pub.tripo3d.com/archive/760058ab-1128-45b7-9b11-3a0aff142fec/Tripo_API_Unity-latest.zip" download>下载</a>

### Unreal Engine：通过 Blueprint 生成模型

**使用场景。** 在 Unreal 编辑器工具或 Blueprint 原型中接入模型生成。

**操作步骤。**

1. 使用插件的 Blueprint 节点创建文本、图片或多视图生成任务。
2. 通过回调和任务状态节点等待生成完成。
3. 将返回的模型地址传给下载节点。运行时展示还需要安装包文档指定的 glTFRuntime 插件。

![用于创建、查询和下载 Tripo 模型的 Unreal Engine Blueprint 节点](/assets/images/docs/plugins/unreal-blueprint.jpg)

**生成结果。** 模型可以下载后导入编辑器，也可以交给运行时展示流程。

<a class="plugin-download-button" href="https://assets-pub.tripo3d.com/archive/74c76766-33aa-4bb6-89cb-688f00b3c350/Tripo_API_Unreal-latest.zip" download>下载</a>

### Blender：由参考图生成基础模型

**使用场景。** 先根据参考图创建基础网格，再进入 Blender 完成建模和材质工作。

**操作步骤。**

1. 打开 `View3D > Sidebar > Tripo 3D` 并连接 API Key。
2. 选择图片生成模型，上传参考图，并设置面数、纹理、PBR 或四边面等参数。
3. 开始生成，等待插件下载并导入结果。

**生成结果。** GLB 或 FBX 会导入 Blender，可继续使用标准建模工具编辑。

<a class="plugin-download-button" href="https://static.tripolabs.com/file/a7291e22-0922-46c9-b930-d3385d9af364.zip" download>下载</a>

### Godot：将生成模型添加为 Node3D

**使用场景。** 在 Godot 编辑器或本地运行时流程中生成对象，并加入场景树。

**操作步骤。** 在插件中配置 API Key，创建输入与任务节点，然后等待任务完成：

下面示例使用文本任务。图片任务可先用 `TripoUploadImage` 上传源图，再用 `TripoImageToModel` 生成模型。

```gdscript
var input = TripoTextToModelInput.new()
input.prompt = "a stylized wooden treasure chest"

var task = TripoTextToModel.new()
task.input = input
add_child(task)

if await task.launch() == TripoTask.TaskError.eSuccess:
    add_child(task.save_to_node())
```

**生成结果。** 模型可以预览、保存，或作为 `Node3D` 添加到当前场景。

<a class="plugin-download-button" href="https://static.tripolabs.com/file/b30c5802-aad9-4e56-9015-27c10255c68f.zip" download>下载</a>

### Cocos Creator：保存生成的项目资产

**使用场景。** 不离开 Cocos Creator，直接通过文字或图片创建 3D 资产。

**操作步骤。**

1. 打开 **Tripo Model Generator** 面板并连接 API Key。
2. 选择文字或图片输入，配置生成参数并启动任务。
3. 等待扩展下载生成完成的模型到项目中。

**生成结果。** GLB 或 FBX 写入 `assets/resources`，可供当前项目继续使用。

<a class="plugin-download-button" href="https://static.tripolabs.com/file/c234ca49-c791-40e9-b0ae-88161b78715d.zip" download>下载</a>

### ComfyUI：搭建文本生成 3D 工作流

**使用场景。** 把 Tripo 生成能力接入现有的节点式图片或资产处理流程。

**操作步骤。**

1. 将文本输入连接到 Tripo 模型生成节点。
2. 设置 API Key、生成模式、模型版本和输出参数。
3. 把结果连接到 3D 预览节点并执行队列。

![包含生成模型预览的 ComfyUI 文本生成 3D 工作流](/assets/images/docs/plugins/comfyui-text-to-model.jpg)

**生成结果。** 模型在工作流中预览，并自动保存到 `ComfyUI/output`。

<a class="plugin-download-button" href="https://static.tripolabs.com/file/b41d0b35-340e-4423-ab32-ad7930058d4a.zip" download>下载</a>

## 安装与首次使用

### Unity

1. 下载并解压 ZIP。
2. 将解压后包含 `package.json` 的插件目录放入项目的 `Packages` 目录。
3. 重新打开项目并选择 `Tools > Tripo API Unity`。

### Unreal Engine

1. 将 ZIP 下载并解压到 Unreal 项目的 `Plugins/Tripo3D`。
2. 在项目设置中启用插件。
3. 重启 Unreal Editor。

### Blender

1. 打开 `Edit > Preferences > Add-ons`。
2. 选择 **Install from Disk**，选中下载的 ZIP，并启用 **Tripo 3D**。
3. 从 `View3D > Sidebar > Tripo 3D` 打开插件。

### Godot

1. 解压 ZIP，将 `addons/tripo-godot` 复制到项目的 `addons` 目录。
2. 打开 `Project Settings > Plugins` 并启用 Tripo 插件。
3. 打开 Tripo 编辑器面板，或在场景中使用插件提供的节点。

### Cocos Creator

1. 打开“扩展 → 扩展管理器”。
2. 选择 **Project** 或 **Global**，点击 `+` 并导入下载的 ZIP。
3. 启用扩展，然后打开 **Tripo Model Generator** 面板。

标准 ZIP 导入流程请参阅 [Cocos Creator 3.8 扩展安装指南](https://docs.cocos.com/creator/3.8/manual/zh/editor/extension/install.html)。

### ComfyUI

1. 将 ZIP 解压到 `ComfyUI/custom_nodes/ComfyUI-Tripo`。
2. 在 ComfyUI 的 Python 环境中安装依赖：

```bash
python -m pip install -r ComfyUI/custom_nodes/ComfyUI-Tripo/requirements.txt
```

3. 重启 ComfyUI，然后加载或创建 Tripo 工作流。

## 配置 API Key

前往 [Tripo API Key 页面](/zh/keys)创建密钥，在开始任务前将它填入所选插件。

API Key 属于敏感凭证。不要把它提交到代码仓库、放入截图、输出到日志或打包进公开客户端。通用 API 规则请参阅[认证方式](/zh/docs/authentication)。

## 相关资源

- [Codex 插件](/zh/docs/codex-plugin)
- [认证方式](/zh/docs/authentication)
- [SDK 调用](/zh/docs/sdk)
- [Tripo API Key](/zh/keys)

=== FILE: quick-start.md ===
# 快速入门

15 分钟上手 Tripo API，从零开始生成你的第一个 3D 模型。

## 1. 获取 API Key

前往 [Tripo 控制台](https://platform.tripo3d.ai) 注册账号，进入「API 密钥」页面创建一个 API Key。

## 2. 发送第一个请求

使用文本描述生成一个 3D 模型：

### curl

```bash
curl -X POST https://openapi.tripo3d.com/v3/generation/text-to-model \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {api_key}" \
  -d '{
    "prompt": "a cute cat",
    "model": "tripo-v3.1"
  }'
```

成功响应：

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

## 3. 查询任务结果

3D 生成是异步任务，使用返回的 `task_id` 轮询任务状态：

```bash
curl -X GET https://openapi.tripo3d.com/v3/tasks/task_abc123 \
  -H "Authorization: Bearer {api_key}"
```

当 `status` 为 `success` 时，任务完成：

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://...",
      "rendered_image_url": "https://..."
    }
  }
}
```

## 4. 下载模型

从响应中的 `output.model_url` 下载 GLB 格式的 3D 模型文件，可直接在 Blender、Unity、Three.js 等工具中使用。

## 完整示例

### Python

```python
import time
import requests

API_KEY = "your_api_key_here"
BASE_URL = "https://openapi.tripo3d.com/v3"

headers = {
    "Content-Type": "application/json",
    "Authorization": f"Bearer {API_KEY}"
}

# 1. 创建文生 3D 任务
response = requests.post(
    f"{BASE_URL}/generation/text-to-model",
    headers=headers,
    json={
        "prompt": "a cute cat",
        "model": "tripo-v3.1"
    }
)
task_id = response.json()["data"]["task_id"]
print(f"任务已创建: {task_id}")

# 2. 轮询等待任务完成
while True:
    response = requests.get(
        f"{BASE_URL}/tasks/{task_id}",
        headers={"Authorization": f"Bearer {API_KEY}"}
    )
    task = response.json()["data"]
    status = task["status"]
    progress = task.get("progress", 0)

    print(f"状态: {status}, 进度: {progress}%")

    if status == "success":
        model_url = task["output"]["model_url"]
        print(f"模型下载地址: {model_url}")
        break
    elif status in ("failed", "cancelled", "banned"):
        print(f"任务失败: {status}")
        break

    time.sleep(2)

# 3. 下载模型文件
if status == "success":
    model_data = requests.get(model_url)
    with open("model.glb", "wb") as f:
        f.write(model_data.content)
    print("模型已保存为 model.glb")
```

### JavaScript

```javascript
const API_KEY = "your_api_key_here";
const BASE_URL = "https://openapi.tripo3d.com/v3";

async function generateModel() {
  // 1. 创建文生 3D 任务
  const createResponse = await fetch(`${BASE_URL}/generation/text-to-model`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${API_KEY}`
    },
    body: JSON.stringify({
      prompt: "a cute cat",
      model: "tripo-v3.1"
    })
  });
  const { data: { task_id } } = await createResponse.json();
  console.log(`任务已创建: ${task_id}`);

  // 2. 轮询等待任务完成
  while (true) {
    const pollResponse = await fetch(`${BASE_URL}/tasks/${task_id}`, {
      headers: { "Authorization": `Bearer ${API_KEY}` }
    });
    const { data: task } = await pollResponse.json();
    const { status, progress = 0 } = task;

    console.log(`状态: ${status}, 进度: ${progress}%`);

    if (status === "success") {
      console.log(`模型下载地址: ${task.output.model_url}`);
      return task.output;
    }
    if (["failed", "cancelled", "banned"].includes(status)) {
      throw new Error(`任务失败: ${status}`);
    }

    await new Promise(resolve => setTimeout(resolve, 2000));
  }
}

generateModel().catch(console.error);
```

=== FILE: rate-limits.md ===
# 速率限制与并发控制

Tripo API 通过速率限制和并发限制来保障服务稳定性和公平使用。

## 速率限制

速率限制约束你在一个时间窗口内能发起的 API 请求数量。

### 限制规则

- 限流按 **API Key** 粒度计算
- 不同端点的限制不同：生成类端点（`/v3/generation/*`）限制较低，查询类端点（`/v3/tasks/*`）限制较高
- 超出限制时返回 HTTP `429 Too Many Requests`，错误码 `1007`

### 响应头

每个 API 响应都包含限流相关的响应头：

| 响应头 | 说明 |
| :-: | :-: |
| `X-RateLimit-Limit` | 当前时间窗口内允许的最大请求数 |
| `X-RateLimit-Remaining` | 当前时间窗口内剩余可用请求数 |
| `X-RateLimit-Reset` | 限流窗口重置的 Unix 时间戳（秒） |

### 触发限流时的响应

```json
{
  "code": 1007,
  "message": "Rate limit exceeded, you've generated too many requests in a short amount of time",
  "suggestion": "Please wait for a while and try again"
}
```

---

## 并发限制

并发限制约束你的账户下能**同时运行**的任务数量。这与速率限制不同——速率限制管控请求频率，并发限制管控同时执行的任务数。

### 运作机制

- 并发按**账户**维度计算（不是按单个 API Key）
- 按**任务类目**独立限制——每个类目拥有独立的并发池
- 当某个类目的并发占满时，该类目下新建任务会返回 HTTP `429`，错误码 `2000`
- 其他类目**不受影响**——并发池满的类目不会阻塞其他类目的任务创建

### 默认限制

所有用户的默认并发数为每个类目 **10** 个，部分类目有不同上限（见下表）。

| 类目 | 包含的任务类型 | 默认并发数 |
| :-: | :-: | :-: |
| 3D 生成 — H 系列 | 文本生成模型 (H)、图片生成模型 (H)、多视图生成模型 (H) | 10 |
| 3D 生成 — P 系列 | 文本生成模型 (P)、图片生成模型 (P)、多视图生成模型 (P) | 5 |
| 图像生成 | 文本生成图像、图生图、图片生成多视图、编辑多视图 | 1 |
| 动画 | 自动绑骨、绑骨前检查、动画重定向 | 10 |
| 模型后处理 | 贴图、格式转换、精修 | 5 |
| 网格操作 | 语义分割、网格补全、重拓扑 | 10 |

> **说明：** 同一类目内的所有任务类型共享并发池。例如，如果你正在运行 10 个 H 系列的文本生成模型任务，就无法再启动 H 系列的图片生成模型任务，需等待其中一个完成后才能创建新任务。但与此同时，你仍可以正常创建 P 系列或图像生成类任务。

### 并发超限时的响应

```json
{
  "code": 2000,
  "message": "You have exceeded the limit of generation",
  "suggestion": "Try again later. You can also check `Retry-After` header."
}
```

响应中包含 `Retry-After` 头，指示建议等待的秒数。

### 提升并发额度

如需更高的并发限制，请通过支持渠道联系我们。我们可以按类目为你单独配置并发上限。

---

## 处理 429 响应

### Python

```python
import time
import requests

def request_with_backoff(method, url, headers, json=None, max_retries=5):
    for attempt in range(max_retries):
        response = requests.request(method, url, headers=headers, json=json)

        if response.status_code != 429:
            return response

        retry_after = response.headers.get("Retry-After")
        reset_at = response.headers.get("X-RateLimit-Reset")

        if retry_after:
            wait = int(retry_after)
        elif reset_at:
            wait = max(int(reset_at) - int(time.time()), 1)
        else:
            wait = 2 ** attempt

        print(f"触发 429，等待 {wait} 秒（第 {attempt + 1} 次重试）...")
        time.sleep(wait)

    raise Exception("重试次数已用尽")
```

### JavaScript

```javascript
async function requestWithBackoff(url, options, maxRetries = 5) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const response = await fetch(url, options);

    if (response.status !== 429) {
      return response;
    }

    const retryAfter = response.headers.get("Retry-After");
    const resetAt = response.headers.get("X-RateLimit-Reset");
    const wait = retryAfter
      ? Number(retryAfter)
      : resetAt
        ? Math.max(Number(resetAt) - Math.floor(Date.now() / 1000), 1)
        : 2 ** attempt;

    console.log(`触发 429，等待 ${wait} 秒（第 ${attempt + 1} 次重试）...`);
    await new Promise(resolve => setTimeout(resolve, wait * 1000));
  }

  throw new Error("重试次数已用尽");
}
```

## 最佳实践

- **实现指数退避重试**：首次等待 1 秒，每次翻倍，最大等待 32 秒
- **优先使用 `Retry-After` 和 `X-RateLimit-Reset` 响应头**：精确等待到限制窗口重置
- **合理利用类目并发池**：图像生成和 3D 生成拥有独立的并发池，可以并行调度不同类目的任务
- **使用批量接口**：用 `POST /v3/tasks/list` 替代多次 `GET /v3/tasks/{task_id}`
- **合理轮询间隔**：等待任务完成时，以 1–2 秒的间隔轮询，避免对查询端点造成压力

=== FILE: sdk.md ===
# SDK 调用

使用 Tripo 官方 SDK 提交文本生成模型任务、等待任务完成、验证终态，并下载生成的模型。以下安装来源已锁定为验证本页面时使用的版本。

## 支持的 SDK

| 语言 | API | 锁定版本 | 安装来源 |
| --- | --- | --- | --- |
| JavaScript / TypeScript | V3 | [`e351348`](https://github.com/VAST-AI-Research/tripo-js-sdk/tree/e35134801b339caac0b84f36fe02d08e73e217b2) | 官方 Git commit |
| Python | V2 + limited V3 | [`v0.4.2`](https://github.com/VAST-AI-Research/tripo-python-sdk/tree/v0.4.2) | PyPI `tripo3d==0.4.2` |
| Go | V3 | [`2c8c8d4`](https://github.com/VAST-AI-Research/tripo-go-sdk/tree/2c8c8d4e6a9e1fc9e49699fc055140eca689ee79) | Go 伪版本 `v0.0.0-20260713072120-2c8c8d4e6a9e` |
| Rust | V3 | [`f992f6a`](https://github.com/VAST-AI-Research/tripo-rust-sdk/tree/f992f6a7cf7a28c10781f9fa28e4630c7802291c) | Cargo Git 依赖 |
| Java | V3 | [`7b6a68d`](https://github.com/VAST-AI-Research/tripo-java-sdk/tree/7b6a68d855e01a0b098775b1ee14ce7f3c8ac7d9) | 源码构建；本地 Maven `0.1.0-SNAPSHOT` |

## 1. 配置 API Key 与地域

在 [Tripo 控制台](/zh/keys)创建密钥，并且只向服务端进程提供。不要将 API Key 放入浏览器代码或提交到源码仓库。

```bash
export TRIPO_API_KEY="tsk_..."
```

JavaScript、Go 和 Rust 使用 `https://openapi.tripo3d.com/v3`。Java 选择 `TripoRegion.CN`；SDK 从 `https://openapi.tripo3d.com` 开始并拼接 `/v3`。Python 0.4.2 的主 V2 客户端使用 `https://api.tripo3d.com/v2/openapi`；其有限的 V3 分割流程使用 `https://openapi.tripo3d.com`。

## 2. 安装 SDK

从各 SDK 锁定的生产来源进行安装。

### JavaScript

```bash
npm install github:VAST-AI-Research/tripo-js-sdk#e35134801b339caac0b84f36fe02d08e73e217b2
```

### Python

```bash
python -m pip install tripo3d==0.4.2
```

### Go

```bash
go get github.com/VAST-AI-Research/tripo-go-sdk@v0.0.0-20260713072120-2c8c8d4e6a9e
```

### Rust

```toml
[dependencies]
tripo3d-sdk = { git = "https://github.com/VAST-AI-Research/tripo-rust-sdk.git", rev = "f992f6a7cf7a28c10781f9fa28e4630c7802291c" }
tokio = { version = "1", features = ["full"] }
anyhow = "1"
```

### Java

```bash
git clone https://github.com/VAST-AI-Research/tripo-java-sdk.git
cd tripo-java-sdk
git checkout 7b6a68d855e01a0b098775b1ee14ce7f3c8ac7d9
./mvnw install
```

Java 构建会将 `ai.tripo3d:tripo-sdk:0.1.0-SNAPSHOT` 安装到本地 Maven 仓库。源码构建完成后，在应用中添加该坐标。

## 3. 提交、等待并下载

每个服务端示例都会读取 `TRIPO_API_KEY`、提交文本生成模型任务、等待终态、检查任务是否成功，并立即保存主模型。生成的模型 URL 是临时地址。

### JavaScript

```javascript
import { writeFile } from 'node:fs/promises';
import { TripoClient, ModelVersion, TaskStatus } from 'tripo3d-sdk-js';

const apiKey = process.env.TRIPO_API_KEY;
if (!apiKey) throw new Error('TRIPO_API_KEY is required');

const client = new TripoClient({
  apiKey,
  baseUrl: 'https://openapi.tripo3d.com/v3',
});

const taskId = await client.textToModel({
  prompt: 'a cute red panda holding bamboo',
  model: ModelVersion.H3_1,
  texture: true,
  pbr: true,
  texture_quality: 'detailed',
});

const task = await client.waitForTask(taskId, {
  pollingIntervalMs: 2000,
  onProgress: (value) => console.log(`${value.status} — ${value.progress ?? 0}%`),
});

if (task.status !== TaskStatus.SUCCESS) {
  throw new Error(`Task did not succeed: ${task.status}`);
}

const modelUrl = task.output.model_url ?? task.output.model;
if (!modelUrl) throw new Error('Task returned no model URL');

const response = await fetch(modelUrl);
if (!response.ok) throw new Error(`Download failed: HTTP ${response.status}`);

await writeFile(`tripo-${taskId}.glb`, Buffer.from(await response.arrayBuffer()));
```

### Python

```python
import asyncio
import os
import shutil
from urllib.request import urlopen

from tripo3d import TripoClient
from tripo3d.models import TaskStatus


def download_file(url, path):
    with urlopen(url) as response, open(path, "wb") as output:
        shutil.copyfileobj(response, output)


async def main():
    api_key = os.environ["TRIPO_API_KEY"]
    os.makedirs("./output", exist_ok=True)

    async with TripoClient(api_key=api_key) as client:
        task_id = await client.text_to_model(
            prompt="a cute red panda holding bamboo",
            model_version="v2.5-20250123",
        )
        task = await client.wait_for_task(task_id, verbose=True)

        if task.status != TaskStatus.SUCCESS:
            raise RuntimeError(f"Task did not succeed: {task.status}")

        model_url = task.output.model
        if not model_url:
            raise RuntimeError("Task returned no model URL")

        output_path = "./output/model.glb"
        await asyncio.to_thread(download_file, model_url, output_path)
        print(f"Downloaded model: {output_path}")


asyncio.run(main())
```

### Go

```go
package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"time"

	tripo3d "github.com/VAST-AI-Research/tripo-go-sdk"
)

func main() {
	apiKey := os.Getenv("TRIPO_API_KEY")
	if apiKey == "" {
		log.Fatal("TRIPO_API_KEY is required")
	}

	client, err := tripo3d.NewClient(tripo3d.ClientOptions{
		APIKey:  apiKey,
		BaseURL: "https://openapi.tripo3d.com/v3",
	})
	if err != nil {
		log.Fatal(err)
	}

	ctx := context.Background()
	taskID, err := client.TextToModel(ctx, tripo3d.TextToModelParams{
		Prompt:         "a cute red panda holding bamboo",
		Model:          tripo3d.String(tripo3d.ModelVersionH31),
		Texture:        tripo3d.Bool(true),
		PBR:            tripo3d.Bool(true),
		TextureQuality: tripo3d.String("detailed"),
	})
	if err != nil {
		log.Fatal(err)
	}

	task, err := client.WaitForTask(ctx, taskID, tripo3d.WaitOptions{
		PollInterval: 2 * time.Second,
	})
	if err != nil {
		log.Fatal(err)
	}
	if task.Status != tripo3d.TaskStatusSuccess {
		log.Fatalf("Task did not succeed: %s", task.Status)
	}

	downloaded, err := client.DownloadModel(ctx, task)
	if err != nil {
		log.Fatal(err)
	}
	if downloaded == nil {
		log.Fatal("Task returned no model URL")
	}

	filename := fmt.Sprintf("tripo-%s.glb", taskID)
	if err := os.WriteFile(filename, downloaded.Data, 0o644); err != nil {
		log.Fatal(err)
	}
}
```

### Rust

```rust
use tokio::fs;
use tripo3d_sdk::{
    constants::model_version,
    params::TextToModelParams,
    ClientOptions,
    TaskStatus,
    TripoClient,
    WaitOptions,
};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let api_key = std::env::var("TRIPO_API_KEY")?;
    let client = TripoClient::new(ClientOptions {
        api_key: Some(api_key),
        base_url: Some("https://openapi.tripo3d.com/v3".into()),
        ..Default::default()
    })?;

    let task_id = client
        .text_to_model(TextToModelParams {
            prompt: "a cute red panda holding bamboo".into(),
            model: Some(model_version::H3_1.to_string()),
            texture: Some(true),
            pbr: Some(true),
            texture_quality: Some("detailed".into()),
            ..Default::default()
        })
        .await?;

    let task = client
        .wait_for_task(&task_id, WaitOptions::default())
        .await?;
    if task.status != TaskStatus::Success {
        anyhow::bail!("Task did not succeed: {}", task.status);
    }

    let downloaded = client
        .download_model(&task)
        .await?
        .ok_or_else(|| anyhow::anyhow!("Task returned no model URL"))?;

    fs::write(format!("tripo-{task_id}.glb"), downloaded.data).await?;
    Ok(())
}
```

### Java

```java
import ai.tripo3d.sdk.api.TripoClient;
import ai.tripo3d.sdk.api.TripoClientConfig;
import ai.tripo3d.sdk.api.TripoRegion;
import ai.tripo3d.sdk.model.request.TaskRequestPayload;
import ai.tripo3d.sdk.model.response.TaskDetail;

import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Map;

public final class TripoQuickStart {
    public static void main(String[] args) throws Exception {
        String apiKey = System.getenv("TRIPO_API_KEY");
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalStateException("TRIPO_API_KEY is required");
        }

        try (TripoClient client = TripoClient.create(
                TripoClientConfig.builder(apiKey)
                        .region(TripoRegion.GLOBAL)
                        .build())) {
            TaskDetail created = client.textToModel(TaskRequestPayload.builder()
                    .prompt("a wooden chair")
                    .model("v3.1-20260211")
                    .build());

            TaskDetail done = client.pollUntilTerminal(created.taskId());
            if (!"success".equalsIgnoreCase(done.status())) {
                throw new IllegalStateException(
                        "Task failed: status=" + done.status()
                                + ", message=" + done.errorMsg());
            }

            Map<String, Object> output = done.output();
            Object modelUrl = output == null ? null : output.get("model_url");
            if (!(modelUrl instanceof String)) {
                throw new IllegalStateException(
                        "Task output does not contain model_url");
            }

            try (InputStream input =
                         new URL((String) modelUrl).openStream()) {
                Files.copy(
                        input,
                        Paths.get("model.glb"),
                        StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }
}
```

JavaScript、Python 和 Java 特意使用原生 HTTP 客户端获取签名模型 URL，并且不附加 `Authorization` 请求头。Go 和 Rust SDK 的下载方法同样不会在获取签名 URL 时携带 API Key。

## 4. V3 路由支持

该矩阵是上述锁定版本中五个 SDK 实现的并集。勾号表示某个公开 SDK 流程会直接或通过内部步骤访问最终的 V3 HTTP 路由；未使用的路由常量不计入支持。

| HTTP 路由 | 用途 | JavaScript | Python | Go | Rust | Java |
| --- | --- | :---: | :---: | :---: | :---: | :---: |
| `POST /v3/generation/text-to-model` | 根据文本生成模型 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/generation/image-to-model` | 根据单张图像生成模型 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/generation/multiview-to-model` | 根据多个视图生成模型 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/generation/text-to-image` | 根据文本生成图像 | ✓ | — | ✓ | ✓ | — |
| `POST /v3/generation/image-to-image` | 转换图像 | ✓ | — | ✓ | ✓ | — |
| `POST /v3/generation/image-to-multiview` | 生成多视图图像 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/generation/edit-multiview` | 编辑多视图输出 | ✓ | — | ✓ | ✓ | — |
| `POST /v3/generation/image-to-splat` | 生成高斯泼溅模型 | — | — | — | — | ✓ |
| `POST /v3/models/refine` | 优化草模 | — | — | — | — | ✓ |
| `POST /v3/models/texture` | 应用或重新生成纹理 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/models/stylize` | 风格化模型 | — | — | — | — | ✓ |
| `POST /v3/models/convert` | 转换模型格式 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/models/import` | 导入外部模型 | — | — | — | — | ✓ |
| `POST /v3/mesh/segment` | 分割网格 | ✓ | ✓ | ✓ | ✓ | ✓ |
| `POST /v3/mesh/complete` | 补全或修复网格 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/mesh/decimate` | 减少面数 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/animations/rig-check` | 检查模型是否可以绑定骨骼 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/animations/rig` | 绑定骨骼 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/animations/retarget` | 应用预设动画 | ✓ | — | ✓ | ✓ | ✓ |
| `GET /v3/tasks/{task_id}` | 获取单个任务 | ✓ | ✓ | ✓ | ✓ | ✓ |
| `POST /v3/tasks/list` | 获取多个任务 | ✓ | — | ✓ | ✓ | ✓ |
| `POST /v3/files` | 上传文件 | ✓ | ✓ | ✓ | ✓ | ✓ |
| `POST /v3/files/presign` | 创建预签名上传 | — | — | — | — | ✓ |
| `GET /v3/account/balance` | 获取账户余额 | ✓ | — | ✓ | ✓ | ✓ |
| `GET /v3/account/usage` | 获取用量历史 | — | — | — | — | ✓ |

在该锁定版本中，只有 Java 公开了 image-to-splat、refine、stylize、import、presign 和 usage。Java 不提供 text-to-image、image-to-image 或 edit-multiview。其内部虽然声明了 `/v3/files/upload-credentials` 描述符，但没有对应的服务或公开客户端方法，因此不计为支持。

Python 仍以 V2 为主。仅当调用 `mesh_segmentation(..., model_version="v2.0-20260430")` 时，它还会使用 `POST /v3/mesh/segment`、`GET /v3/tasks/{task_id}`，并在需要上传本地 `ref_image` 时使用 `POST /v3/files`。

### Python V2 路由支持

Python 0.4.2 共公开五条最终 V2 HTTP 路由。`POST /v2/openapi/task` 由生成、模型处理、网格和动画任务方法共用，并不只用于文本生成模型。

| HTTP 路由 | 用途 |
| --- | --- |
| `POST /v2/openapi/task` | 提交任意受支持的 V2 任务 |
| `GET /v2/openapi/task/{task_id}` | 查询任务状态和输出 |
| `GET /v2/openapi/user/balance` | 获取账户余额 |
| `POST /v2/openapi/upload/sts/token` | 在 `boto3` 可用时获取 STS 上传凭证 |
| `POST /v2/openapi/upload` | SDK 使用旧版 multipart 回退方案时上传文件 |

Java 和其他 V3 SDK 通过各自的官方 V3 参数模型发送模型选择。Java 线上请求中的字段名为 `model`。

## 5. 故障排查

- **缺少密钥：** 在服务端进程中设置 `TRIPO_API_KEY`。请参阅[身份认证](./authentication)。
- **地域错误：** 根据正在使用的 SDK 和 API 版本选择匹配的全球或中国区域端点。
- **任务失败或超时：** 保留 `task_id`，检查任务终态，并参阅[任务生命周期](./task-lifecycle)和[错误处理](./error-handling)。
- **模型 URL 已过期：** 如果 SDK 支持，请重新查询任务，然后立即下载模型。不要将临时签名 URL 作为永久资源保存。

## 官方仓库

- [JavaScript SDK](https://github.com/VAST-AI-Research/tripo-js-sdk)
- [Python SDK](https://github.com/VAST-AI-Research/tripo-python-sdk)
- [Go SDK](https://github.com/VAST-AI-Research/tripo-go-sdk)
- [Rust SDK](https://github.com/VAST-AI-Research/tripo-rust-sdk)
- [Java SDK](https://github.com/VAST-AI-Research/tripo-java-sdk)

=== FILE: task-batch-query.md ===
# 批量任务查询

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /tasks/list`

在单次请求中批量查询多个异步任务的状态和输出。返回以 task_id 为键的任务详情 map，以及未找到的任务 ID 列表。

## Request Parameters

### task_ids

- **Type:** string[]
- **Required:** 必选

要查询的任务 ID 数组。每次请求最多 **100** 个。
示例： `["task_abc123", "task_def456"]`

## Response Fields

### tasks

- **Type:** object
- **Required:** 必选

以 task_id 为键的任务详情 map。每个值的结构与单任务查询响应相同。
### missed

- **Type:** string[]
- **Required:** 必选

未找到的任务 ID 列表（无效 ID、错误的 API Key 或已过期）。

## Request Example

### 批量查询

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/tasks/list \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "task_ids": [
    "task_abc123",
    "task_def456"
  ]
}'
```


## Response Example

### 批量结果

```json
{
  "code": 0,
  "data": {
    "tasks": {
      "task_abc123": {
        "task_id": "task_abc123",
        "type": "text_to_model",
        "status": "success",
        "progress": 100,
        "credits_consumed": 100.00
      },
      "task_def456": {
        "task_id": "task_def456",
        "type": "image_to_model",
        "status": "running",
        "progress": 60
      }
    },
    "missed": []
  }
}
```

=== FILE: task-lifecycle.md ===
# 任务生命周期

Tripo API 的生成类接口均采用异步任务模式。提交请求后返回 `task_id`，通过轮询查询任务状态和结果。

## 状态机

```
queued → running → success
                 → failed
                 → cancelled
```

## 状态说明

| 状态 | 说明 | progress |
| :-: | :-: | :-: |
| `queued` | 任务已创建，排队等待处理 | 0 |
| `running` | 任务正在处理中 | 0–100 |
| `success` | 任务完成，`output` 字段可用 | 100 |
| `failed` | 任务失败，通常是服务端问题，请联系支持 | — |
| `banned` | 输入内容违反内容政策 | — |
| `expired` | 任务已过期，输出文件不再可用 | — |
| `cancelled` | 任务已被取消 | — |

## 任务流程

```
1. 创建任务 (POST /v3/generation/*)
   ↓
2. 返回 task_id
   ↓
3. 轮询状态 (GET /v3/tasks/{task_id})
   ↓
4a. status=success → 获取 output 中的下载链接
4b. status=failed  → 检查错误信息，联系支持
4c. status=banned  → 修改输入内容后重新提交
```

## 积分冻结模型

Tripo 采用「冻结-扣除」的积分模型，确保用户不会为失败的任务付费：

| 阶段 | 积分变化 | 说明 |
| :-: | :-: | :-: |
| 创建任务 | 冻结对应积分 | 从可用余额中预扣，进入冻结状态 |
| 任务成功 | 冻结积分转为已消耗 | 正式扣除 |
| 任务失败 | 冻结积分退回 | 退还到可用余额 |
| 任务取消 | 冻结积分退回 | 退还到可用余额 |

查询当前余额和冻结积分：

```bash
curl -X GET https://openapi.tripo3d.com/v3/account/balance \
  -H "Authorization: Bearer {api_key}"
```

```json
{
  "code": 0,
  "data": {
    "balance": 10000.00,
    "frozen": 200.00
  }
}
```

## 轮询建议

- **轮询间隔**：每 1–2 秒查询一次
- **使用 `progress` 字段展示进度**：值为 0–100 的整数
- **设置超时**：建议设置最大轮询时间（如 5 分钟），超时后提示用户稍后查看
- **批量任务使用 `POST /v3/tasks/list`**：减少请求次数

### Python 轮询示例

```python
import time
import requests

def wait_for_task(task_id, api_key, interval=2, timeout=300):
    url = f"https://openapi.tripo3d.com/v3/tasks/{task_id}"
    headers = {"Authorization": f"Bearer {api_key}"}
    start = time.time()

    while time.time() - start < timeout:
        response = requests.get(url, headers=headers)
        task = response.json()["data"]
        status = task["status"]
        progress = task.get("progress", 0)

        print(f"[{task_id}] {status} ({progress}%)")

        if status == "success":
            return task["output"]
        if status in ("failed", "cancelled", "banned"):
            raise Exception(f"任务终止: {status}")

        time.sleep(interval)

    raise TimeoutError(f"任务 {task_id} 超时")
```

### JavaScript 轮询示例

```javascript
async function waitForTask(taskId, apiKey, interval = 2000, timeout = 300000) {
  const url = `https://openapi.tripo3d.com/v3/tasks/${taskId}`;
  const headers = { "Authorization": `Bearer ${apiKey}` };
  const start = Date.now();

  while (Date.now() - start < timeout) {
    const response = await fetch(url, { headers });
    const { data: task } = await response.json();
    const { status, progress = 0 } = task;

    console.log(`[${taskId}] ${status} (${progress}%)`);

    if (status === "success") return task.output;
    if (["failed", "cancelled", "banned"].includes(status)) {
      throw new Error(`任务终止: ${status}`);
    }

    await new Promise(resolve => setTimeout(resolve, interval));
  }

  throw new Error(`任务 ${taskId} 超时`);
}
```

=== FILE: task-query.md ===
# 任务查询

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `GET /tasks/{task_id}`

通过任务 ID 查询单个异步任务的状态和输出。所有生成和处理端点都会返回可用于此处查询的 task_id。

## Request Parameters

### task_id

- **Type:** string
- **Required:** 必选

唯一任务标识符，作为路径参数传入。以 task_ 开头。

## Response Fields

### task_id

- **Type:** string
- **Required:** 必选

唯一任务标识符。
### type

- **Type:** string
- **Required:** 必选

任务类型（如 text_to_model、rig、convert）。
### status

- **Type:** string
- **Required:** 必选

任务状态。
- `queued`：排队等待中。
- `running`：处理中。
- `success`：已成功完成。
- `failed`：失败并报错。
- `cancelled`：已被用户取消。

### progress

- **Type:** integer
- **Required:** 必选

0–100。
### error_code

- **Type:** integer
- **Required:** 可选

status=failed 时返回。标准化错误码，标识失败原因。
### error_message

- **Type:** string
- **Required:** 可选

status=failed 且存在 error_code 时返回。对应错误码的相关描述。
### output

- **Type:** object
- **Required:** 可选

仅在 `status=success` 时填充。包含 `model_url`、`rendered_image_url` 等。
### credits_consumed

- **Type:** number
- **Required:** 可选

消耗的额度。最多两位小数的数值（例如 48.00）。
### created_at

- **Type:** string
- **Required:** 必选

ISO 8601 创建时间。
### completed_at

- **Type:** string
- **Required:** 可选

ISO 8601 完成时间。

## Request Example

### 查询任务

```
curl -s \
  -H "Authorization: Bearer YOUR_API_KEY" \
  https://openapi.tripo3d.com/v3/tasks/task_abc123
```


## Response Example

### 任务详情

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```

=== FILE: webhooks.md ===
# Webhooks

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST https://<your-endpoint>`

当任务完成或失败、或积分余额低于你在账单中的告警阈值时，Tripo 会向你的 HTTPS URL 投递 JSON，因此无需轮询 `GET /v3/tasks/{task_id}`。配置流程
- 打开 **设置 → Webhooks**，点击 **添加端点**。
- 填写 HTTPS 回调地址（例如 `https://api.yourapp.com/tripo-webhook`）。
- 选择要订阅的事件类型。
- 点击 **保存端点**。
- 复制 **签名密钥**（`whsec_…`）——仅显示一次，请像 API Key 一样妥善保管。

事件类型
- `task.completed`：任务成功结束。
- `task.failed`：任务失败或已取消。
- `balance.low`：余额低于在 **账单 → 额度告警**中设定的阈值（告警本身不决定任务是否成功）。

重试策略若你的端点返回非 2xx 或超时，Tripo 会自动重试。可在 设置 → Webhooks → 最近投递记录 中排查失败原因。
最佳实践
- 处理业务前务必用签名密钥验证载荷来源。
- 约 5 秒内返回 `2xx`；重逻辑异步处理。
- 使用 `Tripo-Webhook-Delivery` 做投递去重。
- 在 账单 中开启 `balance.low` 以便余额不足前收到通知。




## Request Parameters

### id

- **Type:** string
- **Required:** 必选

组合后的事件 ID（通常包含 task_id 与事件类型）。
### type

- **Type:** string
- **Required:** 必选

取值为 `task.completed`、`task.failed`、`balance.low` 之一。
### created_at

- **Type:** string
- **Required:** 必选

事件创建时间，ISO 8601 字符串。
### data

- **Type:** object
- **Required:** 必选

事件相关载荷。任务类事件中的字段与任务查询接口返回一致；balance.low 时包含与余额相关的字段。


- 任务事件：通常包含 `task_id`、`type`、`status`，成功时含 `output`。
- `balance.low`：阈值在 账单 → 额度告警 中配置。

### Tripo-Webhook-Id

- **Type:** header · string
- **Required:** 必选

Tripo 侧 Webhook 端点 ID。
### Tripo-Webhook-Delivery

- **Type:** header · string
- **Required:** 必选

唯一投递 ID——若同一逻辑事件多次投递，可据此去重。
### Tripo-Webhook-Event

- **Type:** header · string
- **Required:** 必选

与 JSON 体中的 type 一致。
### Tripo-Webhook-Signature

- **Type:** header · string
- **Required:** 必选

使用签名密钥对 `{时间戳}.{原始请求体}` 做 HMAC-SHA256。格式： `t=<unix>,v1=<hex>`。


- 从请求头解析 `t` 与 `v1`。
- 以密钥计算 HMAC-SHA256(`t + "." + 原始 body`)，小写十六进制。
- 与 `v1` 做常量时间比较。
- 可选：若 t 与当前时间相差超过约 5 分钟则拒绝（防重放）。

### Content-Type

- **Type:** header · string
- **Required:** 必选
- **Default:** `application/json`

固定为 application/json。

## Response Fields

### HTTP

- **Type:** status
- **Required:** 必选

应尽快返回 2xx（数秒内）。在重计算完成前即可先响应。

## Request Example

### task.completed

```
{
  "id": "task_abc123:task.completed",
  "type": "task.completed",
  "created_at": "2026-05-06T12:00:00Z",
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb"
    }
  }
}
```

### balance.low

```
{
  "id": "evt_balance_low:balance.low",
  "type": "balance.low",
  "created_at": "2026-05-06T12:00:00Z",
  "data": {
    "balance": 1200,
    "threshold": 5000
  }
}
```

### 验证 · Python

```
import hmac
import hashlib
import time

def verify_webhook(payload: bytes, signature_header: str, secret: str) -> bool:
    parts = dict(p.split("=", 1) for p in signature_header.split(","))
    timestamp = parts.get("t", "")
    expected_sig = parts.get("v1", "")

    if abs(time.time() - int(timestamp)) > 300:
        return False

    computed = hmac.new(
        secret.encode("utf-8"),
        f"{timestamp}.{payload.decode('utf-8')}".encode("utf-8"),
        hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(computed, expected_sig)
```

### 验证 · JavaScript

```
const crypto = require("crypto");

function verifyWebhook(payload, signatureHeader, secret) {
  const parts = Object.fromEntries(
    signatureHeader.split(",").map(p => p.split("=", 2))
  );
  const timestamp = parts.t;
  const expectedSig = parts.v1;

  if (Math.abs(Date.now() / 1000 - parseInt(timestamp)) > 300) {
    return false;
  }

  const computed = crypto
    .createHmac("sha256", secret)
    .update(`${timestamp}.${payload}`)
    .digest("hex");

  return crypto.timingSafeEqual(
    Buffer.from(computed),
    Buffer.from(expectedSig)
  );
}
```


## Response Example

### Tripo-Webhook-Signature

```json
Tripo-Webhook-Signature: t=1714992000,v1=5257a869e7ecebeda32affa62cdca3fa51cad7e77a0e56ff536d0ce8e108d8f9
```

### task.failed

```json
{
  "id": "task_abc123:task.failed",
  "type": "task.failed",
  "created_at": "2026-05-06T12:00:05Z",
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "failed",
    "error": {
      "code": "task_failed",
      "message": "Generation failed"
    }
  }
}
```

