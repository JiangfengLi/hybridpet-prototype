# 更新日志

## 贴图模型 v3.5-20260815（2026-09）

新一代贴图模型，两个入口：

- **`POST /v3/models/texture`**：`model` 新增 `v3.5-20260815`。默认值仍为 `v3.0-20250812`，不传参数行为不变。
- **生成接口**（`text-to-model`、`image-to-model`、`multiview-to-model`，含 P1 / P2）：新增 `texture_version`，可独立指定贴图模型，与几何体 `model` 解耦。可选值 `v3.5-20260815`、`v3.0-20250812`、`v2.5-20250123`；省略时按几何体版本推导（v2.5 几何体 → `v2.5-20250123`，其余 → `v3.0-20250812`）。

配套两个新参数，**均仅在 v3.5 贴图下生效**：

- **`texture_quality=fast`**：新增质量档，生成最快，以细节换速度。**输出贴图尺寸与积分均与 `standard` 相同**，仅细节表现更低。在非 v3.5 贴图上使用会返回 `1004`，不会静默降级为 `standard`。
- **`delight`**（boolean，默认 `true`）：贴图前去除参考图中的光照信息；设为 `false` 保留原有明暗。更早的贴图版本会忽略该参数。

## GPT Image 2.5、quality 档位与透明背景（2026-09）

`POST /v3/generation/text-to-image` 与 `POST /v3/generation/image-to-image` 新增两个模型，GPT Image 2/2.5 系列新增 `quality` 参数，两个 2.5 模型新增 `background` 参数。

- **新增模型**：`chat_image_2.5_flare` 与 `chat_image_2.5_sunburst`。两者积分相同，差别在取舍 —— flare 明显更快，sunburst 在编辑时对未指定修改的部分保持得更接近原图。
- **`quality`**：仅 `chat_image_2`（`low`、`medium`、`high`）与两个 2.5 模型（另支持 `xhigh`、`max`）可用。不传等同于 `low` —— 请注意这与 OpenAI 官方默认的 `auto` 不同，且本接口不支持 `auto`。`high`/`xhigh`/`max` 会额外消耗积分，详见定价页。
- **`background`**：取值 `auto`、`opaque`、`transparent`，仅两个 2.5 模型支持。不传则由模型自行决定。其它模型传入会被忽略而非报错，因此现有请求行为不变。
- **`transparent` 必须搭配 `output_format=png`**：JPEG 不支持 alpha 通道，两者同时传入会直接报错，而不是悄悄把透明背景压平。
- **自定义尺寸**：`chat_image_2` 与 2.5 系列支持任意 `宽x高`，需满足单边不超过 3840、两边均为 16 的倍数、长边不超过短边 3 倍、总像素在 655,360 与 8,294,400 之间。原有预设尺寸继续可用。
- **下线计划**：`chat_image_1` 将于 **2026-10-23** 下线，`chat_image_1.5` 将于 **2026-12-01** 下线。请在此之前迁移到 `chat_image_2` 或 2.5 系列。

## P2 系列模型（2026-08）

`POST /v3/generation/text-to-model`、`image-to-model`、`multiview-to-model` 现支持 `model=P2-20260801`（P1 升级版）。

- **P2 独有参数**：`quad`（四边面）。P1 传入 `quad=true` 会 `400`，请改用 P2 或去掉该字段。
- **`face_limit`**：三角面 48–50,000；`quad=true` 时 48–25,000。省略则自适应。
- **积分**：无贴图 100；`standard` / `detailed` / `extreme` 为 110 / 120 / 130（贴图加价与 P1 相同）。
- **P1**（`P1-20260311`）仍可用；P1 不支持 `quad`、`smart_low_poly`、`generate_parts`、`geometry_quality`。

## 文档更正（2026-08）

`credits_consumed`、`balance`、`frozen` 在 JSON 中为**数值（number）**，最多两位小数（例如 `48.00`、`41465.00`）。请使用浮点或 decimal 解析——**禁止**用整数解析（`int`、`parseInt` 等），否则会失败或截断小数部分（如 VIP 折扣）。

## v3.0 (2026-04)

### 全新 API 架构

- **独立端点替代万能 POST**：按能力分组的独立端点（如 `POST /v3/generation/text-to-model`）替代原有的 `POST /v2/openapi/task` + `type` 字段的万能接口
- **统一 `{input}-to-{output}` 命名规范**：所有生成类端点采用直观的命名方式，如 `text-to-model`、`image-to-multiview`、`multiview-to-model`
- **统一 `input` 字段**：支持 `task_id` / `file_token` / URL 自动推断输入来源，无需手动指定输入类型
- **去除 `/openapi` 冗余路径**：Base URL 从 `/v2/openapi/` 简化为 `/v3/`
- **文生图和图生图分离为独立端点**：`text-to-image` 和 `image-to-image` 不再合并为同一个接口

### 端点变更明细

| v2 端点 | v3 端点 |
| :-: | :-: |
| `POST /v2/openapi/task` type=text_to_model | `POST /v3/generation/text-to-model` |
| `POST /v2/openapi/task` type=image_to_model | `POST /v3/generation/image-to-model` |
| `POST /v2/openapi/task` type=multiview_to_model | `POST /v3/generation/multiview-to-model` |
| `POST /v2/openapi/task` type=text_to_image | `POST /v3/generation/text-to-image` |
| `POST /v2/openapi/task` type=generate_image | `POST /v3/generation/image-to-image` |
| `POST /v2/openapi/task` type=generate_multiview_image | `POST /v3/generation/image-to-multiview` |
| `POST /v2/openapi/task` type=edit_multiview_image | `POST /v3/generation/edit-multiview` |
| `POST /v2/openapi/task` type=refine_model | `POST /v3/models/refine` |
| `POST /v2/openapi/task` type=convert_model | `POST /v3/models/convert` |
| `POST /v2/openapi/task` type=import_model | `POST /v3/models/import` |
| `POST /v2/openapi/task` type=stylize_model | `POST /v3/models/stylize` |
| `POST /v2/openapi/task` type=texture_model | `POST /v3/models/texture` |
| `POST /v2/openapi/task` type=animate_prerigcheck | `POST /v3/animations/rig-check` |
| `POST /v2/openapi/task` type=animate_rig | `POST /v3/animations/rig` |
| `POST /v2/openapi/task` type=animate_retarget | `POST /v3/animations/retarget` |
| `POST /v2/openapi/task` type=mesh_segmentation | `POST /v3/mesh/segment` |
| `POST /v2/openapi/task` type=mesh_completion | `POST /v3/mesh/complete` |
| `POST /v2/openapi/task` type=highpoly_to_lowpoly | `POST /v3/mesh/decimate` |
| `GET /v2/openapi/task/{task_id}` | `GET /v3/tasks/{task_id}` |

### 字段变更

| v2 字段 | v3 字段 |
| :-: | :-: |
| `create_time` | `created_at` |
| `consumed_credit` | `credits_consumed` |
| `file` / `file_token` / `url` / `object` | 统一为 `input` |

### 新增能力

- `POST /v3/tasks/list`：批量查询任务
- `POST /v3/files/upload-credentials`：获取文件直传凭证
- `GET /v3/account/usage`：查询用量明细
