# 认证方式

所有 Tripo API 请求需要在 HTTP 请求头中携带 API Key 进行身份认证。

## 认证方式

在请求头中添加 `Authorization` 字段，值为 `Bearer {api_key}`：

```
Authorization: Bearer {api_key}
```

## 获取 API Key

1. 登录 [Tripo 控制台](https://platform.tripo3d.ai)
2. 进入「API 密钥」页面
3. 点击「创建密钥」生成新的 API Key
4. 复制并妥善保存（创建后仅显示一次）

## 请求示例

### curl

```bash
curl -X GET https://openapi.tripo3d.com/v3/account/balance \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Python

```python
import requests

headers = {
    "Authorization": "Bearer YOUR_API_KEY"
}

response = requests.get(
    "https://openapi.tripo3d.com/v3/account/balance",
    headers=headers
)
print(response.json())
```

### JavaScript

```javascript
const response = await fetch("https://openapi.tripo3d.com/v3/account/balance", {
  headers: {
    "Authorization": "Bearer YOUR_API_KEY"
  }
});

const data = await response.json();
console.log(data);
```

## 安全建议

- **使用环境变量存储 API Key**，不要硬编码在源代码中
- **不要将 API Key 提交到代码仓库**，在 `.gitignore` 中添加 `.env` 文件
- **前端应用不要直接使用 API Key**，通过后端服务代理请求
- **定期轮换密钥**，如果怀疑泄露，立即在控制台删除并重新创建

```bash
# 推荐：通过环境变量读取 API Key
export TRIPO_API_KEY="your_api_key_here"
```

```python
import os

api_key = os.environ["TRIPO_API_KEY"]
```

```javascript
const apiKey = process.env.TRIPO_API_KEY;
```
