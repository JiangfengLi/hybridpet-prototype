# 动画重定向

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /animations/retarget`

将预设动画应用到已绑骨的 3D 模型上。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

已绑骨模型的 task_id，以 `task_` 开头。
### animation

- **Type:** string
- **Required:** 条件必填

单个预设动画标识符。**与 `animations` 互斥，只能二选一。**


Rig v2.5-20260210 — 所有骨骼类型


- 双足：`preset:idle`、`preset:walk`、`preset:run`、`preset:dive`、`preset:climb`、`preset:jump`、`preset:slash`、`preset:shoot`、`preset:hurt`、`preset:fall`、`preset:turn`
- 四足：`preset:quadruped:walk`
- 其他：`preset:hexapod:walk`、`preset:octopod:walk`、`preset:serpentine:march`、`preset:aquatic:march`
Rig v1.0-20240301 — 仅双足（90+ 预设动画，点击展开）`preset:biped:afraid``preset:biped:agree``preset:biped:angry_01``preset:biped:angry_02``preset:biped:angry_03``preset:biped:basketball_shot``preset:biped:bow``preset:biped:box_01``preset:biped:box_02``preset:biped:box_03``preset:biped:cast_a_spell``preset:biped:cheer``preset:biped:chop``preset:biped:clap``preset:biped:climb``preset:biped:complain_01``preset:biped:complain_02``preset:biped:cross_body_crunch``preset:biped:crossover_dribble``preset:biped:cry``preset:biped:dance_01``preset:biped:dance_02``preset:biped:dance_03``preset:biped:dance_04``preset:biped:dance_05``preset:biped:dance_06``preset:biped:defeat_02``preset:biped:defeat_03``preset:biped:depressed``preset:biped:dig``preset:biped:dive``preset:biped:dribble``preset:biped:fall``preset:biped:fire``preset:biped:flee_01``preset:biped:flee_02``preset:biped:flip``preset:biped:fold_arms``preset:biped:football_catch``preset:biped:football_save``preset:biped:football_pass``preset:biped:freaky``preset:biped:frightened``preset:biped:front_kick_01``preset:biped:front_kick_02``preset:biped:frustrated_01``preset:biped:frustrated_02``preset:biped:golf``preset:biped:greet_01``preset:biped:greet_02``preset:biped:greet_03``preset:biped:greet_04``preset:biped:heart_pose``preset:biped:hit_to_body_01``preset:biped:hit_to_body_02``preset:biped:hit_to_head``preset:biped:hit_to_side``preset:biped:hit_to_stomach``preset:biped:hug``preset:biped:hurt``preset:biped:idle``preset:biped:jump_down``preset:biped:jump``preset:biped:jump_rope_01``preset:biped:jump_rope_02``preset:biped:laugh_01``preset:biped:laugh_02``preset:biped:lift_heavy``preset:biped:look_around``preset:biped:make_a_call_01``preset:biped:make_a_call_02``preset:biped:pitch_baseball``preset:biped:play_mobile_game``preset:biped:play_video_game``preset:biped:press-up``preset:biped:run_upstairs``preset:biped:run``preset:biped:scared_01``preset:biped:scared_02``preset:biped:scratch``preset:biped:shoot``preset:biped:shovel``preset:biped:sing_01``preset:biped:sing_02``preset:biped:sing_03``preset:biped:sing_04``preset:biped:sit``preset:biped:slash``preset:biped:sob``preset:biped:standing_relax``preset:biped:surf``preset:biped:swagger``preset:biped:swim``preset:biped:turn``preset:biped:victory_celebration``preset:biped:volleyball``preset:biped:wait``preset:biped:walk``preset:biped:warm_up``preset:biped:wave_goodbye_01``preset:biped:wave_goodbye_02`

### animations

- **Type:** string[]
- **Required:** 条件必填

多个预设动画标识符列表。**与 `animation` 互斥，只能二选一。**

### out_format

- **Type:** string
- **Required:** 可选
- **Default:** `glb`

输出格式。
- `glb`：二进制 glTF，适用于 Web。
- `fbx`：FBX，适用于 DCC 工具和游戏引擎。

### bake_animation

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

将动画烘焙到模型中。仅对 `glb` 输出有效。
### export_with_geometry

- **Type:** boolean
- **Required:** 可选
- **Default:** `true`

导出时包含几何体。
### animate_in_place

- **Type:** boolean
- **Required:** 可选
- **Default:** `false`

原地播放动画，无位移。

## Request Example

### 单个动画

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/animations/retarget \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "animation": "preset:walk",
  "out_format": "glb",
  "bake_animation": true
}'
```

### 批量动画

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/animations/retarget \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "animations": [
    "preset:idle",
    "preset:walk",
    "preset:run"
  ],
  "out_format": "fbx"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_def456",
    "status": "success",
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/animated.glb"
    },
    "credits_consumed": 20.00
  }
}
```
