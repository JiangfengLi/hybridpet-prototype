# 图像生成图像

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /generation/image-to-image`

根据参考图像生成或编辑图像。支持编辑、风格迁移和多图融合。

## Request Parameters

### model

- **Type:** string
- **Required:** 可选
- **Default:** `seedream_v5`

图像编辑模型。
- `seedream_v5` — 最强编辑、风格迁移与多图融合能力。
- `banana` — 快速编辑。
- `banana_pro` — 更高质量编辑。
- `banana2` — 最新快速编辑。
- `chat_image_1` — 基础图像编辑。**2026-10-23 下线。**
- `chat_image_1.5` — 更高质量编辑。**2026-12-01 下线。**
- `chat_image_2` — 最新，质量最佳编辑。
- `chat_image_2.5_flare` — 2.5 系列速度档，与 sunburst 同等成本下明显更快。
- `chat_image_2.5_sunburst` — 2.5 系列精修档，对未指定修改的部分保持得最接近原图。

### input

- **Type:** string
- **Required:** 必选

主要参考图像。接受公开 URL、`file_token` 或 `task_id`。**以上三种方式任选其一**，不可同时传入多种类型。



- Formats: `jpeg`, `png` (recommended); `webp` is rejected on some provider routes
- Max file size: **20 MB**
- Max total pixels: **6000 × 6000 = 36 MP**
- Min width/height: 14 px
- Aspect ratio (W/H): **[1/3, 3]**
- URL images must be publicly accessible. Private files require `/v3/files` first.

### inputs

- **Type:** string[]
- **Required:** 可选

多张参考图像。每张图像的格式与 `input` 相同。


- 最多：**4** 张（seedream），**10** 张（banana），**16** 张（chat_image）
- 引用方式：`image[1]`、`image[2]` 等。

### prompt

- **Type:** string
- **Required:** 条件必填

编辑指令。**未指定模板时必填。**
### size

- **Type:** string
- **Required:** 可选
- **Default:** `2048x2048`

输出图像尺寸。可传语义关键字（如 2K / 4K）或精确像素（如 2048x2048）；不同模型支持的取值不同，见下方分模型。
### quality

- **Type:** string
- **Required:** 可选
- **Default:** `low`

渲染质量档位。仅 `chat_image_2`、`chat_image_2.5_flare`、`chat_image_2.5_sunburst` 支持该参数，其它模型传入会直接报错。


- `chat_image_2` — `low`、`medium`、`high`。
- `chat_image_2.5_flare` / `chat_image_2.5_sunburst` — `low`、`medium`、`high`、`xhigh`、`max`。
不传等同于 `low`。请注意这与 OpenAI 官方默认的 `auto` 不同，且本接口**不支持** `auto` —— 计价需要在请求前就确定档位。

`high`、`xhigh`、`max` 会消耗更多积分且耗时明显增加；`low` 与 `medium` 按基础价计费。详见定价页。



### background

- **Type:** string
- **Required:** 可选

背景处理方式。仅 `chat_image_2.5_flare` 与 `chat_image_2.5_sunburst` 支持，取值为 `auto`、`opaque`、`transparent` 之一。

不传则由模型自行决定。其它模型传入会被忽略而非报错，请求照常成功，但背景仍由模型决定。

`transparent` 必须搭配 `output_format=png`。JPEG 不支持 alpha 通道，两者同时传入会直接报错，而不是悄悄把透明背景压平。


### aspect_ratio

- **Type:** string
- **Required:** 可选
- **Default:** `1:1`

输出宽高比。不传时默认 `1:1`（仅 banana 系列；当 `size` 与 `aspect_ratio` 均未传时由 gateway 填充）。
- `banana` / `banana_pro`：`1:1`、`2:3`、`3:2`、`3:4`、`4:3`、`4:5`、`5:4`、`9:16`、`16:9`、`21:9`。
- `banana2` 额外支持 `1:8`、`1:4`、`4:1`、`8:1`。
仅 **banana** 系列支持此字段；seedream / chat_image 按 `size` 出图，请改用 `size` 参数。

### template

- **Type:** string
- **Required:** 可选

编辑模板。设置后 `prompt` 变为可选。
- `t_pose`：转换为 T-pose。
- `character_completion`：补全不完整的角色。
- `3d_enhance`：增强以用于 3D 生成。
- `variants`：生成设计变体。
- `figure`：生成全身人物。

### output_format

- **Type:** string
- **Required:** 可选
- **Default:** `png`

输出图像格式。
- `png`：无损，支持透明度。
- `jpeg`：文件体积更小，不支持透明度。


## Request Example

### 单图示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/image-to-image \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "https://example.com/reference.png",
  "prompt": "Change the silver outfit into transparent glass.",
  "model": "seedream_v5",
  "size": "2K"
}'
```

### 多图示例

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/generation/image-to-image \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "inputs": [
    "https://example.com/photo1.png",
    "https://example.com/photo2.png"
  ],
  "prompt": "Use character from image[1] and outfit from image[2].",
  "model": "seedream_v5"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "image_to_image",
    "status": "success",
    "progress": 100,
    "output": {
      "generated_image_url": "https://cdn.tripo3d.ai/output/image.png"
    },
    "credits_consumed": 20.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:00:08Z"
  }
}
```
