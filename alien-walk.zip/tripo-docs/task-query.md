# 任务查询

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `GET /tasks/{task_id}`

通过任务 ID 查询单个异步任务的状态和输出。所有生成和处理端点都会返回可用于此处查询的 task_id。

## Request Parameters

### task_id

- **Type:** string
- **Required:** 必选

唯一任务标识符，作为路径参数传入。以 task_ 开头。

## Response Fields

### task_id

- **Type:** string
- **Required:** 必选

唯一任务标识符。
### type

- **Type:** string
- **Required:** 必选

任务类型（如 text_to_model、rig、convert）。
### status

- **Type:** string
- **Required:** 必选

任务状态。
- `queued`：排队等待中。
- `running`：处理中。
- `success`：已成功完成。
- `failed`：失败并报错。
- `cancelled`：已被用户取消。

### progress

- **Type:** integer
- **Required:** 必选

0–100。
### error_code

- **Type:** integer
- **Required:** 可选

status=failed 时返回。标准化错误码，标识失败原因。
### error_message

- **Type:** string
- **Required:** 可选

status=failed 且存在 error_code 时返回。对应错误码的相关描述。
### output

- **Type:** object
- **Required:** 可选

仅在 `status=success` 时填充。包含 `model_url`、`rendered_image_url` 等。
### credits_consumed

- **Type:** number
- **Required:** 可选

消耗的额度。最多两位小数的数值（例如 48.00）。
### created_at

- **Type:** string
- **Required:** 必选

ISO 8601 创建时间。
### completed_at

- **Type:** string
- **Required:** 可选

ISO 8601 完成时间。

## Request Example

### 查询任务

```
curl -s \
  -H "Authorization: Bearer YOUR_API_KEY" \
  https://openapi.tripo3d.com/v3/tasks/task_abc123
```


## Response Example

### 任务详情

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123",
    "type": "text_to_model",
    "status": "success",
    "progress": 100,
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/model_pbr.glb",
      "rendered_image_url": "https://cdn.tripo3d.ai/output/preview.png"
    },
    "credits_consumed": 100.00,
    "created_at": "2026-04-28T12:00:00Z",
    "completed_at": "2026-04-28T12:01:30Z"
  }
}
```
