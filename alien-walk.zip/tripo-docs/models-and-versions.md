# 模型与版本

## 3D 生成模型

用于 `POST /v3/generation/text-to-model` 和 `POST /v3/generation/image-to-model` 等 3D 生成端点的 `model` 参数。

| 模型标识 | 说明 | 推荐场景 |
| :-: | :-: | :-: |
| `tripo-p1` | 低面数表现更好 | 游戏管线制作 / UGC 生成式玩法 / 移动端设备 3D 资产生成 |
| `tripo-v3.1` | 最新高精度模型版本（默认） | 3A 作品制作管线 / 3D 打印柔性制造 |
| `tripo-v3.0` | 上一代稳定版 | 兼容性需求 |
| `tripo-v2.5` | 旧版 | 历史项目兼容 |

## 图像生成模型

用于 `POST /v3/generation/text-to-image` 和 `POST /v3/generation/image-to-image` 端点的 `model` 参数。

| 模型标识 | 提供商 | 特点 |
| :-: | :-: | :-: |
| `seedream_v4` | ByteDance | 默认模型，效果均衡 |
| `seedream_v5` | ByteDance | 最新版，质量提升 |
| `banana` | ByteDance | 快速生成 |
| `banana_pro` | ByteDance | 高质量生成 |
| `banana2` | ByteDance | 最新快速版本 |
| `chat_image_1` | OpenAI | GPT 图像生成（2026-10-23 下线） |
| `chat_image_1.5` | OpenAI | GPT 更高质量（2026-12-01 下线） |
| `chat_image_2` | OpenAI | GPT 最新 |

| `chat_image_2.5_flare` | OpenAI | GPT 2.5 速度档 |
| `chat_image_2.5_sunburst` | OpenAI | GPT 2.5 精修档 |
## 版本选择建议

- **新项目**：使用默认版本（3D 用 `tripo-v3.1`，图像用 `seedream_v4`），享受最佳的质量与稳定性平衡
- **生产环境**：锁定具体版本号，避免模型更新导致输出不一致
- **追求最高质量**：3D 使用 `tripo-p1`，图像根据场景选择 `banana_pro` 或 `seedream_v5`
- **低面数 / 游戏资产**：3D 使用 `tripo-p1`，拓扑更干净，面数控制更精确

## 请求示例

```bash
# 使用默认模型
curl -X POST https://openapi.tripo3d.com/v3/generation/text-to-model \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {api_key}" \
  -d '{"prompt": "a robot"}'

# 指定旗舰模型
curl -X POST https://openapi.tripo3d.com/v3/generation/text-to-model \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {api_key}" \
  -d '{"prompt": "a robot", "model": "tripo-p1"}'

# 使用图像生成模型
curl -X POST https://openapi.tripo3d.com/v3/generation/text-to-image \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {api_key}" \
  -d '{"prompt": "a futuristic city", "model": "seedream-v5"}'
```
