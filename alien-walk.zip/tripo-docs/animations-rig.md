# 自动绑骨

**Base URL:** `https://openapi.tripo3d.com/v3`

**Endpoint:** `POST /animations/rig`

自动为 3D 模型添加骨骼绑定。请先运行可绑骨检查以验证兼容性。

## Request Parameters

### input

- **Type:** string
- **Required:** 必选

模型来源。接受 task_id 或 file_token。 接受以下输入类型：**以下三种方式任选其一**，不可同时传入多种类型。

- task_id：此前 3D 生成任务（`text_to_model`、`image_to_model` 或 `multiview_to_model`）返回的任务 ID。系统会自动使用该任务的 3D 模型输出。
示例： `task_abc123`
- file_token：先通过文件上传 API上传 3D 模型文件，然后传入返回的 token。
示例： `file_abc123`
- URL：可公开访问的 3D 模型文件直链。
示例： `https://example.com/model.glb`



- 支持格式：`GLB`、`GLTF`、`FBX`、`OBJ`、`STL`
- 最大文件大小：**150 MB**

### model

- **Type:** string
- **Required:** 可选
- **Default:** `v1.0-20240301`

绑骨模型版本。
- `v1.0-20240301`：仅适用于（且推荐用于）双足类人型绑骨。支持 90+ 预设动画。
- `v2.5-20260210`：适用于非类人型的动物绑骨（四足、六足、八足、蛇形、水生、鸟类）。

### rig_type

- **Type:** string
- **Required:** 可选
- **Default:** `biped`

骨骼类型。建议先调用 `rig-check`。
- `biped`：双足人形。
- `quadruped`：四足动物。
- `hexapod`：六足生物。
- `octopod`：八足生物。
- `avian`：鸟类/有翼生物。
- `serpentine`：蛇形生物。
- `aquatic`：鱼类/水生生物。

### spec

- **Type:** string
- **Required:** 可选
- **Default:** `tripo`

绑骨规范。
- `tripo`：Tripo 原生骨骼命名。
- `mixamo`：兼容 Mixamo 的骨骼命名。

### out_format

- **Type:** string
- **Required:** 可选
- **Default:** `glb`

输出格式。
- `glb`：二进制 glTF，适用于 Web。
- `fbx`：FBX，适用于 DCC 工具和游戏引擎。


## Request Example

### 自动绑骨

```bash
curl --request POST \
  --url https://openapi.tripo3d.com/v3/animations/rig \
  --header 'Authorization: Bearer <token>' \
  --header 'Content-Type: application/json' \
  --data '{
  "input": "task_abc123",
  "model": "v2.5-20260210",
  "rig_type": "biped",
  "spec": "mixamo",
  "out_format": "glb"
}'
```


## Response Example

### 创建任务

```json
{
  "code": 0,
  "data": {
    "task_id": "task_abc123"
  }
}
```

### 任务结果

```json
{
  "code": 0,
  "data": {
    "task_id": "task_def456",
    "status": "success",
    "output": {
      "model_url": "https://cdn.tripo3d.ai/output/rigged.glb"
    },
    "credits_consumed": 30.00
  }
}
```
