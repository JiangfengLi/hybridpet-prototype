#!/usr/bin/env bash
# alien-walk 无头截图。用法： bash _shots/shoot.sh
# 依赖：本机 Chrome；游戏服务器需已在 8766 运行（E:/anaconda/python.exe serve.py）
CHROME="/c/Program Files/Google/Chrome/Application/chrome.exe"
SHOT="C:/Users/26335/WorkBuddy/2026-09-22-09-31-42/alien-walk/_shots"
BASE="http://127.0.0.1:8766/"

# 名称|查询串
#   autostart=1  跳过开场、不请求指针锁        intro=0  立刻隐藏开场层（避免过渡竞态）
#   hud=0        隐藏 HUD                      still=1  冻结模拟（取景必需）
#   pos=x,z      站位                          watch=x,z[,y]  镜头自动对准
JOBS=(
  "y4_ray|autostart=1&intro=0&hud=0&still=1&pos=-38.1,-31.9&watch=-43,-36.8,10.8"
)

for item in "${JOBS[@]}"; do
  name="${item%%|*}"
  q="${item#*|}"
  rm -f "$SHOT/$name.png"
  "$CHROME" --headless=new --disable-gpu --use-angle=swiftshader \
    --enable-unsafe-swiftshader --hide-scrollbars --disable-dev-shm-usage \
    --window-size=960,540 --virtual-time-budget=12000 \
    --screenshot="$SHOT/$name.png" "${BASE}?${q}" >/dev/null 2>&1
  sz=$(stat -c%s "$SHOT/$name.png" 2>/dev/null || echo 0)
  printf "%-14s %8s bytes\n" "$name" "$sz"
done
echo "DONE"
