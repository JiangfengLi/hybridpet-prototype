/**
 * 打包成单文件版： alien-walk-standalone.html
 *
 * 为什么需要：正常版要用 http:// 起服务器（file:// 下浏览器拒绝加载 ES module）。
 * 这里把 three.js 的两个文件直接内联进 HTML，再用 **blob URL** 导入，
 * 于是双击打开就能跑，不依赖任何服务器、也不依赖网络。
 *
 * 用法： node build-standalone.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';

const HERE = path.dirname(url.fileURLToPath(import.meta.url));
const SRC = path.join(HERE, 'index.html');
const OUT = path.join(HERE, 'alien-walk-standalone.html');

/* ---------- 1. 读源文件 ---------- */
const html = fs.readFileSync(SRC, 'utf8');
const coreSrc = fs.readFileSync(path.join(HERE, 'vendor', 'three.core.min.js'), 'utf8');
const modSrc = fs.readFileSync(path.join(HERE, 'vendor', 'three.module.min.js'), 'utf8');

/* 依赖闭包自检：min 构建会 import 兄弟文件，漏了就白屏 */
const siblings = [...modSrc.matchAll(/from\s*["'](\.[^"']*)["']/g)].map(m => m[1]);
if (siblings.length === 0) {
  console.warn('警告：three.module.min.js 没有相对依赖 —— 可能本来就是自包含的，' +
               '打包脚本的 import 重写部分可以省掉。');
}
console.log('three.module.min.js 的相对依赖：' + (siblings.join(', ') || '（无）'));

/* ---------- 2. 替换游戏里的 three.js 引导段 ---------- */
const BOOT = `let THREE;
try {
  THREE = await import('./vendor/three.module.min.js');
} catch (errLocal) {
  console.warn('[alien-walk] 本地 three.js 加载失败，尝试 CDN：', errLocal);
  try {
    THREE = await import('https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.min.js');
  } catch (errCdn) {
    window.__showFatal('<b>three.js 加载失败</b><br>本地副本与 CDN 均不可用。' +
      '<br><small>' + String((errCdn && errCdn.message) || errCdn) + '</small>');
    throw errCdn;
  }
}`;

const BOOT_STANDALONE = `/* 单文件版：three.js 已内联在下面的 <script id="__three_*"> 里，
   通过 blob URL 导入 —— 于是 file:// 双击打开也能跑，不依赖服务器。 */
const __srcOf = id => document.getElementById(id).textContent;
let THREE;
try {
  const coreUrl = URL.createObjectURL(new Blob([__srcOf('__three_core')], { type: 'text/javascript' }));
  const modText = __srcOf('__three_module')
    .replace(/from\\s*["']\\.\\/three\\.core\\.min\\.js["']/g, 'from "' + coreUrl + '"');
  const modUrl = URL.createObjectURL(new Blob([modText], { type: 'text/javascript' }));
  THREE = await import(modUrl);
  URL.revokeObjectURL(coreUrl);
} catch (errBlob) {
  window.__showFatal('<b>three.js 内联导入失败</b><br>这个浏览器可能禁止从 blob: 导入模块。' +
    '<br>请改用正常版：双击 <code>start.bat</code>，或 ' +
    '<code>python serve.py</code> 后访问 <code>http://127.0.0.1:8766/</code>' +
    '<br><small>' + String((errBlob && errBlob.message) || errBlob) + '</small>');
  throw errBlob;
}`;

let out = html;
let hit = 0;
for (const [a, b] of [[BOOT, BOOT_STANDALONE],
                      [BOOT.replace(/\n/g, '\r\n'), BOOT_STANDALONE.replace(/\n/g, '\r\n')]]) {
  if (out.includes(a)) { out = out.replace(a, b); hit++; break; }
}
if (!hit) {
  console.error('失败：在 index.html 里找不到 three.js 引导段 —— 源码变了，请更新本脚本的 BOOT 常量。');
  process.exit(1);
}
console.log('已替换 three.js 引导段');

/* ---------- 3. 把源码原样内联 ----------
   坑：一开始我按 JSON 习惯把 "</" 转义成 "<\/" 再塞进 <script type="text/plain">。
   但 text/plain 块里没有转义规则，读出来时反斜杠**不会消失** →
   源码被改成 "<\/" → 模块抛 "Invalid or unexpected token" → 白屏。
   事实核查：three.js 两个 min 文件里 "</" 出现 **0 次**，根本不需要转义。
   唯一必须避免的是 "</script"，因为 HTML 解析器会在那里截断脚本元素。
   所以：断言不存在 "</script"，然后**原样**内联。 */
function inline(id, src) {
  if (/<\/script/i.test(src)) {
    console.error('失败：' + id + ' 的源码里含 "</script"，会截断 HTML 脚本元素。'
      + '需要改成 base64 或按需转义，请更新构建脚本。');
    process.exit(1);
  }
  return '<script id="' + id + '" type="text/plain">' + src + '</script>\n';
}

const dataBlock = inline('__three_core', coreSrc) + inline('__three_module', modSrc);
console.log('已内联 three.core/three.module（原样，未做转义）');

/* 放在第一个 <script> 之前，保证引导段运行时元素已存在 */
const firstScript = out.indexOf('<script');
if (firstScript < 0) { console.error('失败：找不到 <script> 标签'); process.exit(1); }
out = out.slice(0, firstScript) + dataBlock + out.slice(firstScript);

/* ---------- 4. 标题里注明这是单文件版 ---------- */
out = out.replace('<title>', '<title>[单文件版] ');

fs.writeFileSync(OUT, out, 'utf8');

/* ---------- 5. 自检 ---------- */
const bytes = fs.statSync(OUT).size;
const rawClose = (out.match(/<\/script>/gi) || []).length;
const expectClose = (html.match(/<\/script>/gi) || []).length + 2;   // 多出的两个是内联数据块
console.log('');
console.log('输出：' + path.relative(HERE, OUT) + '  ' + (bytes / 1024).toFixed(0) + ' KB');
console.log('  </script> 出现次数 = ' + rawClose + '（期望 ' + expectClose + '）' +
            (rawClose === expectClose ? ' ✓ 数据块未被提前截断' : ' ✗ 有内容泄漏到标签外'));

/* 内联源码必须与磁盘上的字节完全一致 —— 上一次就是这里出的问题 */
const reCore = out.match(/<script id="__three_core" type="text\/plain">([\s\S]*?)<\/script>/);
const reMod = out.match(/<script id="__three_module" type="text\/plain">([\s\S]*?)<\/script>/);
const same = (a, b) => a !== null && a[1] === b;
console.log('  内联 core 与磁盘一致: ' + (same(reCore, coreSrc) ? '✓' : '✗'));
console.log('  内联 module 与磁盘一致: ' + (same(reMod, modSrc) ? '✓' : '✗'));
if (!same(reCore, coreSrc) || !same(reMod, modSrc)) {
  console.error('失败：内联内容与源文件不一致，file:// 下会语法报错。');
  process.exit(1);
}
