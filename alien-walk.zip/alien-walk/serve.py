#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
KEPLER-9c 本地预览服务器。

为什么需要它：Windows 上 `python -m http.server` 会从注册表取 MIME，
而 .js 常被映射成 text/plain —— 浏览器会拒绝加载 ES module：
  "Failed to load module script: Expected a JavaScript module script
   but the server responded with a MIME type of 'text/plain'"
这里强制修正 MIME，并禁用缓存，改文件后刷新即可生效。

用法：
    python serve.py            # 默认 http://127.0.0.1:8765
    python serve.py 9000
"""
import functools
import http.server
import os
import socketserver
import sys

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
ROOT = os.path.dirname(os.path.abspath(__file__))
HOST = "127.0.0.1"


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        ".js": "text/javascript",
        ".mjs": "text/javascript",
        ".jsx": "text/javascript",
        ".json": "application/json",
        ".wasm": "application/wasm",
        ".glb": "model/gltf-binary",
        ".gltf": "model/gltf+json",
        ".hdr": "application/octet-stream",
        ".webp": "image/webp",
        ".svg": "image/svg+xml",
    }

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, must-revalidate")
        # 允许后续接第三方 CDN 资产
        self.send_header("Access-Control-Allow-Origin", "*")
        super().end_headers()

    def log_message(self, fmt, *args):
        sys.stderr.write("  %s\n" % (fmt % args))


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    handler = functools.partial(Handler, directory=ROOT)
    with Server((HOST, PORT), handler) as httpd:
        print("KEPLER-9c  →  http://%s:%d/" % (HOST, PORT))
        print("根目录: %s" % ROOT)
        print("Ctrl+C 停止")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n已停止")
