/**
 * 集成测试（无需浏览器）：用真实 three.js 跑完整游戏模块。
 * 覆盖：vendor 依赖闭包、场景构建、userData 完整性、主循环长时间稳定性、
 * 玩家移动/跳跃、观测与采集、完成条件。
 *
 * 输入与 UI 接线（keydown 监听器、指针锁降级、拖拽视角）见 test/input.mjs。
 * 用法： node test/integration.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { runGame, DRIVER_HEAD, DRIVER_FOOTER, ROOT } from './harness.mjs';

/* ============================================================
   0. vendor 依赖闭包（静态检查，在 Node 里做，不属于游戏模块）
   只下载主文件会漏掉拆包出来的兄弟文件 → 本地静默加载失败、回退 CDN
   ============================================================ */
let outerFails = 0;
const print = (c, m) => { console.log((c ? 'ok   ' : 'FAIL ') + m); if (!c) outerFails++; };
console.log('\n=== 0. vendor 依赖闭包 ===');

function vendorClosure(entry) {
  const seen = new Set(), missing = [];
  (function walk(f) {
    if (seen.has(f)) return;
    seen.add(f);
    for (const m of fs.readFileSync(f, 'utf8').matchAll(/from\s*["'](\.[^"']*)["']/g)) {
      const t = path.resolve(path.dirname(f), m[1]);
      if (!fs.existsSync(t)) missing.push(path.relative(ROOT, t));
      else walk(t);
    }
  })(entry);
  return { files: [...seen], missing };
}

const entryFile = path.join(ROOT, 'vendor', 'three.module.min.js');
print(fs.existsSync(entryFile), 'vendor/three.module.min.js 存在');
if (fs.existsSync(entryFile)) {
  const { files, missing } = vendorClosure(entryFile);
  console.log('  依赖文件: ' + files.map(f => path.relative(ROOT, f)).join(', '));
  console.log('  合计: ' + (files.reduce((a, f) => a + fs.statSync(f).size, 0) / 1024).toFixed(0) + ' KB');
  print(missing.length === 0, '本地依赖闭包完整（缺失: ' + (missing.join(', ') || '无') + '）');
}
const htmlSrc = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
for (const m of htmlSrc.matchAll(/import\(\s*['"](\.\/[^'"]+)['"]\s*\)/g)) {
  print(fs.existsSync(path.resolve(ROOT, m[1])), '网页引用的本地资源存在: ' + m[1]);
}

/* ============================================================
   1+. 驱动游戏模块
   ============================================================ */
const DRIVER = `
${DRIVER_HEAD}

sec('1. 场景构建');
let buildErr = null;
const meshCount = (() => { let n = 0; try { scene.traverse(o => { if (o.isMesh || o.isPoints || o.isSprite) n++; }); } catch (e) { buildErr = e; } return n; })();
ok(!buildErr, '场景可遍历' + (buildErr ? '：' + buildErr.message : ''));
console.log('  场景直属子节点 = ' + scene.children.length + ' | 可渲染对象 = ' + meshCount);
ok(meshCount > 150, '可渲染对象 >150（实际 ' + meshCount + '）');
ok(animals.length === 25, '动物 25 只（实际 ' + animals.length + '）');
ok(signalObjs.length === 12, '信号源 12 个（实际 ' + signalObjs.length + '）');
ok(terrain.geometry.attributes.position.count > 10000, '地形网格已生成');
ok(scene.fog && scene.fog.density > 0, '雾已设置');
ok(!!globalThis.__loop, '主循环已注册');

sec('2. 动物 userData 完整性');
const need = { walk: ['legs'], hop: ['hind', 'body'] };
const missing = [];
for (const a of animals) {
  const ud = a.g.userData;
  if (!ud.kind) missing.push('kind');
  if (ud.kind === 'land') {
    if (!ud.gait) missing.push('gait');
    (need[ud.gait] || []).forEach(k => { if (!ud[k]) missing.push(ud.gait + '.' + k); });
    if (typeof ud.speed !== 'number') missing.push(ud.gait + '.speed');
  } else {
    if (!ud.wings || ud.wings.length !== 2) missing.push(ud.kind + '.wings');
    if (typeof ud.radius !== 'number' || !(ud.radius > 0)) missing.push(ud.kind + '.radius');
    if (typeof ud.alt !== 'number') missing.push(ud.kind + '.alt');
  }
}
ok(missing.length === 0, 'userData 字段齐备（缺失: ' + (missing.join(', ') || '无') + '）');

/* 边界：四肢/翼不能整段藏进身体包围盒 —— 这是低模动物最容易犯的错 */
const bb = o => { o.geometry.computeBoundingBox(); return o.geometry.boundingBox.clone().applyMatrix4(o.matrixWorld); };
let hiddenLegs = [];
for (const a of animals) {
  const ud = a.g.userData;
  if (ud.kind !== 'land') continue;
  if (ud.gait === 'walk') {
    for (const L of ud.legs) {
      const lb = bb(L.pivot.children[0]);
      if (lb.max.y < 0.06) hiddenLegs.push(a.species.key + ' 腿没踩到地(maxY=' + lb.max.y.toFixed(2) + ')');
    }
  } else if (ud.gait === 'hop') {
    for (const p of ud.hind) {
      const foot = bb(p.children[1]);
      if (foot.max.y < 0.06) hiddenLegs.push('hopper 脚悬空(maxY=' + foot.max.y.toFixed(2) + ')');
    }
  }
}
ok(hiddenLegs.length === 0, '所有陆生动物的脚都踩到地面（' + (hiddenLegs.join('; ') || '无问题') + '）');

sec('3. 主循环 900 帧（15 秒）');
started = true;
let loopErr = null;
const T0 = Date.now();
try { for (let i = 0; i < 900; i++) loop(); } catch (e) { loopErr = e; }
ok(!loopErr, '主循环无异常' + (loopErr ? '：' + loopErr.message : ''));
if (loopErr) console.log(loopErr.stack.split('\\n').slice(0, 5).join('\\n'));
const ms = Date.now() - T0;
console.log('  900 帧逻辑耗时 ' + ms + ' ms（' + (ms / 900).toFixed(2) + ' ms/帧，纯 CPU）');
ok((globalThis.__renders || 0) >= 900, 'render 被调用 ' + (globalThis.__renders || 0) + ' 次');

sec('4. 15 秒后的世界状态');
const land = animals.filter(a => a.g.userData.kind === 'land');
const flyers = animals.filter(a => a.g.userData.kind !== 'land');
const maxR = Math.max(...land.map(a => Math.hypot(a.x, a.z)));
console.log('  陆地动物离原点最远 = ' + maxR.toFixed(1) + '（边界 ' + (WALK_R * 0.96).toFixed(1) + '）');
ok(maxR <= WALK_R * 0.96 + 0.6, '无动物越界');
ok(animals.every(a => Number.isFinite(a.x) && Number.isFinite(a.z) && Number.isFinite(a.y)), '动物坐标始终有限');
ok(animals.every(a => Number.isFinite(a.g.position.x) && Number.isFinite(a.g.position.y) && Number.isFinite(a.g.position.z)), '网格 position 有限');
ok(animals.every(a => Number.isFinite(a.g.rotation.y)), '朝向有限');
const hover = flyers.map(a => a.y - sampleHeight(a.x, a.z));
console.log('  飞行者离地 ' + Math.min(...hover).toFixed(1) + ' ~ ' + Math.max(...hover).toFixed(1) + ' m');
ok(flyers.every((a, i) => hover[i] > 2), '飞行者离地 >2m');
const walkers = land.filter(a => a.g.userData.legs);
ok(walkers.every(a => Math.abs(a.g.userData.legs[0].pivot.rotation.x) > 0.005), '所有步行兽的腿都在摆动');
ok(camera.position.y > sampleHeight(player.x, player.z) - 1, '相机在地表之上');

sec('5. 观测动物（按 E）');
/* 必须挑一只远离信号源的 —— 按 E 时信号源优先是正确行为 */
const landTarget = land.find(a => signalObjs.every(s => Math.hypot(s.pos.x - a.x, s.pos.z - a.z) > 9));
ok(!!landTarget, '存在远离信号源的动物可供观测');
player.x = landTarget.x + 1.5; player.z = landTarget.z + 1.5;
state.near = null;
loop();
ok(state.nearAnimal === landTarget, '识别到目标动物（nearAnimal=' + (state.nearAnimal ? state.nearAnimal.species.key : 'null') + '）');
tryScan();
ok(!!speciesSeen[landTarget.species.key], '物种已记录：' + landTarget.species.name);
ok(el('specCount').textContent === '1', 'HUD 物种计数 = 1（实际 ' + JSON.stringify(el('specCount').textContent) + '）');
tryScan();
ok(el('specCount').textContent === '1', '重复观测不重复计数');

sec('6. 采集信号源（按 E）');
const sig = signalObjs.find(s => !s.scanned);
player.x = sig.pos.x + 2; player.z = sig.pos.z + 2;
state.o2 = 40;
const o2Before = state.o2;
loop(); tryScan();
ok(sig.scanned === true, '信号源已标记');
ok(state.scanned === 1, 'state.scanned = 1（实际 ' + state.scanned + '）');
ok(state.o2 > o2Before, '采集补充氧气（' + o2Before.toFixed(1) + ' → ' + state.o2.toFixed(1) + '）');

sec('7. 完成条件');
try { for (const s of signalObjs) { if (!s.scanned) { state.near = s; tryScan(); } } } catch (e) { loopErr = e; }
ok(!loopErr, '连续采集无异常');
ok(state.scanned === 12, '12 个信号源全部完成（实际 ' + state.scanned + '）');
ok(state.complete === true, 'state.complete 已置位');
for (const a of animals) { state.near = null; state.nearAnimal = a; tryScan(); }
ok(Object.keys(speciesSeen).length === SPECIES_LIST.length, '5 个物种全部记录（实际 ' + Object.keys(speciesSeen).length + '）');

sec('8. 长时稳定性（再 1800 帧）');
let e3 = null;
try { for (let i = 0; i < 1800; i++) loop(); } catch (e) { e3 = e; }
ok(!e3, '1800 帧无异常' + (e3 ? '：' + e3.message : ''));
ok(animals.every(a => Number.isFinite(a.x) && Number.isFinite(a.y) && Number.isFinite(a.z)), '长时运行后动物坐标仍有限');
ok(Number.isFinite(player.x) && Number.isFinite(player.y), '玩家坐标有限');
ok(state.o2 >= 0, '氧气不为负（' + state.o2.toFixed(1) + '）');

${DRIVER_FOOTER}
`;

let failed = outerFails > 0;
try {
  await runGame(DRIVER);
} catch (err) {
  console.log('\n运行失败：' + (err && err.message));
  failed = true;
}
console.log(failed ? '\n>>> 集成测试有失败 <<<' : '\n>>> 集成测试全部通过 <<<');
process.exit(failed ? 1 : 0);
