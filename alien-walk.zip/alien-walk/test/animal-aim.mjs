/**
 * 打印所有动物的精确出生坐标，并给出取景建议（配合 ?still=1 用）。
 * 用法： node test/animal-aim.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';
import * as THREE from '../vendor/three.module.min.js';

const HERE = path.dirname(url.fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');

/* ---------- 最小 DOM 桩 ---------- */
const ctxStub = {
  fillStyle: '', globalAlpha: 1,
  createLinearGradient: () => ({ addColorStop() {} }),
  createRadialGradient: () => ({ addColorStop() {} }),
  fillRect() {}, beginPath() {}, ellipse() {}, fill() {}, save() {}, restore() {},
};
const EL = Object.create(null);
function fakeEl(id) {
  if (EL[id]) return EL[id];
  return (EL[id] = {
    id, classList: { add() {}, remove() {}, toggle() {} },
    style: {}, textContent: '', innerHTML: '', width: 0, height: 0,
    firstElementChild: { style: {} },
    appendChild() {}, addEventListener() {}, requestPointerLock() {},
    querySelector() { return { textContent: '', style: {} }; },
    getContext() { return ctxStub; },
  });
}
globalThis.document = {
  getElementById: fakeEl,
  querySelector: s => fakeEl('sel:' + s),
  createElement: () => fakeEl('new'),
  addEventListener() {}, hidden: false, pointerLockElement: null, exitPointerLock() {},
};
globalThis.window = globalThis;
globalThis.innerWidth = 960;
globalThis.innerHeight = 540;
globalThis.devicePixelRatio = 1;
globalThis.location = { search: '', href: 'http://127.0.0.1:8766/' };
globalThis.addEventListener = () => {};
globalThis.AudioContext = undefined;
THREE.Clock.prototype.getDelta = () => 1 / 60;

/* ---------- 抽取被测模块 ---------- */
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const js = html.match(/<script type="module">([\s\S]*?)<\/script>/)[1];
let body = js.slice(js.lastIndexOf('/* ====', js.indexOf('0. 世界参数')));
body = body.replace(
  "const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });",
  "const renderer = { shadowMap:{}, setPixelRatio(){}, setSize(){}, render(){}, setAnimationLoop(){}, outputColorSpace:null, toneMapping:null, toneMappingExposure:1 };"
);

const DRIVER = `
const bySp = {};
for (const a of animals) {
  const k = a.g.userData.kind === 'land' ? a.species.key : a.g.userData.kind;
  (bySp[k] = bySp[k] || []).push({ x: +a.x.toFixed(1), z: +a.z.toFixed(1), y: +a.y.toFixed(1), s: +a.g.scale.x.toFixed(2) });
}
for (const k of Object.keys(bySp)) console.log(k.padEnd(9), JSON.stringify(bySp[k]));

console.log('');
console.log('取景建议（站到目标附近，用 watch 自动对准镜头）:');
const dist = { grazer: 7, scuttler: 5, hopper: 6, ray: 7, bird: 5 };
for (const k of Object.keys(bySp)) {
  const a = bySp[k][0];
  const d = (dist[k] || 7) * 0.7071;
  const wx = k === 'ray' || k === 'bird' ? a.x : a.x;
  console.log('  ' + k.padEnd(9) +
    ' pos=' + (a.x + d).toFixed(1) + ',' + (a.z + d).toFixed(1) +
    '&watch=' + a.x + ',' + a.z + (k === 'ray' || k === 'bird' ? ',' + a.y : ''));
}
`;

const out = path.join(HERE, '.tmp-aim.mjs');
/* 临时文件是独立 module，需要自己 import three */
fs.writeFileSync(out, "import * as THREE from '../vendor/three.module.min.js';\n" + body + DRIVER, 'utf8');
try {
  await import(url.pathToFileURL(out).href);
} finally {
  try { fs.unlinkSync(out); } catch (e) {}
}
