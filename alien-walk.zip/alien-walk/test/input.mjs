/**
 * 输入与 UI 接线测试。
 *
 * 为什么单独一份：integration.mjs 是**直接改 keys 对象**来驱动机器人的，
 * 所以 keydown/keyup 监听器、指针锁失败降级、拖拽视角、ESC 暂停、resize/visibility
 * 这些"用户真正碰到的代码"从来没被执行过。这里专门测接线本身。
 *
 * 用法： node test/input.mjs
 */
import { runGame, DRIVER_HEAD, DRIVER_FOOTER } from './harness.mjs';

const DRIVER = `
${DRIVER_HEAD}

/* ============================================================
   1. 开场按钮 → 进入世界
   ============================================================ */
sec('1. 点「开始探索」');
ok(el('intro').classList.contains('hide') === false, '初始：开场层可见');
ok(el('hud').classList.contains('on') === false, '初始：HUD 隐藏');
const nBtn = fire('startBtn', 'click');
ok(nBtn === 1, '开始按钮挂了 1 个 click 监听器（实际 ' + nBtn + '）');
ok(el('intro').classList.contains('hide') === true, '开场层已隐藏');
ok(el('hud').classList.contains('on') === true, 'HUD 已显示');
ok(started === true, 'started = true');
ok(paused === false, 'paused = false');
ok(globalThis.__lockCalls >= 1, '已请求指针锁（调用 ' + globalThis.__lockCalls + ' 次）');

/* ============================================================
   2. 指针锁被拒 → 自动降级为拖拽视角（不许卡死）
   注意：失败是 Promise 拒绝，是异步的，必须等一轮宏任务
   ============================================================ */
sec('2. 指针锁被拒时的降级');
const seenHint = { warns: 0 };
const origWarn = console.warn;
await tick();
ok(dragLook === true, '已切换为拖拽兜底模式（dragLook=' + dragLook + '）');
ok(el('hint').classList.contains('on') === true, '显示了提示条');
ok(paused === false, '仍然可以行动（没有卡在暂停态）');
ok((el('hint').textContent || '').includes('拖动'), '提示文案提到了拖动：' + JSON.stringify(el('hint').textContent));
ok(globalThis.__lockCalls >= 2, '失败后重试过一次（共请求 ' + globalThis.__lockCalls + ' 次）');

/* ============================================================
   3. 键盘：W 前进 / 松手停下
   ============================================================ */
sec('3. 键盘移动（走真实 keydown 监听器）');
const x0 = player.x, z0 = player.z;
const nKey = fireKey('keydown', 'KeyW');
ok(nKey >= 1, 'keydown 挂了监听器（' + nKey + '）');
ok(keys['KeyW'] === true, 'keydown 把 keys.KeyW 置为 true');
for (let i = 0; i < 120; i++) loop();
const dW = Math.hypot(player.x - x0, player.z - z0);
console.log('  前进 2 秒位移 = ' + dW.toFixed(2) + ' m');
ok(dW > 5, '确实前进了（' + dW.toFixed(2) + ' m）');
releaseKey('KeyW');
ok(keys['KeyW'] === false, 'keyup 清掉 keys.KeyW');
const x1 = player.x, z1 = player.z;
for (let i = 0; i < 90; i++) loop();
const dStop = Math.hypot(player.x - x1, player.z - z1);
ok(dStop < 1.2, '松手后停下（惯性滑行 ' + dStop.toFixed(2) + ' m）');
ok(Math.abs(player.y - sampleHeight(player.x, player.z)) < 0.05, '全程贴地');

/* ============================================================
   4. 键盘：Shift 冲刺 / Space 跳跃
   ============================================================ */
sec('4. 冲刺与跳跃');
player.vx = player.vz = 0;
const sx0 = player.x, sz0 = player.z;
holdFrames('KeyW', 60);
const dWalk = Math.hypot(player.x - sx0, player.z - sz0);
player.vx = player.vz = 0;
const sx1 = player.x, sz1 = player.z;
pressKey('ShiftLeft'); holdFrames('KeyW', 60); releaseKey('ShiftLeft');
const dRun = Math.hypot(player.x - sx1, player.z - sz1);
console.log('  1 秒 走=' + dWalk.toFixed(2) + ' m  跑=' + dRun.toFixed(2) + ' m');
ok(dRun > dWalk * 1.25, 'Shift 确实加速（' + (dRun / dWalk).toFixed(2) + '×）');

pressKey('Space');
const airborne = [];
for (let i = 0; i < 40; i++) { loop(); airborne.push(player.y - sampleHeight(player.x, player.z)); }
releaseKey('Space');
const peak = Math.max(...airborne);
console.log('  跳跃峰值离地 = ' + peak.toFixed(2) + ' m');
ok(peak > 0.6, 'Space 能跳起来（峰值 ' + peak.toFixed(2) + ' m）');
for (let i = 0; i < 200; i++) loop();
ok(Math.abs(player.y - sampleHeight(player.x, player.z)) < 0.05, '最终落回地面');

/* ============================================================
   5. 键盘：E 交互 / M 静音
   ============================================================ */
sec('5. E 与 M');
const tgt = animals.find(a => a.species.key === 'grazer' &&
  signalObjs.every(s => Math.hypot(s.pos.x - a.x, s.pos.z - a.z) > 9));
player.x = tgt.x + 1.5; player.z = tgt.z + 1.5;
state.near = null;
loop();
ok(state.nearAnimal === tgt, '靠近后识别到可观测动物');
pressKey('KeyE');
ok(!!speciesSeen[tgt.species.key], '按 E 记录物种：' + tgt.species.name);
ok(el('specCount').textContent === '1', 'HUD 物种计数已更新（' + el('specCount').textContent + '）');
let mErr = null;
try { pressKey('KeyM'); } catch (e) { mErr = e; }
ok(!mErr, 'AudioContext 不可用时按 M 不报错' + (mErr ? '：' + mErr.message : ''));

/* ============================================================
   6. 拖拽视角（兜底模式下唯一能转镜头的方式）
   ============================================================ */
sec('6. 拖拽视角');
const yaw0 = player.yaw;
fire('app', 'mousedown');
const nMm = fireDoc('mousemove', { movementX: 100, movementY: 0 });
ok(nMm >= 1, 'document 挂了 mousemove 监听器（' + nMm + '）');
ok(Math.abs(player.yaw - yaw0) > 0.1, '按住左键拖动会转视角（Δyaw=' + (player.yaw - yaw0).toFixed(3) + '）');
fire('window', 'mouseup');
const yaw1 = player.yaw;
fireDoc('mousemove', { movementX: 100, movementY: 0 });
ok(Math.abs(player.yaw - yaw1) < 1e-9, '松开后鼠标移动不再转视角');
const pitchBefore = player.pitch;
fireDoc('mousemove', { movementX: 0, movementY: -10000 });
ok(player.pitch <= 1.4501, '俯仰被夹住（不会翻过头）：' + player.pitch.toFixed(3));
player.pitch = pitchBefore;

/* ============================================================
   7. Escape / visibilitychange / resize
   ============================================================ */
sec('7. 暂停与窗口事件');
pressKey('Escape');
ok(paused === false, '兜底模式下 Escape 是恢复而不是暂停（不会把自己锁死）');
const nVis = fireDoc('visibilitychange', {});
document.hidden = true;
fireDoc('visibilitychange', {});
ok(paused === true, '切到后台自动暂停');
ok(el('dim').classList.contains('on') === true, '显示「已暂停」遮罩');
document.hidden = false;
pressKey('Escape');
ok(paused === false, '回来后可以恢复');

const asp0 = camera.aspect;
globalThis.innerWidth = 800; globalThis.innerHeight = 1000;
fire('window', 'resize');
ok(Math.abs(camera.aspect - 0.8) < 0.001, 'resize 后相机宽高比更新（' + camera.aspect.toFixed(2) + '）');
globalThis.innerWidth = 1280; globalThis.innerHeight = 720;
fire('window', 'resize');
ok(Math.abs(camera.aspect - asp0) < 0.001, '恢复窗口后宽高比还原');

/* ============================================================
   8. 指针锁成功时的行为
   ============================================================ */
sec('8. 指针锁成功路径');
globalThis.__lockMode = 'ok';
document.pointerLockElement = el('app');       // 模拟浏览器真的把锁给了 canvas
fireDoc('pointerlockchange', {});
ok(locked === true, 'locked = true');
ok(paused === false, '拿到锁后处于可行动状态');
document.pointerLockElement = null;
fireDoc('pointerlockchange', {});
ok(locked === false && paused === true, '按 Esc 退出指针锁 → 暂停');

/* ============================================================
   9. 边界：越界被夹住
   ============================================================ */
sec('9. 世界边界');
paused = false;                                 // 上一节结束时是暂停态，先恢复（暂停时不推进是正确的）
player.x = WALK_R * 3; player.z = 0; player.vx = 0; player.vz = 0;
loop();
const rNow = Math.hypot(player.x, player.z);
console.log('  从 ' + (WALK_R * 3).toFixed(0) + ' m 处放置，一帧后被夹到 ' + rNow.toFixed(1) + ' m（半径 ' + WALK_R.toFixed(1) + '）');
ok(rNow <= WALK_R + 0.5, '越界会被夹回可行走半径内');
ok(Number.isFinite(player.x) && Number.isFinite(player.y) && Number.isFinite(player.z), '坐标仍然有限');
/* 朝墙猛冲也不该穿出去 */
player.x = 0; player.z = 0; player.y = sampleHeight(0, 0); player.yaw = Math.PI / 2;
pressKey('KeyW'); pressKey('ShiftLeft');
for (let i = 0; i < 3000; i++) loop();
releaseKey('KeyW'); releaseKey('ShiftLeft');
const rCharge = Math.hypot(player.x, player.z);
console.log('  贴墙冲刺 50 秒后离原点 ' + rCharge.toFixed(1) + ' m');
ok(rCharge <= WALK_R + 0.5, '持续冲刺也冲不出边界（' + rCharge.toFixed(1) + ' m）');
ok(Math.abs(player.y - sampleHeight(player.x, player.z)) < 0.05, '贴地状态没被边界逻辑破坏');

${DRIVER_FOOTER}
`;

let failed = false;
try {
  await runGame(DRIVER);
} catch (err) {
  console.log('\n运行失败：' + (err && err.message));
  failed = true;
}
console.log(failed ? '\n>>> 输入/UI 接线测试有失败 <<<' : '\n>>> 输入/UI 接线测试全部通过 <<<');
process.exit(failed ? 1 : 0);
