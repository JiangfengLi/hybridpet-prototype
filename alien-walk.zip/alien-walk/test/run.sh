#!/usr/bin/env bash
# 跑全部检查。用法： bash test/run.sh
# NODE 可覆盖： NODE=/path/to/node bash test/run.sh
NODE="${NODE:-C:/Users/26335/.workbuddy/binaries/node/versions/22.12.0/node.exe}"
cd "$(dirname "$0")/.." || exit 1

echo "########## 1/4 集成测试（场景 / AI / 交互逻辑）##########"
"$NODE" test/integration.mjs || FAILED=1

echo
echo "########## 2/4 输入与 UI 接线测试 ##########"
"$NODE" test/input.mjs || FAILED=1

echo
echo "########## 3/4 单文件版重建（含内联完整性断言）##########"
"$NODE" build-standalone.mjs || FAILED=1

echo
echo "########## 4/4 取景坐标（供 _shots/shoot.sh 用）##########"
"$NODE" test/animal-aim.mjs || FAILED=1

echo
if [ -n "$FAILED" ]; then echo ">>> 有检查失败 <<<"; exit 1; fi
echo ">>> 全部通过 <<<"
