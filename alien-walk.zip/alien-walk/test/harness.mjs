/**
 * 共享测试夹具：把 index.html 里的 module script 抽出来，注入最小 DOM / 渲染器桩，
 * 用**真实 three.js** 在 Node 里跑完整模块。
 *
 * 关键设计：桩与主体拼成**同一个 module**，所以 driver 代码能直接访问模块内部变量
 * （scene / player / state / keys / loop …），不需要为了测试改一行生产代码。
 * 这也意味着**桩要能接收并记录事件监听器**，否则"用户按下 W 会发生什么"这类接线永远测不到。
 *
 * 用法：
 *   import { runGame } from './harness.mjs';
 *   await runGame(`...driver 源码...`);
 */
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';

const HERE = path.dirname(url.fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');

/* ============================================================
   桩：DOM / 环境 / 渲染器
   —— 所有元素都记录监听器，挂到 globalThis.__L，供 driver 合成事件
   ============================================================ */
const STUBS = `
import * as THREE from '../vendor/three.module.min.js';

/* ---------- 事件注册表：__L[elemId][type] = [fn, ...] ---------- */
const __L = Object.create(null);
globalThis.__L = __L;
function rec(id, type, fn) {
  ((__L[id] ||= {})[type] ||= []).push(fn);
}

/* 可控的指针锁：driver 可以改 __lockMode 来模拟成功／被拒／静默失败 */
globalThis.__lockMode = 'reject';      // 'ok' | 'reject' | 'throw' | 'silent'
globalThis.__lockCalls = 0;

const ctxStub = {
  fillStyle: '', globalAlpha: 1, font: '', textAlign: '',
  createLinearGradient: () => ({ addColorStop() {} }),
  createRadialGradient: () => ({ addColorStop() {} }),
  fillRect() {}, beginPath() {}, ellipse() {}, fill() {}, save() {}, restore() {},
  arc() {}, stroke() {}, moveTo() {}, lineTo() {}, closePath() {},
};
const EL = Object.create(null);
function fakeEl(id) {
  if (EL[id]) return EL[id];
  const e = {
    id,
    classList: {
      _s: new Set(),
      add(c) { this._s.add(c); },
      remove(c) { this._s.delete(c); },
      toggle(c, on) { on === undefined ? (this._s.has(c) ? this._s.delete(c) : this._s.add(c)) : (on ? this._s.add(c) : this._s.delete(c)); },
      contains(c) { return this._s.has(c); },
    },
    style: {}, textContent: '', innerHTML: '', width: 0, height: 0,
    firstElementChild: { style: {} },
    appendChild() {},
    addEventListener(t, fn) { rec(id, t, fn); },
    requestPointerLock() {
      globalThis.__lockCalls++;
      if (globalThis.__lockMode === 'throw') throw new Error('pointer lock denied');
      if (globalThis.__lockMode === 'reject') return Promise.reject(new Error('pointer lock denied'));
      return undefined;                 // 'ok' / 'silent'
    },
    querySelector() { return { textContent: '', style: {} }; },
    getContext() { return ctxStub; },
    getBoundingClientRect() { return { left: 0, top: 0, width: 1280, height: 720 }; },
  };
  EL[id] = e;
  return e;
}

globalThis.document = {
  getElementById: fakeEl,
  querySelector: s => fakeEl('sel:' + s),
  createElement: t => fakeEl('new:' + t),
  addEventListener: (t, fn) => rec('document', t, fn),
  hidden: false,
  pointerLockElement: null,
  exitPointerLock() {},
};
globalThis.window = globalThis;
globalThis.innerWidth = 1280;
globalThis.innerHeight = 720;
globalThis.devicePixelRatio = 1;
globalThis.location = { search: '', href: 'http://127.0.0.1:8766/' };
globalThis.addEventListener = (t, fn) => rec('window', t, fn);
globalThis.AudioContext = undefined;      // 音频走早退分支
globalThis.webkitAudioContext = undefined;

/* 固定步长：否则紧凑循环里 Clock.getDelta() ≈ 0，动画分支根本跑不到 */
THREE.Clock.prototype.getDelta = function () { return 1 / 60; };
THREE.Clock.prototype.getElapsedTime = function () { return 0; };
`;

/* ============================================================
   抽取 + 注入
   ============================================================ */
export function extractBody() {
  const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  const m = html.match(/<script type="module">([\s\S]*?)<\/script>/);
  if (!m) throw new Error('index.html 里找不到 <script type="module">');

  const js = m[1];
  const start = js.lastIndexOf('/* ====', js.indexOf('0. 世界参数'));
  if (start < 0) throw new Error('找不到"0. 世界参数"章节标记');

  let body = js.slice(start);
  const NEEDLE = "const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });";
  if (!body.includes(NEEDLE)) {
    throw new Error('找不到渲染器创建语句 —— 模块结构变了，请更新 test/harness.mjs');
  }
  body = body.replace(NEEDLE, `const renderer = {
    shadowMap: { enabled: false, type: null },
    setPixelRatio() {}, setSize() {},
    render() { globalThis.__renders = (globalThis.__renders || 0) + 1; },
    setAnimationLoop(fn) { globalThis.__loop = fn; },
    outputColorSpace: null, toneMapping: null, toneMappingExposure: 1,
  };`);
  return body;
}

/**
 * 跑一份 driver（会与游戏主体拼进同一个 module）。
 * driver 里可以直接用 scene / player / state / keys / loop / tryScan … 以及合成事件工具：
 *   fire('window','keydown',{code:'KeyW'})
 *   fire('startBtn','click')
 */
export async function runGame(driverSource) {
  const body = extractBody();

  const HELPERS = `
/* ---------- driver 可用的合成事件工具（与游戏同作用域） ---------- */
function fire(elemId, type, ev) {
  const list = (globalThis.__L[elemId] || {})[type] || [];
  const e = Object.assign({ type, preventDefault() {}, stopPropagation() {} }, ev || {});
  for (const fn of list.slice()) fn(e);
  return list.length;
}
function fireKey(type, code, extra) { return fire('window', type, Object.assign({ code }, extra || {})); }
function fireDoc(type, ev) { return fire('document', type, ev); }
function pressKey(code) { fireKey('keydown', code); }
function releaseKey(code) { fireKey('keyup', code); }
function holdFrames(code, n) { pressKey(code); for (let i = 0; i < (n || 1); i++) loop(); releaseKey(code); }
/* 等一轮宏任务：让 Promise 链（如 requestPointerLock 的 catch）跑完 */
function tick() { return new Promise(r => setTimeout(r, 0)); }
`;

  const out = path.join(HERE, '.tmp-harness.mjs');
  fs.writeFileSync(out, STUBS + body + HELPERS + driverSource, 'utf8');
  try {
    await import(url.pathToFileURL(out).href);
  } finally {
    try { fs.unlinkSync(out); } catch (e) {}
  }
}

/* 汇总报告：driver 用 ok() 记录断言，footer 打印总结并决定退出码 */
export const DRIVER_FOOTER = `
const __fails = (globalThis.__t || []).filter(x => !x.ok).length;
console.log('');
console.log(__fails === 0 ? '===== 全部通过（' + (globalThis.__t || []).length + ' 项断言）=====' : '===== ' + __fails + ' 项失败 =====');
if (__fails) throw new Error(__fails + ' assertion(s) failed');
`;

export const DRIVER_HEAD = `
globalThis.__t = [];
const ok = (c, m) => { const r = { ok: !!c, msg: m }; globalThis.__t.push(r); console.log((r.ok ? 'ok   ' : 'FAIL ') + m); };
const sec = t => console.log('\\n=== ' + t + ' ===');
`;

export { ROOT };
